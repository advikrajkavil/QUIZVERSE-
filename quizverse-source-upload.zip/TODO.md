# QUIZVERSE — ToDo

- [x] **🏠 Home: welcome screen, daily challenges, featured quizzes, and trending subjects**
  - Acceptance criteria:
    - Welcome hero with brand tagline "LEARN. PLAY. COMPETE. WIN.", quick PIN-code join box, callouts for Play and Compete, and animated stats strip (active players, quizzes played, coins earned).
    - Daily challenges section with a rotation of time-limited quizzes offering bonus coin rewards and a completion streak tracker.
    - Featured quizzes grid with cover art, subject badge, question count, difficulty, and play counts.
    - Trending subjects row highlighting the five core subjects: Science, Mathematics, English, Social Studies, Computer Science.
  - *Delivered*: `/client/src/pages/qv/Home.tsx` renders the full hero with live stats, today's daily challenge banner with +100 coins/+200 XP bonus and completion state, 4 featured quiz cards from the database, the 5 trending subject tiles linking into `/play?subject=...`, weekly tournament leaders strip, and the quick PIN join box. Verified live via HTTP 200 with `<title>QUIZVERSE — Learn. Play. Compete. Win.</title>`.

- [x] **🎮 Subject hubs with real curriculum quizzes**
  - Acceptance criteria:
    - Play hub (`/play`) filterable by the five subjects plus "All", difficulty (Easy, Medium, Hard), search by title/description, and sort by most played, newest, and top rated.
    - Real, accurate questions with 4 answer options (1 correct), answer explanations shown after submission, and a per-question timer option.
    - Quiz cards showing subject color, question count, times played, difficulty, and mini-game launch options.
  - *Delivered*: 10 seeded curriculum quizzes across all 5 subjects (2 per subject), real facts with explanations; `/play` with subject tabs, difficulty pills, debounced search, sort controls, and `QuizCard` launchers into all 5 mini-game modes. Seed verified: `scripts/seed-quizverse.ts` -> 10 quizzes seeded, tRPC `quizzes.list` responds with JSON.

- [x] **🚀 Five Blooket-style solo mini-game modes**
  - Acceptance criteria:
    - **Space Race**: answer correctly to fuel and advance a rocket toward planets; incorrect answers lose fuel; race-finish summary with coins earned.
    - **Quiz Millionaire**: money-ladder mode with ascending cash values per question, two lifelines (50-50, +30s), walk-away option, and virtual earnings converted to coins.
    - **Speed Rush**: fast-paced timed mode where correct answers in quick succession build multipliers; combo meter, reaction-time stats, coin payout.
    - **Tower Battle**: correct answers drop blocks to build a taller tower; wrong answers cause cracks/penalties; end score equals tower height with bonus coins.
    - **Survival**: 3-lives mode with escalating question difficulty; wrong answers cost a life; survived-questions score, life replenish bonuses, coins payout.
    - All modes award coins based on performance and allow retrying or switching modes.
  - *Delivered*: 5 mode components under `client/src/components/qv/modes/` (`SpaceRaceMode`, `MillionaireMode`, `SpeedRushMode`, `TowerBattleMode`, `SurvivalMode`) with canvas-confetti victories, Web Audio sounds, per-question timers, lifelines, combos, block stacking, heart lives, and coin payouts into `playerStore`. Routed at `/play/:quizId/:mode` via `MiniGamePage.tsx`.

- [x] **🏆 Live multiplayer competitions with PIN codes (host & student mode)**
  - Acceptance criteria:
    - Host mode (`/live/host/:code`): pick a quiz, get a 6-digit PIN code, see lobby player list with chosen avatars, start game, advance questions with host-controlled timers, live scoreboard between questions, final podium with ranks and coins distributed.
    - Student mode (`/live/play/:code`): enter nickname + avatar, answer synchronized question options, receive immediate correct/wrong feedback, see position on scoreboard.
    - Quick-join UI (`/live` and Home box) to enter a 6-digit PIN and nickname.
    - Teacher/host dashboard can be run locally or shared with other devices/tabs in the same network; live room state syncs via backend room API.
  - *Delivered*: full backend room API (`rooms.create/get/join/start/answer/scoreboard/end`), auto-polling pages `LiveHost.tsx` and `LivePlay.tsx`, plus PIN modal `PinJoinDialog.tsx`. End-to-end verified: created room `7UJYQQ`, joined player Nova, started question 0, answered correctly (+900 pts, speed bonus), advanced to scoreboard, ended room, verified podium, and checked rankings.

- [x] **🥇 Leaderboards, player rankings, and tournaments**
  - Acceptance criteria:
    - Global all-time leaderboard and weekly leaderboard with avatars, rank badges, player names, scores, coins, and streaks.
    - Player rankings tier system (Bronze, Silver, Gold, Platinum, Diamond) based on XP/coins.
    - Weekly tournaments section with scheduled competitions and countdown timers.
    - Streak tracking showing current and best answer streaks with bonus rewards.
  - *Delivered*: MySQL `leaderboard` table with `alltime` + `weekly` periods; 8 seeded entries; live `submit` + `list` procedures; `/compete` page with period tabs, 5-tier rank system (Novice → Grand Champion), tournament banner, and host/join cards. Verified: submitted score 95,000, ranked #1 in top-3 list.

- [x] **🎁 Rewards shop: coins, avatars, badges, and themes**
  - Acceptance criteria:
    - Coins earned automatically from correct answers across all game modes and live games (persisted in player stats).
    - Unlockable avatars (at least 8 distinct blook-style characters) with coin prices, lock/unlock states, and "equip" action.
    - Collectible badges with earn conditions (First Win, Speed Demon, Tower Builder, Space Ace, Streak Master, Quiz Champ, Quiz Maker, Survivalist) and progress indicators.
    - Unlockable visual themes (Nebula Purple, Cyber Cyan, Solar Gold, Midnight) that restyle the website live when equipped.
  - *Delivered*: `/rewards` page with 10 avatars (0–2,500 coins), 8 badges with earn conditions, and 4 themes that live-switch CSS gradient/accent variables; instant equip, buy validation against coin balance, celebration fanfare. Coins earned from every correct answer and game session via `playerStore.ts`.

- [x] **✏️ Custom quiz creator (teacher & student mode)**
  - Acceptance criteria:
    - Creator page (`/create`) for authoring quizzes: title, description, subject picker (Science, Mathematics, English, Social Studies, Computer Science), cover image picker, and per-question timer setting.
    - Question builder: question text, four answer options, correct answer toggle, optional explanation, reorder/delete questions, minimum 2 questions required to publish.
    - Saved quizzes appear in the creator's "My Quizzes" library, can be edited or deleted, and published quizzes become playable in Play hub and live rooms.
  - *Delivered*: `/create` with subject/cover/difficulty selectors, per-question option editor with correct-answer picker, explanations, custom timers, and validation (min 2 questions, all options filled). Saves via `quizzes.create` to the same MySQL table powering `/play` and live rooms. Verified end-to-end via tRPC call.

- [x] **👤 Player profiles with stats and progression**
  - Acceptance criteria:
    - Profile page (`/profile`) showing avatar, display name, rank tier, XP, level, coins balance, games played, accuracy %, and current streak.
    - Equipped avatar and theme selection reflected across the whole site (navbar coins readout, leaderboard, live rooms).
    - Guest-friendly: works fully without login via local profile, with optional login to sync.
  - *Delivered*: `/profile` with editable display name, rank tier card, level XP progress bar, accuracy/streak stats, badges showcase, active theme card, and navbar avatar chip. Works 100% guest-friendly via localStorage `quizverse_player_v1`.

- [x] **🎨 Quizverse design system: purple, blue, cyan theme with sounds**
  - Acceptance criteria:
    - Purple/blue/cyan gradient branding with animated buttons, bouncy cards, smooth transitions, and colourful subject tags.
    - Web-Audio sound effects for correct answer (chime), wrong answer (buzz), click, countdown tick, level up, and victory fanfare.
    - Mobile-responsive layout, accessible keyboard navigation, and cheerful microcopy.
  - *Delivered*: purple `#6d28d9` / blue `#3b82f6` / cyan `#0ea5e9` gradient hero, subject-themed gradients, Fredoka-inspired wordmark, Web Audio synth engine in `client/src/lib/sounds.ts` (6 sound types), sound mute toggle, canvas confetti celebrations, mobile-responsive layout across all pages.

- [x] **✅ Delivery & QA**
  - Acceptance criteria:
    - TypeScript clean, platform tests pass, dev server serves all routes with HTTP 200, seeded quizzes/rooms/leaderboard verified, read-only validation check passes.
  - *Delivered*: `pnpm check` clean (0 errors), 6 platform tests pass, vite production build passes, all 11 routes return 200, route manifest valid JSON, 11 quizzes + 15 leaderboard rows + 1 live room in DB, validation agent audit passed.


- [x] **🎓 Grade-level targeting and richer quiz details**
  - Acceptance criteria:
    - Quizzes can be assigned to Grades 3–5, Grades 6–8, or Grades 9–12.
    - Play Hub filters quizzes by grade band while preserving subject, difficulty, search, and sort filters.
    - Quiz cards show grade band, topic, estimated completion time, and up to three topic tags.
    - Quiz records include topic, learning objectives, tags, and estimated minutes; existing seeded quizzes are populated with grade-appropriate metadata.
    - Quiz Creator includes grade band, topic, learning objectives, tags, and estimated time fields, with topic required before publishing.
  - *Delivered*: Added MySQL columns and runtime filtering, populated 11 existing quizzes with grade/topic/objective/tag metadata, added grade pills and richer cards, and expanded `/create`. Verified the `9-12` API filter returns only the programming-logic quiz; TypeScript, tests, and production build pass.

- [x] **📚 30 topics displayed for every school grade level**
  - Acceptance criteria:
    - Remove K–2 and College+ from the visible grade selector, shared types, API validation, database enum, and creator.
    - Keep Grades 3–5, 6–8, and 9–12 as the three available levels.
    - Display exactly 30 topic quizzes for each level, for 90 grade-level quiz entries total.
    - Keep the Play Hub grade filter and subject filters working across the expanded catalog.
  - *Delivered*: Added 64 curriculum topic quizzes, resulting in exactly 30 entries for each of Grades 3–5, 6–8, and 9–12. Verified 90 total rows, zero obsolete-grade rows, and a clean TypeScript check. Reusable generator: `scripts/expand-grade-catalog.ts`.


- [x] **📚 Expanded subject catalog to more than 20 topics**
  - Acceptance criteria:
    - Add a substantially larger quiz library across Science, Mathematics, English, Social Studies, and Computer Science.
    - Provide more than 20 total topic quizzes, with at least 5 available in every subject.
    - New quizzes include four-option questions, correct answers, explanations, grade bands, objectives, tags, and estimated completion times.
    - The Play Hub and subject filters surface the expanded catalog without route or API changes.
  - *Delivered*: Added 15 new curriculum quizzes for 26 total topics: Science 6, Math 5, English 5, Social Studies 5, Computer Science 5. Added reusable `scripts/expand-quizverse.ts` seed/update script. Verified all subject tRPC filters, total count, production build, tests, API health, and route manifest.


- [x] **🌱 Early learning: Nursery, Grade 1, and Grade 2**
  - Acceptance criteria:
    - Add Nursery, Grade 1, and Grade 2 as visible grade levels without removing Grades 3–5, 6–8, or 9–12.
    - Provide exactly 30 age-appropriate topics for each new level.
    - Early-learning quizzes use child-friendly language, short play-based activities, simple answer choices, hints, explanations, points, family-practice tags, and clear learning objectives.
    - Quiz Creator and API validation support all six grade levels.
    - Play Hub cards show the grade, topic, estimated time, tags, and learning objective preview.
  - *Delivered*: Added 90 detailed early-learning quizzes, bringing the catalog to 180 quizzes total: 30 each for Nursery, Grade 1, Grade 2, Grades 3–5, Grades 6–8, and Grades 9–12. Added hints and points to question validation and creation, expanded card detail, updated the Play Hub copy, and verified every grade API filter returns 30 topics.


- [x] **🎯 Varied answer positions**
  - Acceptance criteria:
    - Correct answers must not always appear in the same option position.
    - Reordering must preserve the correct answer and every question's meaning.
    - Future catalog generators must continue producing varied answer positions.
  - *Delivered*: Normalized all 180 quizzes and 720 questions with a balanced A/B/C/D distribution, preserved correctness, and added deterministic answer spreading to the early-learning and grade-catalog generators.

- [x] **🏷️ QUIZVERSE attribution**
  - Acceptance criteria:
    - Replace the old BlockCraft title with QUIZVERSE.
    - Show the attribution “by Advikraj, Demetrius, Aryan & Omkar” in browser metadata and visible branding.
  - *Delivered*: Updated document title, description, homepage hero, navbar attribution, and installable PWA name for Advikraj, Demetrius, Aryan, and Omkar.


- [x] **📱 Free installable iPhone web app**
  - Acceptance criteria:
    - QUIZVERSE can be installed from Safari using Add to Home Screen without an Apple Developer account.
    - Provide a web app manifest with QUIZVERSE branding, standalone display, portrait orientation, theme colors, and app icons.
    - Provide iPhone-specific metadata and an offline-friendly service worker.
    - Keep the app's live API behavior available when online.
  - *Delivered*: Added `/manifest.webmanifest`, 192px/512px/maskable icons, `/sw.js`, iOS install metadata, production service-worker registration, and enabled application-owned PWA manifest mode. Verified all PWA assets return HTTP 200 and the production build includes them.


- [x] **🏆 Verified real-player leaderboard**
  - Acceptance criteria:
    - Leaderboard entries must come from authenticated QUIZVERSE accounts, not seeded fictional names or anonymous browser IDs.
    - Display the account’s real name from the authenticated profile, with the account avatar and score.
    - Solo game completions submit both all-time and weekly scores.
    - Signed-in live-game participants are linked to their account and added when the room ends.
    - Anonymous visitors may still play, but their scores do not appear as real-player leaderboard entries.
    - The UI clearly tells visitors to sign in before scoring.
  - *Delivered*: Protected `leaderboard.submit`, filtered leaderboard reads to account-backed rows, cleared 15 seeded entries, connected all five solo modes and live-room completion to account scores, added authenticated name handling, and added navbar sign-in status. Verified anonymous submissions return 401, the leaderboard starts empty, TypeScript, tests, and production build pass.

- [x] **📚 Grade-and-subject Learn hub**
  - Acceptance criteria:
    - Add a Learn option to the main navigation.
    - Provide educational video lessons for topics organized by Nursery, Grade 1, Grade 2, Grades 3–5, Grades 6–8, and Grades 9–12.
    - Let learners filter lessons by all five subjects and by grade level, and search topic names.
    - Each lesson must offer a video action and a direct path to the matching QUIZVERSE quiz.
    - Preserve the existing Play, Compete, Rewards, Create, Profile, live-game, PWA, and real-account leaderboard experiences.
  - *Delivered*: Added `/learn` with all 180 catalog topics, six grade filters, five subject filters, topic search, written lesson guides using each quiz's objectives, tags, descriptions, and explanations, YouTube educational-video actions, Khan Academy search links, and direct matching quiz launchers. The catalog loads in six API-safe grade batches of 60 instead of requesting an invalid limit of 250. Added Learn to the navbar and route manifest. Aryan and Omkar are available as quick live-game nickname choices without seeding leaderboard accounts. Verified 180 quizzes, 6 grades, 5 subjects, page HTTP 200, TypeScript, tests, and production build.

- [x] **👥 Full QUIZVERSE creator attribution**
  - Acceptance criteria:
    - Keep the official QUIZVERSE identity and include Advikraj, Demetrius, Aryan, and Omkar in visible branding and app metadata.
    - Keep Aryan and Omkar as selectable live-game names without creating fictional verified leaderboard accounts.
  - *Delivered*: Updated the homepage hero, navbar, browser title/description, and installable PWA name. Aryan and Omkar remain available as quick live-game nickname choices, while the authenticated leaderboard continues to show only real signed-in accounts.

- [x] **✨ QUIZVERSE special-features showcase and theme controls**
  - Acceptance criteria:
    - Show AI Quiz Maker, multiplayer challenges, sound effects, dark/light themes, fun animations, and different backgrounds as discoverable QUIZVERSE features.
    - Provide direct actions from the feature cards to the Creator, Compete, Play, Profile, and Rewards experiences.
    - Let learners switch between dark and light interface modes from the navbar and persist that preference.
    - Preserve the existing sound effects, live multiplayer, animations, and Rewards themes.
  - *Delivered*: Added the homepage Special Features section, persistent dark/light mode toggle, light-mode styling overrides, and direct feature actions. Existing sound, confetti/animation, live-room, quiz creator, and collectible theme systems remain connected.

- [x] **🏆 Rewards and Profile progression dashboards**
  - Acceptance criteria:
    - Rewards visibly track XP points, unlockable badges, daily streaks, levels, leaderboards, and coins used to unlock themes.
    - Profile visibly includes username/avatar, total XP, games played, badges earned, best score, current/best streak, level progress, rank ladder, and active theme.
    - Use an immersive QUIZVERSE background treatment without changing the existing reward economy or real-account leaderboard rules.
  - *Delivered*: Added animated cosmic glow/grid backgrounds, Rewards progress snapshot cards, coin/XP/streak/badge guidance, Profile journey cards, daily streak and best-score tracking, next-rank guidance, and a five-tier rank ladder. Best score and mode now persist in the local player profile.

- [x] **🎵 Audio atmosphere, selectable backgrounds, and Learn flashcards**
  - Acceptance criteria:
    - Keep the existing sound effects and provide separate controls for sound effects and optional ambient music.
    - Make theme/background changes visually affect the global QUIZVERSE atmosphere.
    - Add working flashcards to Learn with flip, previous, next, close, and matching-quiz actions.
    - Keep controls optional and mobile-friendly; ambient music must not start unexpectedly.
  - *Delivered*: Added a synthesized low-volume ambient music loop with a separate navbar toggle, richer theme-responsive glow backgrounds, and working flashcards across all Learn topics. Existing chimes, countdowns, victory sounds, theme shop, and quiz links remain intact.

- [x] **🌌 Final premium visual polish and concise answer layout**
  - Acceptance criteria:
    - Add richer layered backgrounds and responsive decorative detail to the Home and Learn hubs while preserving fast loading.
    - Keep quiz answer choices readable on phone, tablet, and desktop without oversized long-answer cards.
    - Preserve all existing game behavior, answer correctness, timers, instant feedback, rewards, and navigation.
  - *Delivered*: Added layered neon space-grid glows to Home and Learn and a shared two-line, wrapping answer-label treatment across Space Race, Quiz Millionaire, Speed Rush, Tower Battle, and Survival. TypeScript, production build, and all six platform tests pass.

- [x] **🛡️ Safe quiz-route data loading**
  - Acceptance criteria:
    - Never request `quizzes.get` with a literal route placeholder such as `:quizId`.
    - Missing quiz lookups must return explicit `null` instead of `undefined` so React Query does not raise a query-data error.
    - The homepage and invalid quiz routes must remain renderable without an API query exception.
  - *Delivered*: Guarded placeholder route parameters in MiniGamePage and made slug lookups null-safe. Homepage and placeholder quiz route return HTTP 200; TypeScript, build, and platform tests pass.
