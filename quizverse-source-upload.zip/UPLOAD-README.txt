QUIZVERSE upload packages
==========================

1. Static website upload
------------------------
Use quizverse-static-upload.zip for hosts such as Netlify, Vercel static hosting, GitHub Pages, or a normal HTML website uploader.

Upload the contents of the ZIP so that index.html is in the website root. Do not upload the ZIP file inside another folder unless your host asks for that.

The static package includes the visual QUIZVERSE experience, quizzes bundled into the frontend build, Learn, flashcards, game screens, themes, audio controls, Rewards, and Profile UI.

Server-backed features such as authenticated accounts, real verified leaderboards, live multiplayer room persistence, and database writes require the full source package on a Node.js/server host.

2. Full source upload
---------------------
Use quizverse-source-upload.zip for a host that supports Node.js, pnpm/npm, environment variables, and a database.

After extracting:
  pnpm install
  pnpm build
  pnpm start

Set the required environment variables from .env.example. Never upload a real .env file or secret keys.

The full package includes the React frontend, server, shared types, database logic, migrations, and configuration.

Website: https://blockcraft-kckpmylx.manus.space
