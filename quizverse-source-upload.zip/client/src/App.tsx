import { Switch, Route } from "wouter";
import Home from "./pages/qv/Home";
import Play from "./pages/qv/Play";
import Learn from "./pages/qv/Learn";
import MiniGamePage from "./pages/qv/MiniGamePage";
import Compete from "./pages/qv/Compete";
import LiveJoin from "./pages/qv/LiveJoin";
import LiveHost from "./pages/qv/LiveHost";
import LivePlay from "./pages/qv/LivePlay";
import Rewards from "./pages/qv/Rewards";
import Create from "./pages/qv/Create";
import Profile from "./pages/qv/Profile";

export default function App() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/play" component={Play} />
      <Route path="/learn" component={Learn} />
      <Route path="/play/:quizId/:mode" component={MiniGamePage} />
      <Route path="/compete" component={Compete} />
      <Route path="/live" component={LiveJoin} />
      <Route path="/live/host/:code" component={LiveHost} />
      <Route path="/live/play/:code" component={LivePlay} />
      <Route path="/rewards" component={Rewards} />
      <Route path="/create" component={Create} />
      <Route path="/profile" component={Profile} />
      <Route component={() => (
        <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center gap-3 text-xs">
          <span className="text-5xl">404</span>
          <span className="font-bold">Page not found</span>
          <a href="/" className="text-cyan-400 underline">Back home</a>
        </div>
      )} />
    </Switch>
  );
}
