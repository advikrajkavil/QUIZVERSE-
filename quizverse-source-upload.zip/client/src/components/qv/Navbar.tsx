/**
 * QUIZVERSE top navbar — brand logo, nav links, coins readout, equipped avatar chip,
 * PIN join trigger, sound toggle, and sign in.
 */

import React, { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  getPlayer,
  subscribePlayer,
  setName,
  applyTheme,
  getUiMode,
  applyUiMode,
} from "@/lib/playerStore";
import type { UiMode } from "@/lib/playerStore";
import { AVATARS } from "@/lib/quizverseData";
import {
  Gamepad2,
  Trophy,
  Gift,
  Plus,
  PlayCircle,
  BookOpen,
  Volume2,
  VolumeX,
  Sparkles,
  Flame,
  Sun,
  Moon,
  Music2,
} from "lucide-react";
import { isSoundsEnabled, setSoundsEnabled, isMusicEnabled, setMusicEnabled, playClick } from "@/lib/sounds";
import { Button } from "@/components/ui/button";

export function Navbar({ onOpenPin }: { onOpenPin?: () => void }) {
  const [location] = useLocation();
  const [player, setPlayerState] = useState(getPlayer());
  const [soundOn, setSoundOn] = useState(isSoundsEnabled());
  const [musicOn, setMusicOn] = useState(isMusicEnabled());
  const [uiMode, setUiMode] = useState<UiMode>(getUiMode());
  const [editName, setEditName] = useState(false);
  const [tempName, setTempName] = useState(player.name);

  useEffect(() => {
    applyTheme(player.theme);
    applyUiMode(uiMode);
    return subscribePlayer(() => {
      setPlayerState({ ...getPlayer() });
    });
  }, [uiMode]);

  const links = [
    { href: "/", label: "Home", icon: Sparkles },
    { href: "/play", label: "Play", icon: PlayCircle },
    { href: "/learn", label: "Learn", icon: BookOpen },
    { href: "/compete", label: "Compete", icon: Trophy },
    { href: "/rewards", label: "Rewards", icon: Gift },
    { href: "/create", label: "Create", icon: Plus },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur border-b border-purple-900/40 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-2">
        {/* Brand */}
        <Link
          href="/"
          onClick={playClick}
          className="flex items-center gap-2 group shrink-0"
        >
          <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500 via-indigo-500 to-cyan-400 flex items-center justify-center text-xl shadow-md shadow-purple-500/30 group-hover:scale-105 transition-transform">
            🧠
          </span>
          <div className="flex flex-col">
            <span
              className="font-black text-lg tracking-tight bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text text-transparent"
              style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}
            >
              QUIZVERSE
            </span>
            <span className="text-[9px] uppercase tracking-widest text-slate-400 -mt-1 hidden sm:block">
              by Advikraj, Demetrius, Aryan &amp; Omkar
            </span>
          </div>
        </Link>

        {/* Nav links */}
        <nav className="hidden md:flex items-center gap-1 text-xs font-bold">
          {links.map((l) => {
            const active = location === l.href;
            const Icon = l.icon;
            return (
              <Link
                key={l.href}
                href={l.href}
                onClick={playClick}
                className={`px-3 py-1.5 rounded-full flex items-center gap-1.5 transition ${
                  active
                    ? "bg-purple-600/60 text-white shadow-inner"
                    : "text-slate-300 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {l.label}
              </Link>
            );
          })}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2 text-xs">
          {/* PIN quick-join button */}
          <Button
            size="sm"
            onClick={() => {
              playClick();
              onOpenPin?.();
            }}
            className="bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black h-8 px-3 rounded-full shadow-md text-xs tracking-wide"
          >
            ENTER PIN
          </Button>

          {/* Coins readout */}
          <Link
            href="/rewards"
            onClick={playClick}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-300 font-extrabold hover:bg-amber-400/25 transition"
            title="Your coin balance — spend in the Rewards shop"
          >
            <span>🪙</span>
            <span className="font-mono text-sm">{player.coins}</span>
          </Link>

          {/* Sound toggle */}
          <button
            type="button"
            onClick={() => {
              const next = !soundOn;
              setSoundsEnabled(next);
              setSoundOn(next);
              if (!next) setMusicOn(false);
            }}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-300 transition"
            title={soundOn ? "Mute sounds" : "Enable sounds"}
            aria-label={soundOn ? "Mute sounds" : "Enable sounds"}
          >
            {soundOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Ambient music toggle */}
          <button
            type="button"
            onClick={() => {
              const next = !musicOn;
              setMusicEnabled(next);
              setMusicOn(next);
            }}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-300 transition"
            title={musicOn ? "Mute ambient music" : "Play ambient music"}
            aria-label={musicOn ? "Mute ambient music" : "Play ambient music"}
          >
            <Music2 className={`w-4 h-4 ${musicOn ? "text-fuchsia-300" : "text-slate-500"}`} />
          </button>

          {/* Dark/light theme toggle */}
          <button
            type="button"
            onClick={() => {
              playClick();
              const next = uiMode === "dark" ? "light" : "dark";
              setUiMode(next);
              applyUiMode(next);
            }}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-300 transition"
            title={uiMode === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            aria-label={uiMode === "dark" ? "Switch to light theme" : "Switch to dark theme"}
          >
            {uiMode === "dark" ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-indigo-300" />}
          </button>

          {/* Avatar chip -> profile */}
          <Link
            href="/profile"
            onClick={playClick}
            className="flex items-center gap-2 pl-1 pr-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 transition"
            title="Open profile & stats"
          >
            <span className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-500 to-cyan-400 flex items-center justify-center text-sm shadow">
              {player.avatar}
            </span>
            <span className="font-bold text-slate-200 hidden sm:inline max-w-[100px] truncate">
              {player.name}
            </span>
            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono font-bold bg-purple-500/30 text-purple-200 hidden md:inline">
              Lv{player.level}
            </span>
          </Link>
        </div>
      </div>
    </header>
  );
}
