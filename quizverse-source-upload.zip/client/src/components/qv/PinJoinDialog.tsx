/**
 * PinJoinDialog — quick-join a Kahoot-style live quiz room by 6-digit PIN.
 */

import React, { useState } from "react";
import { useLocation } from "wouter";
import { getPlayer, setName } from "@/lib/playerStore";
import { trpc } from "@/lib/trpc";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { playClick } from "@/lib/sounds";
import { Users, Loader2 } from "lucide-react";

export function PinJoinDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [, setLocation] = useLocation();
  const player = getPlayer();
  const [pin, setPin] = useState("");
  const [nickname, setNickname] = useState(player.name || "");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const roomUtils = trpc.useUtils();

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    setError(null);
    const code = pin.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (code.length !== 6) {
      setError("PIN must be 6 characters");
      return;
    }
    const name = (nickname || "Player").trim().slice(0, 32);
    setName(name);
    setLoading(true);
    try {
      const room = await roomUtils.client.rooms.get.query({ code });
      if (!room) {
        setError("Room not found. Check the PIN and try again.");
        return;
      }
      onOpenChange(false);
      setLocation(`/live/play/${code}`);
    } catch {
      setError("Could not connect. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm bg-slate-950 text-white border-purple-800/60 p-6 rounded-3xl">
        <DialogHeader className="text-center">
          <div className="mx-auto w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-slate-950 shadow-lg shadow-cyan-500/30 mb-2">
            <Users className="w-6 h-6" />
          </div>
          <DialogTitle className="text-2xl font-black bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text text-transparent">
            Join Live Game
          </DialogTitle>
          <p className="text-xs text-slate-400">Enter the 6-digit game PIN shown by your host</p>
        </DialogHeader>

        <form onSubmit={handleJoin} className="flex flex-col gap-4 mt-2">
          <div>
            <label className="text-[11px] uppercase font-bold text-slate-400">Game PIN</label>
            <input
              type="text"
              inputMode="text"
              maxLength={6}
              autoFocus
              placeholder="123456"
              value={pin}
              onChange={(e) => setPin(e.target.value.toUpperCase())}
              className="mt-1 w-full text-center text-3xl font-black tracking-widest font-mono py-3 rounded-2xl bg-white/5 border border-purple-800/60 text-cyan-300 focus:outline-none focus:border-cyan-400"
            />
          </div>
          <div>
            <label className="text-[11px] uppercase font-bold text-slate-400">Nickname</label>
            <input
              type="text"
              maxLength={32}
              placeholder="Your name"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              className="mt-1 w-full text-center text-sm font-bold py-2.5 rounded-2xl bg-white/5 border border-purple-800/60 text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          {error && <div className="text-xs text-rose-400 text-center font-semibold">{error}</div>}

          <Button
            type="submit"
            disabled={loading}
            className="w-full h-11 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black text-sm tracking-wide shadow-lg shadow-cyan-500/30"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "ENTER GAME"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
