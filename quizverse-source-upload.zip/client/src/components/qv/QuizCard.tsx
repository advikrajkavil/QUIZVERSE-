/**
 * QuizCard — displays a quiz with subject styling, difficulty pill,
 * question count, plays stat, and mini-game launch options.
 */

import React, { useState } from "react";
import { Link } from "wouter";
import { QuizDoc, Subject } from "@shared/types";
import { GRADE_MAP, SUBJECT_MAP } from "@/lib/quizverseData";
import { PlayCircle, Users, Sparkles, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

const MODES = [
  { id: "space-race", name: "🚀 Space Race", desc: "Rocket progression" },
  { id: "millionaire", name: "💰 Quiz Millionaire", desc: "Money ladder" },
  { id: "speed-rush", name: "🏎️ Speed Rush", desc: "Combo speed run" },
  { id: "tower-battle", name: "🏰 Tower Battle", desc: "Build by answering" },
  { id: "survival", name: "🧟 Survival", desc: "3 lives, keep answering" },
];

export function QuizCard({ quiz }: { quiz: QuizDoc | any }) {
  const [open, setOpen] = useState(false);
  const sub = SUBJECT_MAP.get(quiz.subject);
  const grade = GRADE_MAP.get(quiz.gradeBand);
  const diffColors: Record<string, string> = {
    easy: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
    medium: "bg-amber-500/20 text-amber-300 border-amber-500/30",
    hard: "bg-rose-500/20 text-rose-300 border-rose-500/30",
  };

  return (
    <div className="group relative bg-slate-900/80 rounded-2xl border border-purple-900/30 hover:border-cyan-400/50 hover:shadow-xl hover:shadow-cyan-500/10 transition-all flex flex-col overflow-hidden text-xs text-white">
      {/* Top banner */}
      <div className={`relative p-4 pb-3 flex items-start justify-between bg-gradient-to-r ${sub?.gradient || "from-purple-600 to-indigo-600"} text-white`}>
        <div className="flex items-center gap-2">
          <span className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center text-2xl shadow">
            {quiz.cover || "🧠"}
          </span>
          <div>
            <span className="inline-block text-[10px] font-black uppercase tracking-wider bg-black/25 px-2 py-0.5 rounded-full backdrop-blur">
              {sub?.icon} {sub?.name}
            </span>
          </div>
        </div>
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${diffColors[quiz.difficulty] || diffColors.medium}`}>
          {quiz.difficulty}
        </span>
      </div>

      {/* Body */}
      <div className="p-4 flex flex-col gap-2 flex-1">
        <div className="flex items-center justify-between gap-2">
          <span className="px-2 py-0.5 rounded-full bg-cyan-400/10 border border-cyan-400/20 text-cyan-300 text-[10px] font-black">
            {grade?.short || "All grades"}
          </span>
          <span className="text-[10px] text-slate-500">{quiz.estimatedMinutes || 5} min</span>
        </div>
        <h3 className="font-black text-sm text-white group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug">
          {quiz.title}
        </h3>
        <div className="text-[10px] font-bold text-purple-300">{quiz.topic || "General"}</div>
        <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed flex-1">
          {quiz.description || "Challenge yourself with these questions."}
        </p>
        {quiz.learningObjectives && (
          <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">
            <span className="font-bold text-slate-400">You’ll practice:</span> {quiz.learningObjectives}
          </p>
        )}

        {/* Stats */}
        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-white/5">
          <span>{quiz.questions?.length ?? 0} questions</span>
          <span className="flex items-center gap-1">
            <Users className="w-3 h-3 text-slate-500" />
            {(quiz.timesPlayed ?? 0).toLocaleString()} plays
          </span>
        </div>
        {quiz.tags && (
          <div className="flex flex-wrap gap-1">
            {String(quiz.tags).split(",").slice(0, 3).map((tag: string) => (
              <span key={tag} className="px-1.5 py-0.5 rounded bg-white/5 text-[9px] text-slate-500">#{tag.trim()}</span>
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="pt-2 flex items-center gap-2">
          <Link
            href={`/play/${quiz.slug}/space-race`}
            className="flex-1 py-2 rounded-xl bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 hover:brightness-110 font-black text-xs text-center text-white shadow-md shadow-purple-500/30 flex items-center justify-center gap-1.5 transition"
          >
            <PlayCircle className="w-4 h-4" /> Play
          </Link>
          <div className="relative">
            <button
              type="button"
              onClick={() => setOpen((o) => !o)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition"
              title="More game modes"
              aria-label="More game modes"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
            {open && (
              <div
                className="absolute right-0 bottom-full mb-1 w-56 rounded-xl bg-slate-900 border border-purple-800/60 p-1.5 shadow-2xl z-20 text-[11px] flex flex-col gap-0.5"
                onClick={() => setOpen(false)}
              >
                <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase">
                  Choose a game mode
                </div>
                {MODES.map((m) => (
                  <Link
                    key={m.id}
                    href={`/play/${quiz.slug}/${m.id}`}
                    className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-slate-200 transition"
                  >
                    <span className="font-bold">{m.name}</span>
                    <span className="text-[10px] text-slate-500">{m.desc}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
