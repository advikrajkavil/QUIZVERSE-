/**
 * Quiz Millionaire — money-ladder mode.
 * 15 levels up to $1,000,000. Lifelines: 50-50, +30s. Walk-away cash out.
 * Safety levels lock in your earnings.
 */

import React, { useEffect, useState, useRef } from "react";
import { QuizDoc, Question } from "@shared/types";
import { recordAnswer, earnCoins, earnXp, finishGameSession } from "@/lib/playerStore";
import { playClick, playCorrect, playWrong, playVictory, playTick, playUrgent } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Coins, Sparkles, Shield, RotateCcw } from "lucide-react";
import confetti from "canvas-confetti";

const LADDER = [
  100, 200, 300, 500, 1000, 2000, 4000, 8000, 16000, 32000, 64000, 125000, 250000, 500000, 1000000,
];
const SAFETIES = [5, 10]; // ladder indexes (1-based displayed) that are guaranteed

export function MillionaireMode({ quiz, onExit, onComplete }: { quiz: QuizDoc | any; onExit: () => void; onComplete?: (result: { score: number; totalQuestions: number; gameMode: string }) => void }) {
  const baseQuestions: Question[] = quiz.questions || [];
  // loop questions if quiz has fewer than 15
  const questions: Question[] = Array.from({ length: 15 }, (_, i) => baseQuestions[i % baseQuestions.length]);
  const [level, setLevel] = useState(0); // 0..14
  const [selected, setSelected] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [timer, setTimer] = useState(30);
  const [hiddenOptions, setHiddenOptions] = useState<number[]>([]);
  const [lifeline5050, setLifeline5050] = useState(true);
  const [lifelineTime, setLifelineTime] = useState(true);
  const [finished, setFinished] = useState(false);
  const [walked, setWalked] = useState(false);
  const timerRef = useRef<number | null>(null);

  const q = questions[level];
  const money = level > 0 ? LADDER[level - 1] : 0;
  const guaranteed = SAFETIES.filter((s) => level >= s).pop();
  const guaranteedMoney = guaranteed ? LADDER[guaranteed - 1] : 0;

  useEffect(() => {
    if (!q || showAnswer || finished) return;
    setTimer(30);
    setHiddenOptions([]);
    timerRef.current = window.setInterval(() => {
      setTimer((t) => {
        if (t <= 1) {
          handleWrong(null);
          return 0;
        }
        if (t <= 6) playUrgent();
        else if (t <= 10) playTick();
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [level, showAnswer, finished]);

  const handleWrong = (_picked: number | null) => {
    setShowAnswer(true);
    playWrong();
    recordAnswer(false);
    end(guaranteedMoney);
  };

  const handlePick = (idx: number) => {
    if (showAnswer || finished) return;
    setSelected(idx);
    setShowAnswer(true);
    if (idx === q.correct) {
      playCorrect();
      recordAnswer(true);
      const nextLevel = level + 1;
      if (nextLevel >= 15) {
        end(1000000, true);
      }
    } else {
      playWrong();
      recordAnswer(false);
      end(guaranteedMoney);
    }
  };

  const handleNext = () => {
    setLevel((l) => l + 1);
    setSelected(null);
    setShowAnswer(false);
  };

  const use5050 = () => {
    if (!lifeline5050 || showAnswer) return;
    setLifeline5050(false);
    playClick();
    const wrongs = [0, 1, 2, 3].filter((i) => i !== q.correct);
    wrongs.sort(() => Math.random() - 0.5);
    setHiddenOptions(wrongs.slice(0, 2));
  };

  const useExtraTime = () => {
    if (!lifelineTime || showAnswer) return;
    setLifelineTime(false);
    playClick();
    setTimer((t) => t + 30);
  };

  const walkAway = () => {
    setWalked(true);
    end(money);
  };

  const end = (finalMoney: number, won = false) => {
    setFinished(true);
    const coins = Math.max(10, Math.round(finalMoney / 10000) * 10);
    earnCoins(coins);
    earnXp(Math.max(50, Math.round(finalMoney / 2000)));
    finishGameSession({
      gameMode: "millionaire",
      score: finalMoney,
      totalQuestions: 15,
      bonusCoins: coins,
    });
    onComplete?.({ score: finalMoney, totalQuestions: 15, gameMode: "millionaire" });
    if (won) {
      try {
        confetti({ particleCount: 120, spread: 100 });
      } catch {}
      playVictory();
    }
  };

  const restart = () => {
    setLevel(0);
    setSelected(null);
    setShowAnswer(false);
    setLifeline5050(true);
    setLifelineTime(true);
    setFinished(false);
    setWalked(false);
  };

  if (!q) return null;

  return (
    <div className="flex flex-col gap-4 max-w-4xl mx-auto w-full">
      {/* Header */}
      <div className="bg-slate-900/90 rounded-3xl p-4 border border-purple-800/50 flex flex-wrap items-center justify-between gap-3 shadow-2xl">
        <div className="flex items-center gap-2">
          <span className="w-8 h-8 rounded-xl bg-amber-500/30 text-amber-300 flex items-center justify-center text-lg">💰</span>
          <div>
            <span className="font-black text-white text-sm">Quiz Millionaire</span>
            <span className="text-[10px] text-slate-400 block">{quiz.title}</span>
          </div>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono">
          <span className="px-3 py-1 rounded-full bg-amber-400/15 border border-amber-400/40 text-amber-300 font-extrabold text-sm">
            ${money.toLocaleString()}
          </span>
          <span className="text-purple-300 font-bold">⏱ {timer}s</span>
          <span className="text-slate-400 text-[11px]">Level {level + 1}/15</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_260px] gap-4">
        {/* Main question area */}
        {finished ? (
          <div className="bg-slate-900/95 rounded-3xl p-8 border border-purple-800/60 text-center flex flex-col items-center gap-4 shadow-2xl">
            <div className="text-5xl">{money >= 1000000 ? "👑" : money >= 100000 ? "💎" : "🪙"}</div>
            <h2 className="text-3xl font-black bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-500 bg-clip-text text-transparent">
              {money >= 1000000 ? "YOU WON $1,000,000!" : walked ? "You Walked Away!" : "Game Over"}
            </h2>
            <p className="text-xs text-slate-400">
              Final winnings: <span className="font-mono font-bold text-amber-300 text-base">${money.toLocaleString()}</span>
            </p>
            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="p-3 rounded-2xl bg-white/5 border border-white/5 text-amber-300 font-bold">
                +{(Math.max(10, Math.round(money / 10000) * 10)).toLocaleString()} coins
              </span>
              <span className="p-3 rounded-2xl bg-white/5 border border-white/5 text-purple-300 font-bold">
                +{Math.max(50, Math.round(money / 2000)).toLocaleString()} XP
              </span>
            </div>
            <div className="flex gap-3 pt-2">
              <Button onClick={restart} className="bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-slate-950 font-black gap-1.5 rounded-2xl">
                <RotateCcw className="w-4 h-4" /> Play Again
              </Button>
              <Button onClick={onExit} variant="outline" className="border-white/10 text-white rounded-2xl">
                Pick another mode
              </Button>
            </div>
          </div>
        ) : (
          <div className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/50 flex flex-col gap-5 shadow-2xl">
            {/* Lifelines */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex gap-2">
                <Button
                  size="sm"
                  disabled={!lifeline5050}
                  onClick={use5050}
                  className="rounded-full bg-purple-600/60 hover:bg-purple-600 text-white text-xs font-bold disabled:opacity-40"
                >
                  50:50
                </Button>
                <Button
                  size="sm"
                  disabled={!lifelineTime}
                  onClick={useExtraTime}
                  className="rounded-full bg-cyan-600/60 hover:bg-cyan-600 text-white text-xs font-bold disabled:opacity-40"
                >
                  +30s
                </Button>
              </div>
              {level > 0 && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={walkAway}
                  className="rounded-full border-amber-400/40 text-amber-300 hover:bg-amber-400/10 text-xs font-bold"
                >
                  Walk away with ${money.toLocaleString()}
                </Button>
              )}
            </div>

            <div className="text-base sm:text-lg font-bold text-white leading-relaxed">{q.text}</div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {q.options.map((opt, i) => {
                if (hiddenOptions.includes(i)) {
                  return <div key={i} className="p-4 rounded-2xl border border-white/5 opacity-25" />;
                }
                const isSelected = selected === i;
                const isCorrect = i === q.correct;
                let cls =
                  "p-4 rounded-2xl text-left font-bold text-xs sm:text-sm border transition flex items-center justify-between text-white ";
                if (!showAnswer) {
                  cls += "bg-white/5 hover:bg-white/10 border-white/10 hover:border-amber-400/60 active:scale-[0.99]";
                } else if (isCorrect) {
                  cls += "bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-lg shadow-emerald-500/20";
                } else if (isSelected) {
                  cls += "bg-rose-500/25 border-rose-400 text-rose-200";
                } else {
                  cls += "bg-white/5 border-white/5 opacity-50";
                }
                return (
                  <button key={i} type="button" onClick={() => handlePick(i)} className={cls}>
                    <span className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center font-mono text-[11px] shrink-0">
                        {["A", "B", "C", "D"][i]}
                      </span>
                      <span className="qv-answer-label">{opt}</span>
                    </span>
                    {showAnswer && isCorrect && <span className="text-emerald-300 text-xs">✔</span>}
                    {showAnswer && isSelected && !isCorrect && <span className="text-rose-300 text-xs">✘</span>}
                  </button>
                );
              })}
            </div>

            {showAnswer && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-white/5 text-xs">
                <span className="text-slate-300 text-[11px] leading-relaxed">
                  {q.explanation || (selected === q.correct ? "Correct! Climbing the ladder..." : "Wrong answer — you drop to your safety net.")}
                </span>
                <Button
                  onClick={handleNext}
                  className="bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-slate-950 font-black rounded-2xl px-5 text-xs shrink-0"
                >
                  Next Question →
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Money ladder sidebar */}
        <div className="bg-slate-900/90 rounded-3xl p-4 border border-purple-800/50 flex flex-col gap-1.5 shadow-2xl text-xs">
          <div className="text-[10px] font-black uppercase text-slate-400 mb-1 flex items-center justify-between">
            <span>Money Ladder</span>
            <span className="text-amber-300 font-mono">🔒 guaranteed</span>
          </div>
          {[...LADDER].reverse().map((amt, idx) => {
            const actualIdx = 14 - idx; // 0..14
            const isCurrent = level === actualIdx;
            const isPassed = level > actualIdx;
            const isSafety = SAFETIES.includes(actualIdx + 1);
            let cls =
              "px-3 py-1.5 rounded-xl font-mono text-xs flex items-center justify-between transition ";
            if (isCurrent) cls += "bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-black shadow-md ";
            else if (isPassed) cls += "bg-white/10 text-emerald-300 font-bold ";
            else cls += "text-slate-400 ";
            return (
              <div key={actualIdx} className={cls}>
                <span className="text-[10px] font-sans">
                  {isSafety && "🔒 "}Q{actualIdx + 1}
                </span>
                <span>${amt.toLocaleString()}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
