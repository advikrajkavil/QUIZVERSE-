/**
 * Space Race — Blooket-style rocket progression mode.
 * Correct answers fuel and launch your rocket toward planets; incorrect answers
 * lose fuel and stall. Finish race to earn coins.
 */

import React, { useEffect, useState, useRef } from "react";
import { QuizDoc, Question } from "@shared/types";
import { recordAnswer, earnCoins, earnXp, finishGameSession } from "@/lib/playerStore";
import { playClick, playCorrect, playWrong, playVictory, playTick } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Rocket, Sparkles, Fuel, Zap, RotateCcw } from "lucide-react";
import confetti from "canvas-confetti";

const PLANETS = ["🌙 Moon", "🔴 Mars", "🪐 Jupiter", "🌀 Neptune", "🌌 Galaxy Hub"];

export function SpaceRaceMode({ quiz, onExit, onComplete }: { quiz: QuizDoc | any; onExit: () => void; onComplete?: (result: { score: number; totalQuestions: number; gameMode: string }) => void }) {
  const questions: Question[] = quiz.questions || [];
  const [index, setIndex] = useState(0);
  const [fuel, setFuel] = useState(100);
  const [planet, setPlanet] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [timer, setTimer] = useState(questions[0]?.timeLimit || 20);
  const [score, setScore] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const timerRef = useRef<number | null>(null);

  const q = questions[index];

  // Per-question countdown
  useEffect(() => {
    if (!q || showAnswer || finished) return;
    setTimer(q.timeLimit || 20);
    timerRef.current = window.setInterval(() => {
      setTimer((t) => {
        if (t <= 1) {
          handleTimeout();
          return 0;
        }
        if (t <= 6) playTick();
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [index, q, showAnswer, finished]);

  const handleTimeout = () => {
    if (showAnswer || finished) return;
    setShowAnswer(true);
    playWrong();
    recordAnswer(false);
    setFuel((f) => Math.max(0, f - 30));
  };

  const handlePick = (optIndex: number) => {
    if (showAnswer || finished) return;
    setSelected(optIndex);
    setShowAnswer(true);
    const correct = optIndex === q.correct;
    if (correct) {
      playCorrect();
      recordAnswer(true);
      setScore((s) => s + 100);
      setCorrectCount((c) => c + 1);
      setFuel((f) => Math.min(100, f + 15));
      setPlanet((p) => Math.min(PLANETS.length - 1, p + 1));
    } else {
      playWrong();
      recordAnswer(false);
      setFuel((f) => Math.max(0, f - 25));
    }
  };

  const handleNext = () => {
    if (index + 1 >= questions.length || planet >= PLANETS.length - 1 || fuel <= 0) {
      endRace();
      return;
    }
    setIndex((i) => i + 1);
    setSelected(null);
    setShowAnswer(false);
  };

  const endRace = () => {
    setFinished(true);
    const coins = Math.round(score * 0.4 + (planet === PLANETS.length - 1 ? 50 : 10));
    earnCoins(coins);
    earnXp(score + 50);
    finishGameSession({
      gameMode: "space-race",
      score,
      totalQuestions: questions.length,
      bonusCoins: coins,
      stats: { fuelRemaining: fuel },
    });
    onComplete?.({ score, totalQuestions: questions.length, gameMode: "space-race" });
    if (score >= questions.length * 80) {
      try {
        confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
      } catch {}
      playVictory();
    }
  };

  const restart = () => {
    setIndex(0);
    setFuel(100);
    setPlanet(0);
    setSelected(null);
    setShowAnswer(false);
    setScore(0);
    setCorrectCount(0);
    setFinished(false);
  };

  if (!q) return null;

  return (
    <div className="flex flex-col gap-4 max-w-3xl mx-auto w-full">
      {/* Race track header */}
      <div className="bg-slate-900/90 rounded-3xl p-4 border border-purple-800/50 flex flex-col gap-3 shadow-2xl">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-purple-600 flex items-center justify-center text-lg">🚀</span>
            <div>
              <span className="font-black text-white text-sm">Space Race</span>
              <span className="text-[10px] text-slate-400 block">{quiz.title}</span>
            </div>
          </div>
          <div className="flex items-center gap-4 font-mono text-xs">
            <span className="text-cyan-300 font-bold">{score} pts</span>
            <span className="text-amber-300 font-bold">Q{index + 1}/{questions.length}</span>
            <span className="text-purple-300 font-bold">⏱ {timer}s</span>
          </div>
        </div>

        {/* Orbit track */}
        <div className="relative pt-6 pb-2">
          <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 transition-all duration-700"
              style={{ width: `${((planet + 1) / PLANETS.length) * 100}%` }}
            />
          </div>
          {/* Rocket */}
          <div
            className="absolute top-0 text-2xl -ml-3 transition-all duration-700"
            style={{ left: `${Math.min(96, ((planet + 1) / PLANETS.length) * 100)}%` }}
          >
            🚀
          </div>
          {/* Planet markers */}
          <div className="flex justify-between mt-3 text-[10px] font-bold text-slate-400">
            {PLANETS.map((p, i) => (
              <span key={p} className={i <= planet ? "text-cyan-300 font-black" : "text-slate-600"}>
                {p}
              </span>
            ))}
          </div>
        </div>

        {/* Fuel gauge */}
        <div className="flex items-center gap-2 text-[11px]">
          <Fuel className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-bold text-slate-400">Fuel</span>
          <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${fuel > 40 ? "bg-amber-400" : "bg-rose-500"}`}
              style={{ width: `${fuel}%` }}
            />
          </div>
          <span className="font-mono text-xs text-amber-300 font-bold w-10 text-right">{fuel}%</span>
        </div>
      </div>

      {/* Finished screen */}
      {finished ? (
        <div className="bg-slate-900/95 rounded-3xl p-8 border border-purple-800/60 text-center flex flex-col items-center gap-4 shadow-2xl">
          <div className="text-5xl">{planet >= PLANETS.length - 1 ? "🌌" : fuel <= 0 ? "💥" : "🚀"}</div>
          <h2 className="text-3xl font-black bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text text-transparent">
            {planet >= PLANETS.length - 1 ? "Mission Complete!" : fuel <= 0 ? "Out of Fuel!" : "Mission Over"}
          </h2>
          <p className="text-xs text-slate-400 max-w-sm">
            {planet >= PLANETS.length - 1
              ? "You reached Galaxy Hub! Outstanding piloting."
              : fuel <= 0
              ? "Your engines stalled. Refuel by answering correctly and try again!"
              : "Good run! Reach the Galaxy Hub for a massive bonus next time."}
          </p>
          <div className="grid grid-cols-4 gap-3 w-full max-w-md text-xs font-mono">
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="text-[10px] text-slate-400 font-sans">Score</div>
              <div className="text-lg font-black text-cyan-300">{score}</div>
            </div>
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="text-[10px] text-slate-400 font-sans">Accuracy</div>
              <div className="text-lg font-black text-emerald-300">
                {questions.length ? Math.round((correctCount / questions.length) * 100) : 0}%
              </div>
            </div>
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="text-[10px] text-slate-400 font-sans">Coins</div>
              <div className="text-lg font-black text-amber-300">
                +{Math.round(score * 0.4 + (planet === PLANETS.length - 1 ? 50 : 10))}
              </div>
            </div>
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="text-[10px] text-slate-400 font-sans">Planet</div>
              <div className="text-lg font-black text-purple-300">{PLANETS[planet]?.split(" ")[0]}</div>
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <Button onClick={restart} className="bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 text-slate-950 font-black gap-1.5 rounded-2xl">
              <RotateCcw className="w-4 h-4" /> Race Again
            </Button>
            <Button onClick={onExit} variant="outline" className="border-white/10 text-white rounded-2xl">
              Pick another mode
            </Button>
          </div>
        </div>
      ) : (
        /* Question panel */
        <div className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/50 flex flex-col gap-5 shadow-2xl">
          <div className="text-base sm:text-lg font-bold text-white leading-relaxed">{q.text}</div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {q.options.map((opt, i) => {
              const isSelected = selected === i;
              const isCorrect = i === q.correct;
              let cls =
                "p-4 rounded-2xl text-left font-bold text-xs sm:text-sm border transition flex items-center justify-between text-white ";
              if (!showAnswer) {
                cls +=
                  "bg-white/5 hover:bg-white/10 border-white/10 hover:border-cyan-400/60 active:scale-[0.99]";
              } else if (isCorrect) {
                cls += "bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-lg shadow-emerald-500/20";
              } else if (isSelected) {
                cls += "bg-rose-500/25 border-rose-400 text-rose-200";
              } else {
                cls += "bg-white/5 border-white/5 opacity-50";
              }
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    playClick();
                    handlePick(i);
                  }}
                  className={cls}
                >
                  <span className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center font-mono text-[11px] shrink-0">
                      {["A", "B", "C", "D"][i]}
                    </span>
                    <span className="qv-answer-label">{opt}</span>
                  </span>
                  {showAnswer && isCorrect && <span className="text-emerald-300 text-xs">✔</span>}
                  {showAnswer && isSelected && !isCorrect && <span className="text-rose-300 text-xs">✘</span>}
                </button>
              );
            })}
          </div>

          {showAnswer && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-white/5 text-xs">
              <span className="text-slate-300 text-[11px] leading-relaxed">
                {q.explanation || (selected === q.correct ? "Great job!" : "Keep trying — fuel up on the next one.")}
              </span>
              <Button
                onClick={() => {
                  playClick();
                  handleNext();
                }}
                className="bg-gradient-to-r from-purple-500 to-cyan-400 hover:brightness-110 font-black rounded-2xl px-5 text-xs text-slate-950 shrink-0"
              >
                {index + 1 >= questions.length ? "Finish Race →" : "Next Planet →"}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
