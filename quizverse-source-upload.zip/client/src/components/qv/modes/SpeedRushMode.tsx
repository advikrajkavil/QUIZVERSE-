/**
 * Speed Rush — 60-second timed mode. Fast correct answers build combo
 * multipliers (1x -> 2x -> 3x -> 5x); wrong answers reset the combo.
 */

import React, { useEffect, useState, useRef } from "react";
import { QuizDoc, Question } from "@shared/types";
import { recordAnswer, earnCoins, earnXp, finishGameSession } from "@/lib/playerStore";
import { playClick, playCorrect, playWrong, playVictory, playTick, playUrgent } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Zap, Flame, RotateCcw, Timer } from "lucide-react";
import confetti from "canvas-confetti";

export function SpeedRushMode({ quiz, onExit, onComplete }: { quiz: QuizDoc | any; onExit: () => void; onComplete?: (result: { score: number; totalQuestions: number; gameMode: string }) => void }) {
  const baseQuestions: Question[] = quiz.questions || [];
  const questions: Question[] = Array.from({ length: 40 }, (_, i) => baseQuestions[i % baseQuestions.length]);

  const [index, setIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);
  const [score, setScore] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [flash, setFlash] = useState<"correct" | "wrong" | null>(null);
  const [finished, setFinished] = useState(false);
  const [started, setStarted] = useState(false);
  const timerRef = useRef<number | null>(null);

  const q = questions[index % questions.length];
  const mult = combo >= 9 ? 5 : combo >= 5 ? 3 : combo >= 2 ? 2 : 1;

  useEffect(() => {
    if (!started || finished) return;
    timerRef.current = window.setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          end();
          return 0;
        }
        if (t <= 5) playUrgent();
        else if (t <= 10) playTick();
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [started, finished]);

  const end = () => {
    setFinished(true);
    const coins = Math.round(score * 0.05 + correctCount * 2);
    earnCoins(coins);
    earnXp(score + 80);
    finishGameSession({
      gameMode: "speed-rush",
      score,
      totalQuestions: totalCount,
      bonusCoins: coins,
      stats: { combo: maxCombo },
    });
    onComplete?.({ score, totalQuestions: totalCount, gameMode: "speed-rush" });
    if (score >= 1500) {
      try {
        confetti({ particleCount: 80, spread: 80 });
      } catch {}
      playVictory();
    }
  };

  const handlePick = (idx: number) => {
    if (!started || finished || !q) return;
    setTotalCount((t) => t + 1);
    if (idx === q.correct) {
      playCorrect();
      recordAnswer(true);
      const newCombo = combo + 1;
      setCombo(newCombo);
      if (newCombo > maxCombo) setMaxCombo(newCombo);
      setScore((s) => s + 100 * mult);
      setCorrectCount((c) => c + 1);
      setFlash("correct");
    } else {
      playWrong();
      recordAnswer(false);
      setCombo(0);
      setFlash("wrong");
    }
    setTimeout(() => setFlash(null), 250);
    setIndex((i) => i + 1);
  };

  const restart = () => {
    setIndex(0);
    setTimeLeft(60);
    setCombo(0);
    setMaxCombo(0);
    setScore(0);
    setCorrectCount(0);
    setTotalCount(0);
    setFinished(false);
    setStarted(true);
  };

  return (
    <div className="flex flex-col gap-4 max-w-3xl mx-auto w-full">
      {/* Header */}
      <div className="bg-slate-900/90 rounded-3xl p-4 border border-purple-800/50 flex flex-wrap items-center justify-between gap-3 shadow-2xl">
        <div className="flex items-center gap-2">
          <span className="w-8 h-8 rounded-xl bg-cyan-500/30 text-cyan-300 flex items-center justify-center text-lg">🏎️</span>
          <div>
            <span className="font-black text-white text-sm">Speed Rush</span>
            <span className="text-[10px] text-slate-400 block">{quiz.title}</span>
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono">
          <span className="text-cyan-300 font-bold">{score} pts</span>
          <span className="text-purple-300 font-bold flex items-center gap-1">
            <Timer className="w-3.5 h-3.5" /> {timeLeft}s
          </span>
          <span className="px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-extrabold flex items-center gap-1">
            <Flame className="w-3 h-3" /> {mult}x combo
          </span>
        </div>
      </div>

      {!started ? (
        <div className="bg-slate-900/95 rounded-3xl p-10 border border-purple-800/60 text-center flex flex-col items-center gap-4 shadow-2xl">
          <div className="text-5xl">⚡</div>
          <h2 className="text-3xl font-black bg-gradient-to-r from-cyan-300 via-sky-200 to-blue-400 bg-clip-text text-transparent">
            Answer as fast as you can
          </h2>
          <p className="text-xs text-slate-400 max-w-sm">
            60 seconds on the clock. Correct streaks build combos up to 5x. Wrong answers reset the combo.
          </p>
          <Button
            onClick={() => {
              playClick();
              setStarted(true);
            }}
            className="bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 text-slate-950 font-black rounded-2xl px-8 h-12 text-sm shadow-lg shadow-cyan-500/30"
          >
            START RUSH
          </Button>
        </div>
      ) : finished ? (
        <div className="bg-slate-900/95 rounded-3xl p-8 border border-purple-800/60 text-center flex flex-col items-center gap-4 shadow-2xl">
          <div className="text-5xl">{score >= 1500 ? "🏆" : "🏎️"}</div>
          <h2 className="text-3xl font-black bg-gradient-to-r from-cyan-300 via-sky-200 to-blue-400 bg-clip-text text-transparent">
            {score >= 1500 ? "Speed Demon!" : "Time's Up!"}
          </h2>
          <div className="grid grid-cols-4 gap-3 w-full max-w-md text-xs font-mono">
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="text-[10px] text-slate-400 font-sans">Score</div>
              <div className="text-lg font-black text-cyan-300">{score}</div>
            </div>
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="text-[10px] text-slate-400 font-sans">Accuracy</div>
              <div className="text-lg font-black text-emerald-300">
                {totalCount ? Math.round((correctCount / totalCount) * 100) : 0}%
              </div>
            </div>
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="text-[10px] text-slate-400 font-sans">Max combo</div>
              <div className="text-lg font-black text-amber-300">{maxCombo}x</div>
            </div>
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5">
              <div className="text-[10px] text-slate-400 font-sans">Coins</div>
              <div className="text-lg font-black text-purple-300">
                +{Math.round(score * 0.05 + correctCount * 2)}
              </div>
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <Button onClick={restart} className="bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 text-slate-950 font-black gap-1.5 rounded-2xl">
              <RotateCcw className="w-4 h-4" /> Rush Again
            </Button>
            <Button onClick={onExit} variant="outline" className="border-white/10 text-white rounded-2xl">
              Pick another mode
            </Button>
          </div>
        </div>
      ) : (
        <div
          className={`bg-slate-900/90 rounded-3xl p-6 border flex flex-col gap-5 shadow-2xl transition-all ${
            flash === "correct"
              ? "border-emerald-400 shadow-emerald-500/20"
              : flash === "wrong"
              ? "border-rose-400 shadow-rose-500/20"
              : "border-purple-800/50"
          }`}
        >
          {/* Combo bar */}
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400 transition-all duration-200"
                style={{ width: `${Math.min(100, combo * 10)}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-amber-300 font-bold">{combo} streak</span>
          </div>

          <div className="text-base sm:text-lg font-bold text-white leading-relaxed">{q?.text}</div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {q?.options.map((opt, i) => (
              <button
                key={i}
                type="button"
                onClick={() => handlePick(i)}
                className="p-4 rounded-2xl text-left font-bold text-xs sm:text-sm border transition flex items-center justify-between text-white bg-white/5 hover:bg-white/10 border-white/10 hover:border-cyan-400/60 active:scale-[0.99]"
              >
                <span className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center font-mono text-[11px] shrink-0">
                    {["A", "B", "C", "D"][i]}
                  </span>
                  <span className="qv-answer-label">{opt}</span>
                </span>
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-white/5 font-mono">
            <span>#{index + 1} answered</span>
            <span>+{100 * mult} pts per correct answer</span>
          </div>
        </div>
      )}
    </div>
  );
}
