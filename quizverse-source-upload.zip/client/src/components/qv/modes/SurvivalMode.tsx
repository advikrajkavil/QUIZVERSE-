/**
 * Survival — start with 3 lives (hearts). Wrong answers cost a life.
 * Answer streaks can replenish a life. How many questions can you survive?
 */

import React, { useEffect, useState, useRef } from "react";
import { QuizDoc, Question } from "@shared/types";
import { recordAnswer, earnCoins, earnXp, finishGameSession } from "@/lib/playerStore";
import { playClick, playCorrect, playWrong, playVictory, playTick, playLevelUp } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Heart, RotateCcw, Skull } from "lucide-react";
import confetti from "canvas-confetti";

export function SurvivalMode({ quiz, onExit, onComplete }: { quiz: QuizDoc | any; onExit: () => void; onComplete?: (result: { score: number; totalQuestions: number; gameMode: string }) => void }) {
  const baseQuestions: Question[] = quiz.questions || [];
  const questions: Question[] = Array.from({ length: 40 }, (_, i) => baseQuestions[i % baseQuestions.length]);
  const [index, setIndex] = useState(0);
  const [lives, setLives] = useState(3);
  const [streak, setStreak] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [survived, setSurvived] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const [timer, setTimer] = useState(25);
  const timerRef = useRef<number | null>(null);

  const q = questions[index % questions.length];

  useEffect(() => {
    if (!q || showAnswer || finished) return;
    setTimer(q.timeLimit || 25);
    timerRef.current = window.setInterval(() => {
      setTimer((t) => {
        if (t <= 1) {
          handleTimeout();
          return 0;
        }
        if (t <= 6) playTick();
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [index, showAnswer, finished]);

  const handleTimeout = () => {
    setShowAnswer(true);
    playWrong();
    recordAnswer(false);
    loseLife();
  };

  const loseLife = () => {
    const next = lives - 1;
    setLives(next);
    setStreak(0);
    if (next <= 0) end(true);
  };

  const handlePick = (idx: number) => {
    if (showAnswer || finished) return;
    setSelected(idx);
    setShowAnswer(true);
    if (idx === q.correct) {
      playCorrect();
      recordAnswer(true);
      setCorrectCount((c) => c + 1);
      const s = streak + 1;
      setStreak(s);
      if (s > 0 && s % 3 === 0 && lives < 5) {
        setLives((l) => Math.min(5, l + 1));
        playLevelUp();
      }
      setSurvived((v) => v + 1);
    } else {
      playWrong();
      recordAnswer(false);
      loseLife();
    }
  };

  const handleNext = () => {
    setIndex((i) => i + 1);
    setSelected(null);
    setShowAnswer(false);
  };

  const end = (_noLives = false) => {
    setFinished(true);
    const score = survived * 100;
    const coins = Math.round(survived * 6 + (survived >= 12 ? 40 : 5));
    earnCoins(coins);
    earnXp(score + 70);
    finishGameSession({
      gameMode: "survival",
      score,
      totalQuestions: survived,
      bonusCoins: coins,
      stats: { survived },
    });
    onComplete?.({ score, totalQuestions: survived, gameMode: "survival" });
    if (survived >= 12) {
      try {
        confetti({ particleCount: 90, spread: 80 });
      } catch {}
      playVictory();
    }
  };

  const restart = () => {
    setIndex(0);
    setLives(3);
    setStreak(0);
    setSelected(null);
    setShowAnswer(false);
    setSurvived(0);
    setCorrectCount(0);
    setFinished(false);
  };

  if (!q) return null;

  return (
    <div className="flex flex-col gap-4 max-w-3xl mx-auto w-full">
      {/* Header */}
      <div className="bg-slate-900/90 rounded-3xl p-4 border border-purple-800/50 flex flex-wrap items-center justify-between gap-3 shadow-2xl">
        <div className="flex items-center gap-2">
          <span className="w-8 h-8 rounded-xl bg-rose-500/30 text-rose-300 flex items-center justify-center text-lg">🧟</span>
          <div>
            <span className="font-black text-white text-sm">Survival</span>
            <span className="text-[10px] text-slate-400 block">{quiz.title}</span>
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Heart
                key={i}
                className={`w-4 h-4 ${
                  i < lives ? "text-rose-400 fill-rose-400" : "text-slate-700"
                } transition-colors`}
              />
            ))}
          </div>
          <span className="text-cyan-300 font-bold">{survived} survived</span>
          <span className="text-purple-300 font-bold">⏱ {timer}s</span>
        </div>
      </div>

      {finished ? (
        <div className="bg-slate-900/95 rounded-3xl p-8 border border-purple-800/60 text-center flex flex-col items-center gap-4 shadow-2xl">
          <div className="text-5xl">{survived >= 12 ? "🏆" : "💀"}</div>
          <h2 className="text-3xl font-black bg-gradient-to-r from-rose-300 via-pink-200 to-rose-400 bg-clip-text text-transparent">
            {survived >= 12 ? "Survivor Legend!" : "Game Over"}
          </h2>
          <p className="text-xs text-slate-400 max-w-sm">
            You survived <span className="font-mono font-bold text-cyan-300 text-base">{survived}</span> questions.
            Streak 3 refills a life.
          </p>
          <div className="flex items-center gap-3 text-xs font-mono">
            <span className="p-3 rounded-2xl bg-white/5 border border-white/5 text-amber-300 font-bold">
              +{Math.round(survived * 6 + (survived >= 12 ? 40 : 5))} coins
            </span>
            <span className="p-3 rounded-2xl bg-white/5 border border-white/5 text-purple-300 font-bold">
              +{survived * 100 + 70} XP
            </span>
          </div>
          <div className="flex gap-3 pt-2">
            <Button onClick={restart} className="bg-gradient-to-r from-rose-400 to-pink-500 hover:from-rose-300 text-slate-950 font-black gap-1.5 rounded-2xl">
              <RotateCcw className="w-4 h-4" /> Try Again
            </Button>
            <Button onClick={onExit} variant="outline" className="border-white/10 text-white rounded-2xl">
              Pick another mode
            </Button>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/50 flex flex-col gap-5 shadow-2xl">
          <div className="text-base sm:text-lg font-bold text-white leading-relaxed">{q.text}</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {q.options.map((opt, i) => {
              const isSelected = selected === i;
              const isCorrect = i === q.correct;
              let cls =
                "p-4 rounded-2xl text-left font-bold text-xs sm:text-sm border transition flex items-center justify-between text-white ";
              if (!showAnswer) {
                cls += "bg-white/5 hover:bg-white/10 border-white/10 hover:border-cyan-400/60 active:scale-[0.99]";
              } else if (isCorrect) {
                cls += "bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-lg shadow-emerald-500/20";
              } else if (isSelected) {
                cls += "bg-rose-500/25 border-rose-400 text-rose-200";
              } else {
                cls += "bg-white/5 border-white/5 opacity-50";
              }
              return (
                <button key={i} type="button" onClick={() => handlePick(i)} className={cls}>
                  <span className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center font-mono text-[11px] shrink-0">
                      {["A", "B", "C", "D"][i]}
                    </span>
                    <span className="qv-answer-label">{opt}</span>
                  </span>
                  {showAnswer && isCorrect && <span className="text-emerald-300 text-xs">✔</span>}
                  {showAnswer && isSelected && !isCorrect && <span className="text-rose-300 text-xs">✘</span>}
                </button>
              );
            })}
          </div>
          {showAnswer && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-white/5 text-xs">
              <span className="text-slate-300 text-[11px] leading-relaxed">
                {q.explanation || (selected === q.correct ? "Survived! Keep going." : "A life was lost. Answer 3 in a row to earn one back.")}
              </span>
              <Button onClick={handleNext} className="bg-gradient-to-r from-rose-400 to-pink-500 hover:from-rose-300 font-black rounded-2xl px-5 text-xs text-slate-950 shrink-0">
                Continue →
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
