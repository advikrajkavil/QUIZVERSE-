/**
 * Tower Battle — answer correctly to stack colourful blocks into a tower.
 * Wrong answers crack and remove blocks. Finish with the tallest tower for
 * bonus coins.
 */

import React, { useEffect, useState, useRef } from "react";
import { QuizDoc, Question } from "@shared/types";
import { recordAnswer, earnCoins, earnXp, finishGameSession } from "@/lib/playerStore";
import { playClick, playCorrect, playWrong, playVictory, playTick } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Castle, RotateCcw } from "lucide-react";
import confetti from "canvas-confetti";

const BLOCK_COLORS = [
  "from-violet-500 to-purple-600",
  "from-indigo-500 to-blue-600",
  "from-cyan-400 to-teal-500",
  "from-emerald-400 to-green-600",
  "from-amber-400 to-yellow-500",
  "from-orange-500 to-red-500",
  "from-pink-500 to-rose-600",
];

export function TowerBattleMode({ quiz, onExit, onComplete }: { quiz: QuizDoc | any; onExit: () => void; onComplete?: (result: { score: number; totalQuestions: number; gameMode: string }) => void }) {
  const baseQuestions: Question[] = quiz.questions || [];
  const questions: Question[] = Array.from({ length: 25 }, (_, i) => baseQuestions[i % baseQuestions.length]);
  const [index, setIndex] = useState(0);
  const [blocks, setBlocks] = useState<number[]>([]); // color indexes
  const [selected, setSelected] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [wobble, setWobble] = useState(false);
  const [timer, setTimer] = useState(25);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const timerRef = useRef<number | null>(null);

  const q = questions[index % questions.length];

  useEffect(() => {
    if (!q || showAnswer || finished) return;
    setTimer(q.timeLimit || 25);
    timerRef.current = window.setInterval(() => {
      setTimer((t) => {
        if (t <= 1) {
          handleTimeout();
          return 0;
        }
        if (t <= 6) playTick();
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [index, showAnswer, finished]);

  const handleTimeout = () => {
    setShowAnswer(true);
    playWrong();
    recordAnswer(false);
    shakeAndDamage();
  };

  const shakeAndDamage = () => {
    setWobble(true);
    setTimeout(() => setWobble(false), 500);
    setBlocks((b) => b.slice(0, Math.max(0, b.length - 1)));
  };

  const handlePick = (idx: number) => {
    if (showAnswer || finished) return;
    setSelected(idx);
    setShowAnswer(true);
    if (idx === q.correct) {
      playCorrect();
      recordAnswer(true);
      setBlocks((b) => [...b, Math.floor(Math.random() * BLOCK_COLORS.length)]);
      setCorrectCount((c) => c + 1);
    } else {
      playWrong();
      recordAnswer(false);
      shakeAndDamage();
    }
  };

  const handleNext = () => {
    if (index + 1 >= Math.min(questions.length, 15)) {
      end();
      return;
    }
    setIndex((i) => i + 1);
    setSelected(null);
    setShowAnswer(false);
  };

  const end = () => {
    setFinished(true);
    const score = blocks.length * 100;
    const coins = Math.round(blocks.length * 8 + (blocks.length >= 10 ? 50 : 5));
    earnCoins(coins);
    earnXp(score + 60);
    finishGameSession({
      gameMode: "tower-battle",
      score,
      totalQuestions: Math.min(questions.length, 15),
      bonusCoins: coins,
      stats: { height: blocks.length },
    });
    onComplete?.({ score, totalQuestions: Math.min(questions.length, 15), gameMode: "tower-battle" });
    if (blocks.length >= 8) {
      try {
        confetti({ particleCount: 90, spread: 80 });
      } catch {}
      playVictory();
    }
  };

  const restart = () => {
    setIndex(0);
    setBlocks([]);
    setSelected(null);
    setShowAnswer(false);
    setCorrectCount(0);
    setFinished(false);
  };

  if (!q) return null;

  return (
    <div className="flex flex-col gap-4 max-w-4xl mx-auto w-full">
      {/* Header */}
      <div className="bg-slate-900/90 rounded-3xl p-4 border border-purple-800/50 flex flex-wrap items-center justify-between gap-3 shadow-2xl">
        <div className="flex items-center gap-2">
          <span className="w-8 h-8 rounded-xl bg-purple-500/30 text-purple-300 flex items-center justify-center text-lg">🏰</span>
          <div>
            <span className="font-black text-white text-sm">Tower Battle</span>
            <span className="text-[10px] text-slate-400 block">{quiz.title}</span>
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono">
          <span className="text-cyan-300 font-bold">{blocks.length} blocks tall</span>
          <span className="text-purple-300 font-bold">⏱ {timer}s</span>
          <span className="text-slate-400 text-[11px]">Q{index + 1}/15</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_240px] gap-4">
        {finished ? (
          <div className="bg-slate-900/95 rounded-3xl p-8 border border-purple-800/60 text-center flex flex-col items-center gap-4 shadow-2xl">
            <div className="text-5xl">{blocks.length >= 10 ? "🏆" : blocks.length >= 5 ? "🏰" : "🧱"}</div>
            <h2 className="text-3xl font-black bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text text-transparent">
              {blocks.length >= 10 ? "Tower Master!" : "Tower Finished!"}
            </h2>
            <p className="text-xs text-slate-400 max-w-sm">
              Your tower reached <span className="font-mono font-bold text-cyan-300 text-base">{blocks.length}</span> blocks high.
            </p>
            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="p-3 rounded-2xl bg-white/5 border border-white/5 text-amber-300 font-bold">
                +{Math.round(blocks.length * 8 + (blocks.length >= 10 ? 50 : 5))} coins
              </span>
              <span className="p-3 rounded-2xl bg-white/5 border border-white/5 text-purple-300 font-bold">
                +{blocks.length * 100 + 60} XP
              </span>
            </div>
            <div className="flex gap-3 pt-2">
              <Button onClick={restart} className="bg-gradient-to-r from-purple-500 to-cyan-400 hover:brightness-110 text-slate-950 font-black gap-1.5 rounded-2xl">
                <RotateCcw className="w-4 h-4" /> Build Again
              </Button>
              <Button onClick={onExit} variant="outline" className="border-white/10 text-white rounded-2xl">
                Pick another mode
              </Button>
            </div>
          </div>
        ) : (
          <div className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/50 flex flex-col gap-5 shadow-2xl">
            <div className="text-base sm:text-lg font-bold text-white leading-relaxed">{q.text}</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {q.options.map((opt, i) => {
                const isSelected = selected === i;
                const isCorrect = i === q.correct;
                let cls =
                  "p-4 rounded-2xl text-left font-bold text-xs sm:text-sm border transition flex items-center justify-between text-white ";
                if (!showAnswer) {
                  cls += "bg-white/5 hover:bg-white/10 border-white/10 hover:border-cyan-400/60 active:scale-[0.99]";
                } else if (isCorrect) {
                  cls += "bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-lg shadow-emerald-500/20";
                } else if (isSelected) {
                  cls += "bg-rose-500/25 border-rose-400 text-rose-200";
                } else {
                  cls += "bg-white/5 border-white/5 opacity-50";
                }
                return (
                  <button key={i} type="button" onClick={() => handlePick(i)} className={cls}>
                    <span className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center font-mono text-[11px] shrink-0">
                        {["A", "B", "C", "D"][i]}
                      </span>
                      <span className="qv-answer-label">{opt}</span>
                    </span>
                    {showAnswer && isCorrect && <span className="text-emerald-300 text-xs">✔</span>}
                    {showAnswer && isSelected && !isCorrect && <span className="text-rose-300 text-xs">✘</span>}
                  </button>
                );
              })}
            </div>
            {showAnswer && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-white/5 text-xs">
                <span className="text-slate-300 text-[11px] leading-relaxed">
                  {q.explanation || (selected === q.correct ? "Another block added!" : "Tower cracked — answer correctly to rebuild.")}
                </span>
                <Button onClick={handleNext} className="bg-gradient-to-r from-purple-500 to-cyan-400 hover:brightness-110 font-black rounded-2xl px-5 text-xs text-slate-950 shrink-0">
                  {index + 1 >= 15 ? "Finish Tower →" : "Next Question →"}
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Tower visual */}
        <div className="bg-slate-900/90 rounded-3xl p-4 border border-purple-800/50 flex flex-col justify-end items-center gap-1 min-h-[380px] shadow-2xl relative overflow-hidden">
          <div className="absolute top-3 left-4 text-[10px] font-black uppercase text-slate-400">
            Tower height
          </div>
          <div className={`w-full flex flex-col-reverse items-center gap-1 max-h-[320px] overflow-y-auto px-4 ${wobble ? "animate-pulse" : ""}`}>
            {blocks.map((cIdx, i) => (
              <div
                key={i}
                className={`w-full max-w-[170px] h-6 rounded-lg bg-gradient-to-r ${BLOCK_COLORS[cIdx]} shadow-md border border-white/20 transition-all flex items-center justify-center text-[10px] font-mono font-bold text-white`}
              >
                #{i + 1}
              </div>
            ))}
          </div>
          {/* Ground */}
          <div className="w-full h-3 rounded-full bg-slate-800 border border-purple-800/60 mt-1" />
        </div>
      </div>
    </div>
  );
}
