/**
 * QUIZVERSE player store — persistent local player profile with coins, XP,
 * levels, streaks, equipped avatar/theme, and inventory.
 */

import { PlayerStats } from "@shared/types";
import { AVATARS, levelFromXp, rankFromXp, THEMES } from "./quizverseData";
import { playLevelUp } from "./sounds";

const KEY = "quizverse_player_v1";
const UI_MODE_KEY = "quizverse_ui_mode_v1";

export type UiMode = "dark" | "light";

const DEFAULT_STATS: PlayerStats = {
  id: "guest-" + Math.random().toString(36).slice(2, 10),
  name: "Quiz Pilot",
  avatar: "🚀",
  theme: "nebula",
  coins: 100, // starter coins
  xp: 0,
  level: 1,
  rankTitle: "Novice",
  streak: 0,
  bestStreak: 0,
  gamesPlayed: 0,
  bestScore: 0,
  bestScoreMode: undefined,
  correctAnswers: 0,
  totalAnswers: 0,
  avatarsOwned: ["rocket"],
  badgesOwned: [],
  themesOwned: ["nebula"],
  dailyCompletedAt: undefined,
  updatedAt: new Date().toISOString(),
};

type Listener = () => void;
const listeners = new Set<Listener>();

function load(): PlayerStats {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_STATS;
    const s = JSON.parse(raw);
    return { ...DEFAULT_STATS, ...s, avatarsOwned: s.avatarsOwned || ["rocket"], badgesOwned: s.badgesOwned || [], themesOwned: s.themesOwned || ["nebula"] };
  } catch {
    return DEFAULT_STATS;
  }
}

let state: PlayerStats = load();

function save() {
  state.level = levelFromXp(state.xp);
  state.rankTitle = rankFromXp(state.xp).name;
  state.updatedAt = new Date().toISOString();
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {}
  listeners.forEach((l) => l());
}

export function getPlayer(): PlayerStats {
  return state;
}

export function subscribePlayer(fn: Listener): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function setName(name: string) {
  state.name = (name || "Player").trim().slice(0, 32);
  save();
}

export function earnCoins(amount: number) {
  if (amount <= 0) return;
  state.coins += amount;
  save();
}

export function earnXp(amount: number) {
  if (amount <= 0) return;
  const prevLevel = state.level;
  state.xp += amount;
  state.level = levelFromXp(state.xp);
  if (state.level > prevLevel) playLevelUp();
  save();
}

export function recordAnswer(correct: boolean) {
  state.totalAnswers += 1;
  state.gamesPlayed = state.gamesPlayed + (state.totalAnswers % 10 === 0 ? 1 : 0);
  if (correct) {
    state.correctAnswers += 1;
    state.streak += 1;
    if (state.streak > state.bestStreak) state.bestStreak = state.streak;
    state.coins += 5;
    state.xp += 15;
    if (state.streak >= 10 && !state.badgesOwned.includes("streak-master")) unlockBadge("streak-master");
  } else {
    state.streak = 0;
    state.xp += 3;
  }
  save();
}

export function finishGameSession(opts: {
  gameMode: string;
  score: number;
  totalQuestions: number;
  bonusCoins?: number;
  stats?: Record<string, number>;
}) {
  if (opts.score > state.bestScore) {
    state.bestScore = opts.score;
    state.bestScoreMode = opts.gameMode;
  }
  const bonus = opts.bonusCoins ?? Math.max(0, Math.floor(opts.score * 0.1));
  earnCoins(bonus);
  earnXp(Math.max(10, Math.floor(opts.score * 0.15)));
  if (!state.badgesOwned.includes("first-win")) {
    const accuracy = opts.totalQuestions ? Math.round((opts.score / (opts.totalQuestions * 100)) * 100) : 0;
    if (accuracy >= 80) unlockBadge("first-win");
  }
  if (opts.gameMode === "space-race" && (opts.stats?.fuelRemaining ?? 0) >= 100) unlockBadge("space-ace");
  if (opts.gameMode === "millionaire" && opts.score >= 1000000) unlockBadge("millionaire");
  if (opts.gameMode === "speed-rush" && (opts.stats?.combo ?? 0) >= 5) unlockBadge("speed-demon");
  if (opts.gameMode === "tower-battle" && (opts.stats?.height ?? 0) >= 10) unlockBadge("tower-builder");
  if (opts.gameMode === "survival" && (opts.stats?.survived ?? 0) >= 12) unlockBadge("survivalist");
}

export function unlockBadge(badgeId: string) {
  if (state.badgesOwned.includes(badgeId)) return;
  state.badgesOwned = [...state.badgesOwned, badgeId];
  state.coins += 25;
  state.xp += 50;
  save();
}

export function buyAvatar(avatarId: string): boolean {
  const a = AVATARS.find((x) => x.id === avatarId);
  if (!a) return false;
  if (state.avatarsOwned.includes(avatarId)) return false;
  if (state.coins < a.price) return false;
  state.coins -= a.price;
  state.avatarsOwned = [...state.avatarsOwned, avatarId];
  save();
  return true;
}

export function equipAvatar(emoji: string) {
  state.avatar = emoji;
  save();
}

export function buyTheme(themeId: string): boolean {
  const t = THEMES.find((x) => x.id === themeId);
  if (!t) return false;
  if (state.themesOwned.includes(themeId)) return false;
  if (state.coins < t.price) return false;
  state.coins -= t.price;
  state.themesOwned = [...state.themesOwned, themeId];
  save();
  return true;
}

export function equipTheme(themeId: string) {
  state.theme = themeId;
  applyTheme(themeId);
  save();
}

export function applyTheme(themeId: string) {
  const t = THEMES.find((x) => x.id === themeId) || THEMES[0];
  document.documentElement.style.setProperty("--qv-gradient", t.gradient);
  document.documentElement.style.setProperty("--qv-accent", t.accent);
  const glows: Record<string, [string, string]> = {
    nebula: ["rgba(168,85,247,.28)", "rgba(14,165,233,.18)"],
    cyan: ["rgba(6,182,212,.26)", "rgba(59,130,246,.18)"],
    solar: ["rgba(245,158,11,.28)", "rgba(244,63,94,.15)"],
    midnight: ["rgba(129,140,248,.22)", "rgba(30,41,59,.28)"],
  };
  const [a, b] = glows[themeId] || glows.nebula;
  document.documentElement.style.setProperty("--qv-glow-a", a);
  document.documentElement.style.setProperty("--qv-glow-b", b);
}

export function getUiMode(): UiMode {
  try {
    return localStorage.getItem(UI_MODE_KEY) === "light" ? "light" : "dark";
  } catch {
    return "dark";
  }
}

export function applyUiMode(mode: UiMode) {
  document.documentElement.dataset.qvMode = mode;
  try {
    localStorage.setItem(UI_MODE_KEY, mode);
  } catch {}
}

export function completeDailyChallenge(): boolean {
  const today = new Date().toISOString().slice(0, 10);
  if (state.dailyCompletedAt === today) return false;
  state.dailyCompletedAt = today;
  state.coins += 100;
  state.xp += 200;
  save();
  return true;
}

export function resetPlayer() {
  state = { ...DEFAULT_STATS };
  save();
}
