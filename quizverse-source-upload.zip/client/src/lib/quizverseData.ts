/**
 * QUIZVERSE catalogs: subjects, avatars (blooks), badges, themes, ranks.
 */

import { AvatarItem, BadgeItem, GradeBand, Subject, ThemeItem } from "@shared/types";

export const GRADE_BANDS: Array<{ id: GradeBand; label: string; short: string; description: string }> = [
  { id: "nursery", label: "Nursery", short: "Nursery", description: "Playful foundations for language, counting, colors, shapes, and discovery." },
  { id: "grade1", label: "Grade 1", short: "Grade 1", description: "Early reading, number sense, nature, community, and creative confidence." },
  { id: "grade2", label: "Grade 2", short: "Grade 2", description: "Growing fluency in reading, mathematics, science, and everyday problem solving." },
  { id: "3-5", label: "Grades 3–5", short: "3–5", description: "Elementary concepts, fluency, and curious exploration." },
  { id: "6-8", label: "Grades 6–8", short: "6–8", description: "Middle-school skills, reasoning, and deeper explanations." },
  { id: "9-12", label: "Grades 9–12", short: "9–12", description: "High-school content, analysis, and exam readiness." },
];

export const GRADE_MAP = new Map(GRADE_BANDS.map((g) => [g.id, g]));

export interface SubjectMeta {
  id: Subject;
  name: string;
  icon: string;
  color: string; // hex
  gradient: string; // tailwind gradient
  badgeBg: string;
  badgeText: string;
  description: string;
}

export const SUBJECTS: SubjectMeta[] = [
  {
    id: "science",
    name: "Science",
    icon: "🔬",
    color: "#10B981",
    gradient: "from-emerald-400 to-teal-500",
    badgeBg: "bg-emerald-100",
    badgeText: "text-emerald-700",
    description: "Biology, chemistry, physics, space, and the living world.",
  },
  {
    id: "math",
    name: "Mathematics",
    icon: "📐",
    color: "#3B82F6",
    gradient: "from-blue-400 to-indigo-500",
    badgeBg: "bg-blue-100",
    badgeText: "text-blue-700",
    description: "Arithmetic, fractions, percentages, geometry, and logic.",
  },
  {
    id: "english",
    name: "English",
    icon: "📖",
    color: "#EC4899",
    gradient: "from-pink-400 to-rose-500",
    badgeBg: "bg-pink-100",
    badgeText: "text-pink-700",
    description: "Vocabulary, grammar, reading comprehension, and idioms.",
  },
  {
    id: "social",
    name: "Social Studies",
    icon: "🌍",
    color: "#F59E0B",
    gradient: "from-amber-400 to-orange-500",
    badgeBg: "bg-amber-100",
    badgeText: "text-amber-800",
    description: "World geography, ancient civilizations, history, and civics.",
  },
  {
    id: "cs",
    name: "Computer Science",
    icon: "💻",
    color: "#8B5CF6",
    gradient: "from-purple-400 to-violet-600",
    badgeBg: "bg-purple-100",
    badgeText: "text-purple-700",
    description: "Coding concepts, algorithms, data structures, and the web.",
  },
];

export const SUBJECT_MAP = new Map(SUBJECTS.map((s) => [s.id, s]));

export const AVATARS: AvatarItem[] = [
  { id: "rocket", name: "Star Rocket", emoji: "🚀", price: 0, tier: "Starter", description: "Standard-issue Quizverse pilot." },
  { id: "brain", name: "Big Brain", emoji: "🧠", price: 80, tier: "Starter", description: "Packed with trivia knowledge." },
  { id: "owl", name: "Wise Owl", emoji: "🦉", price: 150, tier: "Starter", description: "Studies day and night." },
  { id: "cat", name: "Lucky Cat", emoji: "🐱", price: 250, tier: "Rare", description: "Brings good fortunes to quizzes." },
  { id: "robot", name: "Quiz Bot", emoji: "🤖", price: 400, tier: "Rare", description: "Processes answers in milliseconds." },
  { id: "fox", name: "Clever Fox", emoji: "🦊", price: 550, tier: "Rare", description: "Always one step ahead." },
  { id: "lion", name: "Brave Lion", emoji: "🦁", price: 800, tier: "Epic", description: "Roars at the leaderboard." },
  { id: "dragon", name: "Quiz Dragon", emoji: "🐉", price: 1200, tier: "Epic", description: "Breathes fire, aces tests." },
  { id: "unicorn", name: "Unicorn", emoji: "🦄", price: 1800, tier: "Legendary", description: "Rarest of all quiz creatures." },
  { id: "crown", name: "Golden Crown", emoji: "👑", price: 2500, tier: "Legendary", description: "Worn only by the best." },
];

export const BADGES: BadgeItem[] = [
  { id: "first-win", name: "First Victory", icon: "🥇", description: "Win your first quiz with a score of 80%+.", category: "progression" },
  { id: "space-ace", name: "Space Ace", icon: "🚀", description: "Complete a Space Race with 100% fuel remaining.", category: "gameplay" },
  { id: "millionaire", name: "Millionaire", icon: "💰", description: "Win $1,000,000 in Quiz Millionaire mode.", category: "gameplay" },
  { id: "speed-demon", name: "Speed Demon", icon: "🏎️", description: "Finish a Speed Rush with a 5x combo multiplier.", category: "gameplay" },
  { id: "tower-builder", name: "Tower Builder", icon: "🏰", description: "Build a tower of 10+ blocks without falling.", category: "gameplay" },
  { id: "survivalist", name: "Survivalist", icon: "🧟", description: "Survive 12 questions in Survival mode.", category: "gameplay" },
  { id: "streak-master", name: "Streak Master", icon: "🔥", description: "Answer 10 questions correctly in a row.", category: "streak" },
  { id: "quiz-maker", name: "Quiz Maker", icon: "✏️", description: "Create and publish your own quiz.", category: "social" },
];

export const THEMES: ThemeItem[] = [
  { id: "nebula", name: "Nebula Purple", description: "Deep space purple with cyan stars — the signature Quizverse look.", price: 0, gradient: "from-[#4b1d7f] via-[#6d28d9] to-[#0ea5e9]", accent: "#a855f7" },
  { id: "cyan", name: "Cyber Cyan", description: "Electric blue and teal like a hologram dashboard.", price: 300, gradient: "from-[#0f172a] via-[#0e7490] to-[#06b6d4]", accent: "#06b6d4" },
  { id: "solar", name: "Solar Gold", description: "Warm amber and orange bursting with energy.", price: 500, gradient: "from-[#451a03] via-[#b45309] to-[#f59e0b]", accent: "#f59e0b" },
  { id: "midnight", name: "Midnight Stealth", description: "Dark sleek backdrop with neon accents for focus.", price: 700, gradient: "from-[#030712] via-[#111827] to-[#1f2937]", accent: "#818cf8" },
];

export interface RankTier {
  name: string;
  minXp: number;
  icon: string;
  color: string;
}

export const RANK_TIERS: RankTier[] = [
  { name: "Novice", minXp: 0, icon: "🌱", color: "#10b981" },
  { name: "Scholar", minXp: 500, icon: "📚", color: "#3b82f6" },
  { name: "Champion", minXp: 1500, icon: "⚔️", color: "#8b5cf6" },
  { name: "Master Mind", minXp: 3500, icon: "🧠", color: "#ec4899" },
  { name: "Grand Champion", minXp: 7000, icon: "👑", color: "#f59e0b" },
];

export function rankFromXp(xp: number): RankTier {
  let r = RANK_TIERS[0];
  for (const tier of RANK_TIERS) {
    if (xp >= tier.minXp) r = tier;
  }
  return r;
}

export function levelFromXp(xp: number): number {
  return Math.max(1, Math.floor(Math.sqrt(xp / 100)) + 1);
}

export function xpForNextLevel(level: number): number {
  return level * level * 100;
}
