/**
 * QUIZVERSE sound effects — Web Audio synthesised chimes, buzzes,
 * countdown ticks, level-up fanfares, and clicks.
 */

let ctx: AudioContext | null = null;
let enabled = true;
let musicEnabled = false;
let musicTimer: number | null = null;
let musicStep = 0;

function ac(): AudioContext | null {
  if (!enabled) return null;
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      ctx = new AC();
    }
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

export function setSoundsEnabled(on: boolean) {
  enabled = on;
  if (!on) setMusicEnabled(false);
}

export function isSoundsEnabled(): boolean {
  return enabled;
}

export function isMusicEnabled(): boolean {
  return musicEnabled;
}

function playMusicBar() {
  const c = ac();
  if (!c || !musicEnabled) return;
  const notes = [261.63, 329.63, 392, 493.88, 392, 329.63];
  const t = c.currentTime;
  for (let i = 0; i < 6; i++) {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = "sine";
    o.frequency.value = notes[(musicStep + i) % notes.length];
    const start = t + i * 0.38;
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(0.035, start + 0.06);
    g.gain.exponentialRampToValueAtTime(0.0001, start + 0.34);
    o.connect(g);
    g.connect(c.destination);
    o.start(start);
    o.stop(start + 0.36);
  }
  musicStep = (musicStep + 1) % notes.length;
}

export function setMusicEnabled(on: boolean) {
  musicEnabled = on;
  if (!on) {
    if (musicTimer !== null) window.clearInterval(musicTimer);
    musicTimer = null;
    return;
  }
  if (!enabled || musicTimer !== null) return;
  playMusicBar();
  musicTimer = window.setInterval(playMusicBar, 2280);
}

export function playClick() {
  const c = ac();
  if (!c) return;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = "sine";
  o.frequency.setValueAtTime(800, c.currentTime);
  o.frequency.exponentialRampToValueAtTime(300, c.currentTime + 0.04);
  g.gain.setValueAtTime(0.12, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.05);
  o.connect(g);
  g.connect(c.destination);
  o.start(c.currentTime);
  o.stop(c.currentTime + 0.05);
}

export function playCorrect() {
  const c = ac();
  if (!c) return;
  const notes = [523.25, 659.25, 783.99, 1046.5]; // C5 E5 G5 C6 arpeggio
  notes.forEach((f, i) => {
    const o = c.createOscillator();
    const g = c.createGain();
    const t = c.currentTime + i * 0.07;
    o.type = "sine";
    o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.22, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    o.connect(g);
    g.connect(c.destination);
    o.start(t);
    o.stop(t + 0.3);
  });
}

export function playWrong() {
  const c = ac();
  if (!c) return;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = "sawtooth";
  o.frequency.setValueAtTime(190, c.currentTime);
  o.frequency.linearRampToValueAtTime(110, c.currentTime + 0.35);
  g.gain.setValueAtTime(0.25, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.35);
  o.connect(g);
  g.connect(c.destination);
  o.start(c.currentTime);
  o.stop(c.currentTime + 0.35);
}

export function playTick() {
  const c = ac();
  if (!c) return;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = "square";
  o.frequency.value = 1000;
  g.gain.setValueAtTime(0.08, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.03);
  o.connect(g);
  g.connect(c.destination);
  o.start(c.currentTime);
  o.stop(c.currentTime + 0.03);
}

export function playUrgent() {
  const c = ac();
  if (!c) return;
  for (let i = 0; i < 2; i++) {
    const o = c.createOscillator();
    const g = c.createGain();
    const t = c.currentTime + i * 0.08;
    o.type = "square";
    o.frequency.value = 1200;
    g.gain.setValueAtTime(0.12, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    o.connect(g);
    g.connect(c.destination);
    o.start(t);
    o.stop(t + 0.05);
  }
}

export function playVictory() {
  const c = ac();
  if (!c) return;
  const notes = [523.25, 523.25, 523.25, 659.25, 783.99, 1046.5];
  const times = [0, 0.12, 0.24, 0.36, 0.52, 0.72];
  notes.forEach((f, i) => {
    const o = c.createOscillator();
    const g = c.createGain();
    const t = c.currentTime + times[i];
    o.type = "triangle";
    o.frequency.value = f;
    g.gain.setValueAtTime(0.001, t);
    g.gain.exponentialRampToValueAtTime(0.3, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
    o.connect(g);
    g.connect(c.destination);
    o.start(t);
    o.stop(t + 0.6);
  });
}

export function playLevelUp() {
  const c = ac();
  if (!c) return;
  const notes = [440, 554.37, 659.25, 880];
  notes.forEach((f, i) => {
    const o = c.createOscillator();
    const g = c.createGain();
    const t = c.currentTime + i * 0.1;
    o.type = "sine";
    o.frequency.value = f;
    g.gain.setValueAtTime(0.001, t);
    g.gain.exponentialRampToValueAtTime(0.28, t + 0.03);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
    o.connect(g);
    g.connect(c.destination);
    o.start(t);
    o.stop(t + 0.5);
  });
}
