/**
 * QUIZVERSE Compete — live room hosting/joining, global & weekly leaderboards,
 * rank tiers, and tournament schedule.
 */

import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/qv/Navbar";
import { PinJoinDialog } from "@/components/qv/PinJoinDialog";
import { RANK_TIERS, RankTier } from "@/lib/quizverseData";
import { getPlayer } from "@/lib/playerStore";
import { playClick } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Trophy, Crown, Flame, Users, Calendar, ArrowRight, Loader2, Sparkles } from "lucide-react";

export default function Compete() {
  const [, setLocation] = useLocation();
  const [pinOpen, setPinOpen] = useState(false);
  const [period, setPeriod] = useState<"weekly" | "alltime">("weekly");
  const [selectedQuizId, setSelectedQuizId] = useState<number | null>(null);
  const [hostName, setHostName] = useState(getPlayer().name || "Host");
  const [hostError, setHostError] = useState<string | null>(null);

  const quizzesQuery = trpc.quizzes.list.useQuery({ limit: 40 });
  const leadersQuery = trpc.leaderboard.list.useQuery({ period, limit: 30 });
  const createRoom = trpc.rooms.create.useMutation();

  const quizzes = quizzesQuery.data || [];
  const leaders = leadersQuery.data || [];

  const handleHost = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    setHostError(null);
    if (!selectedQuizId) {
      setHostError("Pick a quiz to host");
      return;
    }
    try {
      const room = await createRoom.mutateAsync({
        quizId: selectedQuizId,
        hostName: (hostName || "Host").trim().slice(0, 32),
      });
      if (room?.code) setLocation(`/live/host/${room.code}`);
    } catch {
      setHostError("Could not create room. Try again.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenPin={() => setPinOpen(true)} />
      <PinJoinDialog open={pinOpen} onOpenChange={setPinOpen} />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-8">
        {/* Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500/30 via-purple-600/30 to-cyan-500/30 p-6 sm:p-8 border border-amber-400/30 flex flex-col gap-2 shadow-xl">
          <span className="text-[10px] font-black uppercase tracking-wider text-amber-300">🏆 Competition Arena</span>
          <h1 className="text-2xl sm:text-4xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
            Host live games. Climb the leaderboards.
          </h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Kahoot-style live competitions with 6-digit PIN codes for schools and friends, plus global weekly tournaments.
          </p>
        </div>

        {/* Live game cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Host card */}
          <div className="rounded-3xl bg-slate-900/90 border border-purple-800/60 p-6 flex flex-col gap-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <span className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center text-2xl shadow">
                🎤
              </span>
              <div>
                <h3 className="text-lg font-black text-white">Host a Live Game</h3>
                <p className="text-[11px] text-slate-400">Pick any quiz and share your PIN with players</p>
              </div>
            </div>

            <form onSubmit={handleHost} className="flex flex-col gap-3 text-xs">
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Select quiz</label>
                <select
                  value={selectedQuizId ?? ""}
                  onChange={(e) => setSelectedQuizId(Number(e.target.value) || null)}
                  className="mt-1 w-full py-2.5 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-bold text-xs focus:outline-none focus:border-cyan-400"
                >
                  <option value="" className="bg-slate-900">Choose a quiz…</option>
                  {quizzes.map((q) => (
                    <option key={q.id} value={q.id} className="bg-slate-900">
                      {q.title} ({q.subject} · {q.questions?.length || 0} Q)
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Host name</label>
                <input
                  type="text"
                  maxLength={32}
                  value={hostName}
                  onChange={(e) => setHostName(e.target.value)}
                  className="mt-1 w-full py-2.5 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-bold text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              {hostError && <div className="text-xs text-rose-400 font-semibold">{hostError}</div>}

              <Button
                type="submit"
                disabled={createRoom.isPending}
                className="w-full h-11 rounded-2xl bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 hover:brightness-110 text-white font-black text-xs shadow-lg shadow-purple-500/30"
              >
                {createRoom.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "START HOSTING →"}
              </Button>
            </form>
          </div>

          {/* Join card */}
          <div className="rounded-3xl bg-slate-900/90 border border-cyan-800/60 p-6 flex flex-col gap-4 justify-between shadow-2xl">
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <span className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-2xl text-slate-950 shadow">
                  👥
                </span>
                <div>
                  <h3 className="text-lg font-black text-white">Join with PIN</h3>
                  <p className="text-[11px] text-slate-400">Enter a code your host gave you</p>
                </div>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Connect from any device. Answer questions in sync with the room, race the clock, and see your rank climb on the live scoreboard.
              </p>
            </div>
            <div className="flex flex-col gap-2">
              <Button
                onClick={() => setPinOpen(true)}
                className="w-full h-11 rounded-2xl bg-cyan-300 hover:bg-cyan-200 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/30"
              >
                ENTER GAME PIN
              </Button>
              <Link
                href="/live"
                className="text-center text-[11px] text-slate-400 hover:text-white underline font-semibold"
              >
                Open full join page →
              </Link>
            </div>
          </div>
        </div>

        {/* TOURNAMENT BANNER */}
        <section className="rounded-3xl bg-gradient-to-r from-purple-800/50 via-indigo-800/40 to-slate-900 border border-purple-700/60 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🗓️</span>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-purple-300 flex items-center gap-1">
                <Calendar className="w-3 h-3" /> Weekly Tournament
              </span>
              <h3 className="text-base font-black text-white">Solar System Cup · Science Week</h3>
              <p className="text-[11px] text-slate-300">Play the featured space quiz this week. Top 3 scores win 500 bonus coins.</p>
            </div>
          </div>
          <Link
            href="/play/science-solar-system/space-race"
            className="px-5 py-2.5 rounded-full bg-cyan-300 hover:bg-cyan-200 text-slate-950 font-black text-xs shrink-0 shadow"
          >
            Enter Tournament →
          </Link>
        </section>

        {/* LEADERBOARD */}
        <section className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
                <Crown className="w-6 h-6 text-amber-400" /> Leaderboard
              </h2>
              <p className="text-xs text-slate-400">Scores sync from both solo and live games.</p>
            </div>
            <div className="flex items-center gap-1 bg-white/5 p-1 rounded-full border border-white/10 text-xs">
              <button
                onClick={() => {
                  playClick();
                  setPeriod("weekly");
                }}
                className={`px-3 py-1 rounded-full font-bold transition ${
                  period === "weekly" ? "bg-amber-400 text-slate-950" : "text-slate-300"
                }`}
              >
                Weekly
              </button>
              <button
                onClick={() => {
                  playClick();
                  setPeriod("alltime");
                }}
                className={`px-3 py-1 rounded-full font-bold transition ${
                  period === "alltime" ? "bg-amber-400 text-slate-950" : "text-slate-300"
                }`}
              >
                All-time
              </button>
            </div>
          </div>

          <div className="bg-slate-900/90 rounded-3xl border border-purple-800/50 overflow-hidden shadow-2xl">
            <div className="divide-y divide-white/5">
              {leadersQuery.isLoading ? (
                <div className="p-12 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" /> Loading leaderboard…
                </div>
              ) : leaders.length === 0 ? (
                <div className="p-12 text-center text-xs text-slate-400">No entries yet. Be the first to place!</div>
              ) : (
                leaders.map((e, i) => (
                  <div
                    key={e.id}
                    className="p-3.5 sm:px-6 sm:py-3.5 flex items-center justify-between text-xs font-mono hover:bg-white/5 transition"
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`font-black text-base w-7 text-center ${
                          i === 0
                            ? "text-amber-300"
                            : i === 1
                            ? "text-slate-300"
                            : i === 2
                            ? "text-amber-600"
                            : "text-slate-500"
                        }`}
                      >
                        #{i + 1}
                      </span>
                      <span className="text-2xl">{e.avatar}</span>
                      <div className="font-sans">
                        <div className="font-black text-white text-sm">{e.name}</div>
                        <div className="text-[10px] text-purple-300 font-bold">{e.rankTitle}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-black text-cyan-300 text-sm">{e.score.toLocaleString()} pts</div>
                      <div className="text-[10px] text-amber-300">{e.coins.toLocaleString()} coins</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </section>

        {/* RANK TIERS */}
        <section className="flex flex-col gap-4">
          <div>
            <h2 className="text-xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
              Rank Tiers
            </h2>
            <p className="text-xs text-slate-400">Earn XP from every answered question to rank up.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
            {RANK_TIERS.map((r, i) => (
              <div
                key={r.name}
                className="p-4 rounded-2xl bg-white/5 border border-white/5 flex flex-col gap-1 text-center items-center"
              >
                <span className="text-3xl">{r.icon}</span>
                <span className="text-[10px] font-bold uppercase text-slate-400 font-mono">Tier {i + 1}</span>
                <span className="font-black text-sm" style={{ color: r.color }}>
                  {r.name}
                </span>
                <span className="text-[10px] font-mono text-slate-400">{r.minXp} XP</span>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
