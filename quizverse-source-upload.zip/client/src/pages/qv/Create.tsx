/**
 * QUIZVERSE Quiz Creator — build, save, edit, and publish quizzes with 4-option
 * questions, correct-answer picker, timers, explanations, and cover emoji.
 */

import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/qv/Navbar";
import { PinJoinDialog } from "@/components/qv/PinJoinDialog";
import { GradeBand, Question, Subject, Difficulty } from "@shared/types";
import { GRADE_BANDS, SUBJECTS } from "@/lib/quizverseData";
import { getPlayer } from "@/lib/playerStore";
import { playClick } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, CheckCircle2, Loader2, Sparkles, AlertCircle } from "lucide-react";

const COVERS = ["🧠", "🚀", "⚡", "🔬", "📐", "📖", "🌍", "💻", "🎨", "🎵", "🏆", "🌟", "🪐", "🦄", "👑"];

function emptyQuestion(id: number): Question {
  return {
    id: "q" + id,
    text: "",
    options: ["", "", "", ""],
    correct: 0,
    explanation: "",
    hint: "",
    points: 100,
    timeLimit: 20,
  };
}

export default function Create() {
  const [, setLocation] = useLocation();
  const [pinOpen, setPinOpen] = useState(false);
  const player = getPlayer();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [subject, setSubject] = useState<Subject>("science");
  const [gradeBand, setGradeBand] = useState<GradeBand>("6-8");
  const [topic, setTopic] = useState("");
  const [learningObjectives, setLearningObjectives] = useState("");
  const [tags, setTags] = useState("");
  const [estimatedMinutes, setEstimatedMinutes] = useState(8);
  const [cover, setCover] = useState("🧠");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [questions, setQuestions] = useState<Question[]>([
    emptyQuestion(1),
    emptyQuestion(2),
  ]);
  const [error, setError] = useState<string | null>(null);

  const createMutation = trpc.quizzes.create.useMutation();

  const addQuestion = () => {
    playClick();
    setQuestions((qs) => [...qs, emptyQuestion(qs.length + 1)]);
  };

  const removeQuestion = (idx: number) => {
    playClick();
    setQuestions((qs) => qs.filter((_, i) => i !== idx));
  };

  const updateQ = (idx: number, patch: Partial<Question>) => {
    setQuestions((qs) => qs.map((q, i) => (i === idx ? { ...q, ...patch } : q)));
  };

  const updateOption = (qIdx: number, optIdx: number, val: string) => {
    setQuestions((qs) =>
      qs.map((q, i) => {
        if (i !== qIdx) return q;
        const opts = [...q.options] as [string, string, string, string];
        opts[optIdx] = val;
        return { ...q, options: opts };
      })
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    setError(null);
    if (!title.trim()) {
      setError("Please add a title");
      return;
    }
    if (!topic.trim()) {
      setError("Please add a topic, such as Fractions or Ecosystems");
      return;
    }
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.text.trim()) {
        setError(`Question ${i + 1} is empty`);
        return;
      }
      if (q.options.some((o) => !o.trim())) {
        setError(`Question ${i + 1}: fill all 4 answer options`);
        return;
      }
    }
    try {
      const created = await createMutation.mutateAsync({
        title: title.trim(),
        description: description.trim() || undefined,
        subject,
        gradeBand,
        topic: topic.trim(),
        learningObjectives: learningObjectives.trim() || undefined,
        tags: tags.trim() || undefined,
        estimatedMinutes,
        cover,
        difficulty,
        authorName: player.name || "Quizverse",
        questions: questions.map((q) => ({
          ...q,
          text: q.text.trim(),
          options: q.options.map((o) => o.trim()) as [string, string, string, string],
          explanation: q.explanation?.trim() || undefined,
          hint: q.hint?.trim() || undefined,
          points: q.points ?? 100,
        })),
      });
      if (created?.slug) setLocation(`/play/${created.slug}/space-race`);
    } catch (err: any) {
      setError(err?.message || "Failed to save quiz");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenPin={() => setPinOpen(true)} />
      <PinJoinDialog open={pinOpen} onOpenChange={setPinOpen} />

      <main className="flex-1 max-w-4xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-8">
        <div>
          <span className="text-[10px] font-black uppercase tracking-wider text-purple-300">✏️ Quiz Creator</span>
          <h1 className="text-3xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
            Make your own quiz
          </h1>
          <p className="text-xs text-slate-400">
            Published quizzes appear in the Play hub and can be hosted live with a PIN code.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-8">
          {/* Metadata */}
          <section className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/60 shadow-2xl flex flex-col gap-4 text-xs">
            <h2 className="font-black text-sm text-white">Quiz Details</h2>

            <div>
              <label className="text-[11px] uppercase font-bold text-slate-400">Title</label>
              <input
                type="text"
                required
                maxLength={256}
                placeholder="e.g. Ancient Rome & Greek Myths"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="mt-1 w-full py-2.5 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-bold text-sm focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Grade band</label>
                <select value={gradeBand} onChange={(e) => setGradeBand(e.target.value as GradeBand)} className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-bold focus:outline-none focus:border-cyan-400">
                  {GRADE_BANDS.map((g) => <option key={g.id} value={g.id} className="bg-slate-900">{g.label}</option>)}
                </select>
                <p className="mt-1 text-[10px] text-slate-500">Match the vocabulary and difficulty to your learners.</p>
              </div>
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Topic</label>
                <input type="text" required maxLength={128} placeholder="e.g. Fractions & percentages" value={topic} onChange={(e) => setTopic(e.target.value)} className="mt-1 w-full py-2.5 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-bold focus:outline-none focus:border-cyan-400" />
              </div>
            </div>

            <div>
              <label className="text-[11px] uppercase font-bold text-slate-400">Description</label>
              <textarea
                rows={2}
                maxLength={1000}
                placeholder="What is this quiz about?"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Subject</label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value as Subject)}
                  className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-bold focus:outline-none focus:border-cyan-400"
                >
                  {SUBJECTS.map((s) => (
                    <option key={s.id} value={s.id} className="bg-slate-900">
                      {s.icon} {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Difficulty</label>
                <div className="mt-1 flex gap-2">
                  {(["easy", "medium", "hard"] as Difficulty[]).map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDifficulty(d)}
                      className={`flex-1 py-2 rounded-2xl font-bold capitalize transition ${
                        difficulty === d ? "bg-purple-600 text-white shadow" : "bg-white/5 text-slate-400 hover:bg-white/10"
                      }`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Learning objectives</label>
                <textarea rows={2} maxLength={2000} placeholder="What should students know or be able to do?" value={learningObjectives} onChange={(e) => setLearningObjectives(e.target.value)} className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white text-xs focus:outline-none focus:border-cyan-400" />
              </div>
              <div className="flex flex-col gap-3">
                <div>
                  <label className="text-[11px] uppercase font-bold text-slate-400">Tags</label>
                  <input type="text" maxLength={1000} placeholder="fractions, practice, review" value={tags} onChange={(e) => setTags(e.target.value)} className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white text-xs focus:outline-none focus:border-cyan-400" />
                </div>
                <div>
                  <label className="text-[11px] uppercase font-bold text-slate-400">Estimated time (minutes)</label>
                  <input type="number" min={1} max={180} value={estimatedMinutes} onChange={(e) => setEstimatedMinutes(Math.max(1, Math.min(180, Number(e.target.value) || 1)))} className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-mono text-xs focus:outline-none focus:border-cyan-400" />
                </div>
              </div>
            </div>

            <div>
              <label className="text-[11px] uppercase font-bold text-slate-400">Cover icon</label>
              <div className="mt-1 flex flex-wrap gap-2">
                {COVERS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCover(c)}
                    className={`w-10 h-10 rounded-2xl text-xl flex items-center justify-center border transition ${
                      cover === c ? "bg-purple-600/60 border-purple-400" : "bg-white/5 border-white/5 hover:bg-white/10"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </section>

          {/* Questions */}
          <section className="flex flex-col gap-4 text-xs">
            <div className="flex items-center justify-between">
              <h2 className="font-black text-sm text-white">Questions ({questions.length})</h2>
              <Button
                type="button"
                onClick={addQuestion}
                className="rounded-2xl bg-purple-600 hover:bg-purple-500 text-xs font-black gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add Question
              </Button>
            </div>

            {questions.map((q, idx) => (
              <div
                key={idx}
                className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/60 shadow-2xl flex flex-col gap-4"
              >
                <div className="flex items-center justify-between">
                  <span className="font-black text-sm text-cyan-300 font-mono">Q{idx + 1}</span>
                  {questions.length > 2 && (
                    <button
                      type="button"
                      onClick={() => removeQuestion(idx)}
                      className="text-rose-400 hover:text-rose-300 text-xs font-bold flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Remove
                    </button>
                  )}
                </div>

                <div>
                  <label className="text-[11px] uppercase font-bold text-slate-400">Question text</label>
                  <input
                    type="text"
                    required
                    placeholder="Type your question…"
                    value={q.text}
                    onChange={(e) => updateQ(idx, { text: e.target.value })}
                    className="mt-1 w-full py-2.5 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-bold text-sm focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] uppercase font-bold text-slate-400">
                      Answer options (select the correct one)
                    </label>
                  </div>
                  <div className="mt-1 grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {q.options.map((opt, oi) => {
                      const isCorrect = q.correct === oi;
                      return (
                        <div
                          key={oi}
                          onClick={() => updateQ(idx, { correct: oi })}
                          className={`p-3 rounded-2xl border cursor-pointer transition flex items-center gap-2 ${
                            isCorrect
                              ? "bg-emerald-500/20 border-emerald-400 text-white"
                              : "bg-white/5 border-white/5 hover:border-white/20"
                          }`}
                        >
                          <span
                            className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono text-[11px] shrink-0 font-bold ${
                              isCorrect ? "bg-emerald-400 text-slate-950" : "bg-white/10 text-slate-400"
                            }`}
                          >
                            {["A", "B", "C", "D"][oi]}
                          </span>
                          <input
                            type="text"
                            required
                            placeholder={`Option ${["A", "B", "C", "D"][oi]}`}
                            value={opt}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => updateOption(idx, oi, e.target.value)}
                            className="flex-1 bg-transparent text-xs font-bold text-white placeholder-slate-500 focus:outline-none"
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] uppercase font-bold text-slate-400">Explanation (optional)</label>
                    <input
                      type="text"
                      placeholder="Why is this the answer?"
                      value={q.explanation || ""}
                      onChange={(e) => updateQ(idx, { explanation: e.target.value })}
                      className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] uppercase font-bold text-slate-400">Timer (seconds)</label>
                    <input
                      type="number"
                      min={5}
                      max={120}
                      value={q.timeLimit || 20}
                      onChange={(e) => updateQ(idx, { timeLimit: Math.max(5, Number(e.target.value) || 20) })}
                      className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-mono text-xs focus:outline-none focus:border-cyan-400 text-center"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] uppercase font-bold text-slate-400">Hint (optional)</label>
                    <input type="text" maxLength={300} placeholder="A gentle clue for learners" value={q.hint || ""} onChange={(e) => updateQ(idx, { hint: e.target.value })} className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white text-xs focus:outline-none focus:border-cyan-400" />
                  </div>
                  <div>
                    <label className="text-[11px] uppercase font-bold text-slate-400">Points</label>
                    <input type="number" min={0} max={1000} value={q.points ?? 100} onChange={(e) => updateQ(idx, { points: Math.max(0, Math.min(1000, Number(e.target.value) || 0)) })} className="mt-1 w-full py-2 px-3 rounded-2xl bg-white/5 border border-purple-800/60 text-white font-mono text-xs focus:outline-none focus:border-cyan-400 text-center" />
                  </div>
                </div>
              </div>
            ))}
          </section>

          {error && (
            <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pb-8">
            <span className="text-[11px] text-slate-500">
              Minimum 2 questions · all fields saved permanently
            </span>
            <div className="flex gap-3">
              <Link href="/play" className="px-5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-xs font-bold">
                Cancel
              </Link>
              <Button
                type="submit"
                disabled={createMutation.isPending}
                className="px-8 h-12 rounded-2xl bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 hover:brightness-110 text-white font-black text-sm shadow-lg shadow-purple-500/30"
              >
                {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "PUBLISH QUIZ →"}
              </Button>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
}
