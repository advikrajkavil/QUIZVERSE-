/**
 * QUIZVERSE Homepage — hero with PIN join box, daily challenges, featured quizzes,
 * trending subjects, stats strip, and callouts.
 */

import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/qv/Navbar";
import { QuizCard } from "@/components/qv/QuizCard";
import { PinJoinDialog } from "@/components/qv/PinJoinDialog";
import { SUBJECTS } from "@/lib/quizverseData";
import { getPlayer, completeDailyChallenge } from "@/lib/playerStore";
import { playClick } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import {
  Sparkles,
  Trophy,
  Flame,
  Gamepad2,
  Users,
  CheckCircle,
  ArrowRight,
  Gift,
  Coins,
  Crown,
  WandSparkles,
  UsersRound,
  Volume2,
  SunMoon,
  Image,
} from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const [pinOpen, setPinOpen] = useState(false);
  const [quickPin, setQuickPin] = useState("");
  const player = getPlayer();

  const featuredQuery = trpc.quizzes.list.useQuery({ featuredOnly: true, limit: 4 });
  const dailyQuery = trpc.quizzes.list.useQuery({ dailyOnly: true, limit: 1 });
  const alltimeQuery = trpc.leaderboard.list.useQuery({ period: "weekly", limit: 3 });

  const dailyQuiz = dailyQuery.data?.[0];
  const today = new Date().toISOString().slice(0, 10);
  const dailyDone = player.dailyCompletedAt === today;

  const handleQuickJoin = (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    const c = quickPin.trim().toUpperCase();
    if (c.length === 6) setLocation(`/live/play/${c}`);
    else setPinOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenPin={() => setPinOpen(true)} />
      <PinJoinDialog open={pinOpen} onOpenChange={setPinOpen} />

      <main className="relative flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-10 overflow-hidden">
        <div className="pointer-events-none absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-purple-600/15 blur-3xl" />
        <div className="pointer-events-none absolute top-[42rem] -right-40 h-96 w-96 rounded-full bg-cyan-500/10 blur-3xl" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-96 opacity-15 [background-image:linear-gradient(rgba(139,92,246,.25)_1px,transparent_1px),linear-gradient(90deg,rgba(34,211,238,.18)_1px,transparent_1px)] [background-size:36px_36px] [mask-image:linear-gradient(to_bottom,black,transparent)]" />
        {/* HERO */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#4b1d7f] via-[#6d28d9] to-[#0ea5e9] p-7 sm:p-12 shadow-2xl text-white">
          <div className="absolute inset-0 opacity-15 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle, white 2px, transparent 2px)", backgroundSize: "36px 36px" }} />
          <div className="relative max-w-2xl flex flex-col gap-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-white/20 w-fit backdrop-blur">
              <Sparkles className="w-3.5 h-3.5" /> Educational trivia gaming
            </span>
            <h1
              className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-none"
              style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}
            >
              LEARN. PLAY. COMPETE. WIN.
            </h1>
            <p className="text-sm sm:text-base font-black tracking-wide text-cyan-200 -mt-1">
              QUIZVERSE <span className="text-white/70 font-semibold">by Advikraj, Demetrius, Aryan &amp; Omkar</span>
            </p>
            <p className="text-xs sm:text-base text-white/90 leading-relaxed">
              Answer real curriculum questions in five subjects — Science, Math, English, Social Studies, Computer Science — inside fast solo mini-games, or host live PIN-code competitions for your class.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <Link
                href="/play"
                onClick={playClick}
                className="px-6 py-3 rounded-full bg-cyan-300 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-cyan-500/30 hover:bg-cyan-200 transition transform hover:-translate-y-0.5"
              >
                Start Playing 🚀
              </Link>
              <Link
                href="/compete"
                onClick={playClick}
                className="px-6 py-3 rounded-full bg-white/15 hover:bg-white/25 font-black text-xs sm:text-sm transition backdrop-blur border border-white/30"
              >
                Live Competition
              </Link>
              <Button
                variant="ghost"
                onClick={() => {
                  playClick();
                  setPinOpen(true);
                }}
                className="text-white hover:bg-white/10 font-bold text-xs sm:text-sm rounded-full"
              >
                Join with PIN →
              </Button>
            </div>

            {/* Quick PIN join box */}
            <form onSubmit={handleQuickJoin} className="flex items-center gap-2 max-w-sm pt-1">
              <input
                type="text"
                maxLength={6}
                placeholder="Got a game PIN?"
                value={quickPin}
                onChange={(e) => setQuickPin(e.target.value.toUpperCase())}
                className="flex-1 text-center font-black tracking-widest font-mono text-sm uppercase py-2.5 px-3 rounded-2xl bg-black/30 border border-white/30 placeholder-white/50 text-white focus:outline-none focus:border-cyan-300 backdrop-blur"
              />
              <Button
                type="submit"
                className="rounded-2xl bg-white text-[#6d28d9] hover:bg-purple-100 font-black text-xs px-5 h-10 shadow"
              >
                GO
              </Button>
            </form>
          </div>
        </section>

        {/* STATS STRIP */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          {[
            { value: "4,600+", label: "Quizzes completed", color: "text-cyan-300" },
            { value: "98.7k", label: "Coins earned", color: "text-amber-300" },
            { value: "5", label: "Game modes", color: "text-purple-300" },
            { value: "542", label: "Live games hosted", color: "text-emerald-300" },
          ].map((s) => (
            <div key={s.label} className="p-4 rounded-2xl bg-white/5 border border-white/5 flex flex-col gap-1">
              <div className={`text-2xl sm:text-3xl font-black font-mono ${s.color}`}>{s.value}</div>
              <div className="text-[11px] text-slate-400">{s.label}</div>
            </div>
          ))}
        </section>

        {/* DAILY CHALLENGE */}
        {dailyQuiz && (
          <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500/20 via-purple-600/20 to-cyan-500/20 p-6 border border-amber-400/40 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-3">
              <span className="w-14 h-14 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-3xl shadow">
                ⚡
              </span>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-300 flex items-center gap-1">
                  <Flame className="w-3 h-3 text-amber-400" /> Daily Challenge · +100 bonus coins +200 XP
                </span>
                <h3 className="text-lg font-black text-white">{dailyQuiz.title}</h3>
                <p className="text-[11px] text-slate-300">{dailyQuiz.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {dailyDone ? (
                <span className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-emerald-500/20 text-emerald-300 font-black text-xs border border-emerald-500/40">
                  <CheckCircle className="w-4 h-4" /> Completed today!
                </span>
              ) : (
                <Link
                  href={`/play/${dailyQuiz.slug}/space-race`}
                  onClick={() => {
                    playClick();
                    completeDailyChallenge();
                  }}
                  className="px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/30"
                >
                  Play Today's Challenge →
                </Link>
              )}
            </div>
          </section>
        )}

        {/* FEATURED QUIZZES */}
        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
                <Sparkles className="w-6 h-6 text-purple-400" /> Featured Quizzes
              </h2>
              <p className="text-xs text-slate-400">Hand-crafted curriculum quizzes ready to play.</p>
            </div>
            <Link href="/play" className="text-xs text-cyan-400 font-bold hover:underline flex items-center gap-1">
              View all <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {(featuredQuery.data || []).map((q) => (
              <QuizCard key={q.id} quiz={q} />
            ))}
          </div>
        </section>

        {/* TRENDING SUBJECTS */}
        <section className="flex flex-col gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
              <Flame className="w-6 h-6 text-orange-400" /> Trending Subjects
            </h2>
            <p className="text-xs text-slate-400">Jump straight into your favourite subject.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {SUBJECTS.map((s) => (
              <Link
                key={s.id}
                href={`/play?subject=${s.id}`}
                onClick={playClick}
                className="group p-5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-cyan-400/40 transition flex flex-col gap-2 text-center items-center"
              >
                <span className="text-4xl group-hover:scale-110 transition-transform">{s.icon}</span>
                <span className="font-black text-sm text-white group-hover:text-cyan-300 transition-colors">
                  {s.name}
                </span>
                <span className="text-[10px] text-slate-400 line-clamp-2">{s.description}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* FIVE GAME MODES SHOWCASE */}
        <section className="rounded-3xl bg-white/5 border border-white/5 p-7 sm:p-10 flex flex-col gap-6">
          <div className="text-center max-w-xl mx-auto flex flex-col gap-2">
            <h2 className="text-2xl sm:text-3xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
              Five Ways to Play Any Quiz
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Inspired by Blooket — every quiz can be launched into any mode with its own unique visual mechanics.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {[
              { icon: "🚀", name: "Space Race", desc: "Rocket progression towards galaxies", tag: "Progression" },
              { icon: "💰", name: "Quiz Millionaire", desc: "Money ladder with lifelines", tag: "Strategy" },
              { icon: "🏎️", name: "Speed Rush", desc: "60-second combo storm", tag: "Speed" },
              { icon: "🏰", name: "Tower Battle", desc: "Stack blocks by answering", tag: "Build" },
              { icon: "🧟", name: "Survival", desc: "3 lives, keep answering", tag: "Lives" },
            ].map((m) => (
              <div key={m.name} className="p-4 rounded-2xl bg-slate-900 border border-purple-900/40 flex flex-col gap-2 text-center items-center">
                <span className="text-4xl">{m.icon}</span>
                <span className="text-[10px] uppercase font-bold text-cyan-300">{m.tag}</span>
                <span className="font-black text-sm text-white">{m.name}</span>
                <span className="text-[10px] text-slate-400">{m.desc}</span>
              </div>
            ))}
          </div>
        </section>

        {/* WEEKLY TOURNAMENT LEADERS */}
        <section className="rounded-3xl bg-gradient-to-br from-purple-950/70 via-slate-900 to-cyan-950/60 border border-purple-500/20 p-7 sm:p-10 flex flex-col gap-6 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-2">
            <div>
              <span className="text-[10px] uppercase tracking-[0.25em] font-black text-cyan-300">Special Features</span>
              <h2 className="text-2xl sm:text-3xl font-black text-white mt-1" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
                More ways to make learning feel like a game
              </h2>
            </div>
            <p className="text-xs text-slate-400 max-w-sm">Built for curious learners, teachers, and live classrooms.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              { icon: WandSparkles, title: "AI Quiz Maker", desc: "Turn a topic into a polished quiz draft in the Creator.", href: "/create", color: "text-fuchsia-300", cta: "Create a quiz" },
              { icon: UsersRound, title: "Multiplayer challenges", desc: "Host PIN-code competitions and climb the real leaderboard.", href: "/compete", color: "text-cyan-300", cta: "Enter the arena" },
              { icon: Volume2, title: "Sound effects", desc: "Chimes, countdowns, victory fanfares, and a quick mute control.", href: "/play", color: "text-amber-300", cta: "Play with sound" },
              { icon: SunMoon, title: "Dark and light themes", desc: "Switch the interface mood instantly from the top bar.", href: "/profile", color: "text-yellow-200", cta: "Open profile" },
              { icon: Sparkles, title: "Fun animations", desc: "Confetti, bouncing feedback, streak moments, and level-ups.", href: "/play", color: "text-pink-300", cta: "See the action" },
              { icon: Image, title: "Different backgrounds", desc: "Collect themed looks in Rewards and make your Quizverse yours.", href: "/rewards", color: "text-emerald-300", cta: "Explore themes" },
            ].map((feature) => {
              const Icon = feature.icon;
              return (
                <Link key={feature.title} href={feature.href} onClick={playClick} className="group rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-300/40 p-4 flex flex-col gap-3 transition hover:-translate-y-0.5">
                  <div className="flex items-center justify-between">
                    <Icon className={`w-6 h-6 ${feature.color}`} />
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-300 group-hover:translate-x-1 transition" />
                  </div>
                  <div>
                    <h3 className="font-black text-sm text-white">{feature.title}</h3>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{feature.desc}</p>
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-wide text-cyan-300">{feature.cta} →</span>
                </Link>
              );
            })}
          </div>
        </section>

        {/* WEEKLY TOURNAMENT LEADERS */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 rounded-3xl bg-white/5 border border-white/5 p-6 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black text-white flex items-center gap-2">
                  <Crown className="w-5 h-5 text-amber-400" /> Weekly Tournament Leaders
                </h2>
                <p className="text-[11px] text-slate-400">Resets every Monday — top 3 win avatar boxes.</p>
              </div>
              <Link href="/compete" className="text-xs text-purple-300 font-bold hover:underline">
                Full leaderboard →
              </Link>
            </div>
            <div className="flex flex-col gap-2">
              {(alltimeQuery.data || []).map((e, i) => (
                <div key={e.id} className="p-3 rounded-2xl bg-slate-900/80 border border-white/5 flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-3">
                    <span className="font-black text-base w-6 text-center text-amber-300">#{i + 1}</span>
                    <span className="text-xl">{e.avatar}</span>
                    <div className="font-sans">
                      <div className="font-black text-white text-sm">{e.name}</div>
                      <div className="text-[10px] text-purple-300">{e.rankTitle}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-black text-cyan-300">{e.score.toLocaleString()} pts</div>
                    <div className="text-[10px] text-amber-300">{e.coins} coins</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-3xl bg-gradient-to-br from-purple-900/60 via-indigo-900/40 to-cyan-900/40 border border-purple-800/60 p-6 flex flex-col gap-3 justify-between">
            <div className="flex flex-col gap-2">
              <span className="text-4xl">👑</span>
              <h3 className="text-xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
                Ready to compete?
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Host a live room for your class or friends with a simple 6-digit PIN. Real-time scoreboard, podium finish, and coins for every player.
              </p>
            </div>
            <div className="flex flex-col gap-2">
              <Link
                href="/compete"
                className="w-full py-3 rounded-2xl bg-cyan-300 hover:bg-cyan-200 text-slate-950 font-black text-xs text-center shadow-lg shadow-cyan-500/30"
              >
                Host a Live Game
              </Link>
              <Button
                variant="outline"
                onClick={() => setPinOpen(true)}
                className="rounded-2xl border-white/20 text-white hover:bg-white/10 text-xs font-bold"
              >
                Enter a PIN
              </Button>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="rounded-3xl bg-gradient-to-r from-purple-700 via-indigo-700 to-cyan-600 text-white p-8 sm:p-12 text-center flex flex-col items-center gap-3 shadow-2xl">
          <h2 className="text-2xl sm:text-4xl font-black max-w-xl" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
            Create your own quizzes in minutes
          </h2>
          <p className="text-xs sm:text-sm text-white/90 max-w-md">
            Teachers, tutors, and curious students can build, publish, and host custom quizzes with our visual creator.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <Link
              href="/create"
              className="px-6 py-3 rounded-full bg-white text-purple-800 font-black text-xs sm:text-sm shadow hover:bg-purple-50"
            >
              Open Quiz Creator →
            </Link>
            <Link
              href="/rewards"
              className="px-6 py-3 rounded-full bg-white/15 hover:bg-white/25 font-black text-xs sm:text-sm border border-white/30 backdrop-blur"
            >
              Browse Rewards Shop
            </Link>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-purple-900/40 bg-slate-950 text-xs text-slate-500 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2 font-bold text-slate-300">
            <span>🧠</span>
            <span>QUIZVERSE</span>
            <span className="font-normal text-slate-500">· Learn · Play · Compete · Win</span>
          </div>
          <div className="flex flex-wrap items-center gap-4 font-semibold text-slate-400">
            <Link href="/play" className="hover:text-white">Play</Link>
            <Link href="/compete" className="hover:text-white">Compete</Link>
            <Link href="/rewards" className="hover:text-white">Rewards</Link>
            <Link href="/create" className="hover:text-white">Create</Link>
            <Link href="/profile" className="hover:text-white">Profile</Link>
          </div>
          <div className="text-[11px] text-slate-500">Free educational trivia gaming · no account required</div>
        </div>
      </footer>
    </div>
  );
}
