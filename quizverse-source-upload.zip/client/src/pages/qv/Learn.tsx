/**
 * QUIZVERSE Learn hub — curriculum topics paired with curated educational video links.
 */
import React, { useMemo, useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/qv/Navbar";
import { PinJoinDialog } from "@/components/qv/PinJoinDialog";
import { GRADE_BANDS, SUBJECTS, SUBJECT_MAP } from "@/lib/quizverseData";
import { playClick } from "@/lib/sounds";
import { BookOpen, ExternalLink, GraduationCap, Loader2, Play, Search, Sparkles, Layers3, X, ChevronLeft, ChevronRight } from "lucide-react";

function videoSearchUrl(title: string, subject: string, grade: string) {
  const gradeLabel = GRADE_BANDS.find((g) => g.id === grade)?.label || grade;
  const query = `Khan Academy ${title} ${subject} ${gradeLabel} lesson`;
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
}

function academyUrl(title: string, subject: string) {
  return `https://www.khanacademy.org/search?page_search_query=${encodeURIComponent(`${title} ${subject}`)}`;
}

function getQuestions(quiz: any) {
  if (Array.isArray(quiz.questions)) return quiz.questions;
  try {
    return JSON.parse(quiz.questions || "[]");
  } catch {
    return [];
  }
}

function lessonIdeas(quiz: any) {
  const objectiveIdeas = String(quiz.learningObjectives || "").split(/[,.;]/).map((idea) => idea.trim()).filter(Boolean);
  const tagIdeas = String(quiz.tags || "").split(",").map((tag) => tag.trim()).filter(Boolean);
  return [...objectiveIdeas, ...tagIdeas.map((tag) => `Connect the idea to ${tag}`)].slice(0, 4);
}

export default function Learn() {
  const [pinOpen, setPinOpen] = useState(false);
  const [subject, setSubject] = useState("all");
  const [gradeBand, setGradeBand] = useState("all");
  const [search, setSearch] = useState("");
  const [flashcard, setFlashcard] = useState<{ title: string; questions: any[] } | null>(null);
  const [flashIndex, setFlashIndex] = useState(0);
  const [flashFlipped, setFlashFlipped] = useState(false);
  const nurseryQuery = trpc.quizzes.list.useQuery({ gradeBand: "nursery", limit: 60 });
  const grade1Query = trpc.quizzes.list.useQuery({ gradeBand: "grade1", limit: 60 });
  const grade2Query = trpc.quizzes.list.useQuery({ gradeBand: "grade2", limit: 60 });
  const elementaryQuery = trpc.quizzes.list.useQuery({ gradeBand: "3-5", limit: 60 });
  const middleQuery = trpc.quizzes.list.useQuery({ gradeBand: "6-8", limit: 60 });
  const highQuery = trpc.quizzes.list.useQuery({ gradeBand: "9-12", limit: 60 });
  const catalogQueries = [nurseryQuery, grade1Query, grade2Query, elementaryQuery, middleQuery, highQuery];
  const quizzes = catalogQueries.flatMap((query) => query.data || []);
  const quizzesLoading = catalogQueries.some((query) => query.isLoading);

  const lessons = useMemo(() => quizzes.filter((quiz: any) => {
    const matchesSubject = subject === "all" || quiz.subject === subject;
    const matchesGrade = gradeBand === "all" || quiz.gradeBand === gradeBand;
    const matchesSearch = !search.trim() || `${quiz.title} ${quiz.subject} ${quiz.gradeBand}`.toLowerCase().includes(search.toLowerCase());
    return matchesSubject && matchesGrade && matchesSearch;
  }), [quizzes, subject, gradeBand, search]);

  const featured = lessons[0];

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenPin={() => setPinOpen(true)} />
      <PinJoinDialog open={pinOpen} onOpenChange={setPinOpen} />

      <main className="relative flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-6 overflow-hidden">
        <div className="pointer-events-none absolute -top-32 -right-32 h-80 w-80 rounded-full bg-cyan-500/15 blur-3xl" />
        <div className="pointer-events-none absolute top-[34rem] -left-40 h-80 w-80 rounded-full bg-purple-600/15 blur-3xl" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-80 opacity-15 [background-image:linear-gradient(rgba(34,211,238,.25)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,.2)_1px,transparent_1px)] [background-size:32px_32px] [mask-image:linear-gradient(to_bottom,black,transparent)]" />
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-cyan-500/30 via-blue-600/25 to-purple-600/30 p-6 sm:p-9 border border-cyan-400/30 shadow-xl">
          <div className="absolute -right-8 -top-12 text-[160px] opacity-10 select-none">🎬</div>
          <div className="relative max-w-3xl flex flex-col gap-3">
            <span className="inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-cyan-200"><Sparkles className="w-3.5 h-3.5" /> Learn Hub</span>
            <h1 className="text-2xl sm:text-4xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>Watch. Understand. Then play.</h1>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-2xl">Read a quick lesson, watch a trusted explanation, and then practise every QUIZVERSE topic with its matching quiz.</p>
            <div className="flex flex-wrap items-center gap-2 pt-1 text-[10px] font-bold text-cyan-100">
              <span className="px-2.5 py-1 rounded-full bg-white/10 border border-white/10">{quizzes.length || 180} lessons</span>
              <span className="px-2.5 py-1 rounded-full bg-white/10 border border-white/10">6 grade levels</span>
              <span className="px-2.5 py-1 rounded-full bg-white/10 border border-white/10">5 subjects</span>
            </div>
          </div>
        </section>

        <section className="flex flex-col gap-3">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <button onClick={() => { playClick(); setSubject("all"); }} className={`px-3.5 py-1.5 rounded-full font-bold shrink-0 ${subject === "all" ? "bg-cyan-400 text-slate-950" : "bg-white/5 text-slate-300 hover:bg-white/10"}`}>All subjects</button>
            {SUBJECTS.map((s) => (
              <button key={s.id} onClick={() => { playClick(); setSubject(s.id); }} className={`px-3.5 py-1.5 rounded-full font-bold shrink-0 flex items-center gap-1 ${subject === s.id ? `bg-gradient-to-r ${s.gradient} text-white` : "bg-white/5 text-slate-300 hover:bg-white/10"}`}>
                <span>{s.icon}</span>{s.name}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 bg-white/5 p-3 rounded-2xl border border-white/5">
            <div className="flex items-center gap-1 overflow-x-auto w-full pb-1">
              <span className="text-[11px] text-slate-500 mr-1 shrink-0">Grade:</span>
              <button onClick={() => setGradeBand("all")} className={`px-2.5 py-1 rounded-full text-[11px] font-bold shrink-0 ${gradeBand === "all" ? "bg-cyan-400 text-slate-950" : "text-slate-400 hover:bg-white/5"}`}>All</button>
              {GRADE_BANDS.map((g) => <button key={g.id} onClick={() => setGradeBand(g.id)} title={g.description} className={`px-2.5 py-1 rounded-full text-[11px] font-bold shrink-0 ${gradeBand === g.id ? "bg-cyan-400 text-slate-950" : "text-slate-400 hover:bg-white/5"}`}>{g.short}</button>)}
            </div>
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search topics or lessons…" className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400" />
            </div>
            <span className="text-[11px] text-slate-500">Showing {lessons.length} lessons</span>
          </div>
        </section>

        {quizzesLoading ? (
          <div className="py-24 flex items-center justify-center gap-2 text-xs text-slate-400"><Loader2 className="w-5 h-5 animate-spin" /> Loading lessons…</div>
        ) : lessons.length === 0 ? (
          <div className="py-20 text-center text-slate-400 text-xs"><BookOpen className="w-10 h-10 mx-auto mb-3 opacity-50" /><p className="font-bold">No lessons found.</p><p>Try another grade, subject, or search phrase.</p></div>
        ) : (
          <>
            {featured && (
              <section className="rounded-3xl bg-slate-900/90 border border-cyan-800/50 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
                <div className="flex items-start gap-3"><span className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-slate-950 shrink-0"><GraduationCap className="w-6 h-6" /></span><div><span className="text-[10px] uppercase tracking-wider font-black text-cyan-300">Featured lesson</span><h2 className="text-lg font-black text-white">{featured.title}</h2><p className="text-[11px] text-slate-400">{SUBJECT_MAP.get(featured.subject)?.name} · {GRADE_BANDS.find((g) => g.id === featured.gradeBand)?.label}</p></div></div>
                <a href={videoSearchUrl(featured.title, featured.subject, featured.gradeBand)} target="_blank" rel="noreferrer" onClick={playClick} className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-cyan-300 hover:bg-cyan-200 text-slate-950 text-xs font-black shrink-0"><Play className="w-4 h-4 fill-current" /> WATCH VIDEO</a>
              </section>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {lessons.map((lesson: any) => {
                const meta = SUBJECT_MAP.get(lesson.subject);
                const grade = GRADE_BANDS.find((g) => g.id === lesson.gradeBand);
                const lessonQuestions = getQuestions(lesson);
                const question = lessonQuestions[0];
                const ideas = lessonIdeas(lesson);
                return <article key={lesson.id} className="rounded-3xl bg-slate-900/90 border border-white/10 overflow-hidden flex flex-col shadow-lg hover:border-cyan-400/40 transition-colors">
                  <div className={`h-24 bg-gradient-to-br ${meta?.gradient || "from-cyan-400 to-blue-500"} p-4 flex items-start justify-between`}><span className="text-4xl">{meta?.icon || "📚"}</span><span className="px-2 py-1 rounded-full bg-slate-950/35 text-[10px] text-white font-black">{grade?.short}</span></div>
                  <div className="p-4 flex flex-col gap-2 flex-1"><div className="text-[10px] uppercase tracking-wider text-cyan-300 font-black">{meta?.name}</div><h3 className="font-black text-white leading-tight">{lesson.title}</h3><p className="text-[11px] text-slate-400 flex-1">{lesson.description || "Build the idea step by step, then test your understanding."}</p>
                    <details className="rounded-2xl bg-cyan-400/5 border border-cyan-400/15 group/lesson">
                      <summary className="cursor-pointer list-none px-3 py-2 text-[11px] font-black text-cyan-200 flex items-center justify-between"><span className="flex items-center gap-1.5"><BookOpen className="w-3.5 h-3.5" /> Read lesson</span><span className="text-cyan-400 group-open/lesson:rotate-180 transition-transform">⌄</span></summary>
                      <div className="px-3 pb-3 flex flex-col gap-2 text-[11px] text-slate-300 leading-relaxed"><p><span className="font-black text-white">Lesson focus: </span>{lesson.learningObjectives || `Explore the main ideas in ${lesson.title}.`}</p>{ideas.length > 0 && <div><span className="font-black text-white">Key ideas</span><ul className="list-disc pl-4 mt-1 text-slate-400">{ideas.map((idea: string) => <li key={idea}>{idea}</li>)}</ul></div>}{question?.explanation && <p className="rounded-xl bg-white/5 p-2"><span className="font-black text-amber-200">Remember: </span>{question.explanation}</p>}</div>
                    </details>
                    <div className="flex gap-2 pt-2"><a href={videoSearchUrl(lesson.title, meta?.name || lesson.subject, lesson.gradeBand)} target="_blank" rel="noreferrer" onClick={playClick} className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 rounded-xl bg-cyan-400/15 text-cyan-200 hover:bg-cyan-400/25 text-[11px] font-black"><Play className="w-3.5 h-3.5 fill-current" /> Video</a><button type="button" onClick={() => { playClick(); setFlashcard({ title: lesson.title, questions: lessonQuestions }); setFlashIndex(0); setFlashFlipped(false); }} className="inline-flex items-center justify-center gap-1 px-2.5 rounded-xl bg-fuchsia-400/15 text-fuchsia-200 hover:bg-fuchsia-400/25 text-[11px] font-black" title="Open flashcards"><Layers3 className="w-3.5 h-3.5" /> Cards</button><a href={academyUrl(lesson.title, meta?.name || lesson.subject)} target="_blank" rel="noreferrer" className="w-9 inline-flex items-center justify-center rounded-xl bg-white/5 text-slate-300 hover:bg-white/10" title="Open Khan Academy search"><ExternalLink className="w-3.5 h-3.5" /></a><Link href={`/play/${lesson.slug}/space-race`} onClick={playClick} className="w-9 inline-flex items-center justify-center rounded-xl bg-purple-400/15 text-purple-200 hover:bg-purple-400/25" title="Play matching quiz"><BookOpen className="w-3.5 h-3.5" /></Link></div></div>
                </article>;
              })}
            </div>
          </>
        )}

        {flashcard && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-label={`${flashcard.title} flashcards`}>
            <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-fuchsia-400/30 shadow-2xl overflow-hidden">
              <div className="p-5 flex items-center justify-between border-b border-white/10"><div><span className="text-[10px] uppercase tracking-wider font-black text-fuchsia-300">Flashcards</span><h2 className="text-lg font-black text-white">{flashcard.title}</h2></div><button type="button" onClick={() => setFlashcard(null)} className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center" aria-label="Close flashcards"><X className="w-4 h-4" /></button></div>
              <div className="p-5 flex flex-col gap-4"><button type="button" onClick={() => setFlashFlipped((value) => !value)} className="min-h-52 rounded-3xl bg-gradient-to-br from-purple-600 via-indigo-600 to-cyan-500 p-7 text-center flex flex-col items-center justify-center gap-3 hover:scale-[1.01] transition-transform"><span className="text-[10px] uppercase tracking-[0.25em] font-black text-white/70">{flashFlipped ? "Answer" : "Question"} · {flashIndex + 1}/{flashcard.questions.length}</span><span className="text-xl sm:text-2xl font-black text-white">{flashFlipped ? (flashcard.questions[flashIndex]?.explanation || flashcard.questions[flashIndex]?.options?.[flashcard.questions[flashIndex]?.correct] || "Review the idea, then try the quiz!") : flashcard.questions[flashIndex]?.text}</span><span className="text-[11px] text-white/70">Tap to flip</span></button><div className="flex items-center justify-between"><button type="button" disabled={flashIndex === 0} onClick={() => { setFlashIndex((value) => value - 1); setFlashFlipped(false); }} className="px-3 py-2 rounded-xl bg-white/5 disabled:opacity-30 text-xs font-black flex items-center gap-1"><ChevronLeft className="w-4 h-4" /> Previous</button><span className="text-[11px] text-slate-400">Learn, flip, remember</span><button type="button" disabled={flashIndex === flashcard.questions.length - 1} onClick={() => { setFlashIndex((value) => value + 1); setFlashFlipped(false); }} className="px-3 py-2 rounded-xl bg-white/5 disabled:opacity-30 text-xs font-black flex items-center gap-1">Next <ChevronRight className="w-4 h-4" /></button></div><Link href={`/play/${lessons.find((lesson: any) => lesson.title === flashcard.title)?.slug || ""}/space-race`} onClick={() => { playClick(); setFlashcard(null); }} className="w-full text-center py-2.5 rounded-2xl bg-cyan-300 text-slate-950 font-black text-xs">Play this quiz →</Link></div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
