/**
 * LiveHost — teacher host dashboard.
 * Lobby with PIN + player list, start question with countdown, scoreboard,
 * podium results, and coin distribution.
 */

import React, { useEffect, useState, useRef } from "react";
import { Link, useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/qv/Navbar";
import { playClick, playCorrect, playTick, playVictory } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Users, Loader2, Sparkles, Trophy, ArrowRight, Play, CheckCircle } from "lucide-react";
import confetti from "canvas-confetti";

export default function LiveHost() {
  const [, params] = useRoute("/live/host/:code");
  const [, setLocation] = useLocation();
  const code = (params?.code || "").toUpperCase();

  const roomUtils = trpc.useUtils();
  const roomQuery = trpc.rooms.get.useQuery({ code }, { enabled: !!code, refetchInterval: 1500 });
  const startQ = trpc.rooms.start.useMutation();
  const showSb = trpc.rooms.scoreboard.useMutation();
  const endRoom = trpc.rooms.end.useMutation();

  const room = roomQuery.data;
  const quiz = room?.quiz;
  const questions = quiz?.questions || [];
  const currentQ = questions[room?.currentQuestion ?? 0];
  const players = room?.players || [];
  const answers = room?.answers || {};

  const [timer, setTimer] = useState(20);
  const timerRef = useRef<number | null>(null);

  // Question countdown for host view
  useEffect(() => {
    if (room?.status !== "question") return;
    setTimer(currentQ?.timeLimit || 20);
    timerRef.current = window.setInterval(() => {
      setTimer((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current!);
          showSb.mutate({ code });
          return 0;
        }
        if (t <= 6) playTick();
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [room?.status, room?.currentQuestion]);

  const handleStart = async () => {
    playClick();
    await startQ.mutateAsync({ code, questionIndex: 0 });
    roomUtils.rooms.get.invalidate({ code });
  };

  const handleNextQuestion = async () => {
    playClick();
    const next = (room?.currentQuestion ?? 0) + 1;
    if (next >= questions.length) {
      await endRoom.mutateAsync({ code });
      roomUtils.rooms.get.invalidate({ code });
      try {
        confetti({ particleCount: 100, spread: 90 });
      } catch {}
      playVictory();
      return;
    }
    await startQ.mutateAsync({ code, questionIndex: next });
    roomUtils.rooms.get.invalidate({ code });
  };

  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar />

      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-6">
        {/* Top bar */}
        <div className="bg-slate-900/90 rounded-3xl p-5 border border-purple-800/60 shadow-2xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-purple-600 flex items-center justify-center text-xl">🎤</span>
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-400">Host Dashboard</div>
              <div className="font-black text-white text-base">{quiz?.title || "Live Room"}</div>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <div>
              <span className="text-slate-400 text-[10px] block font-sans uppercase">Game PIN</span>
              <span className="text-3xl font-black text-cyan-300 tracking-widest">{code}</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block font-sans uppercase">Players</span>
              <span className="text-2xl font-black text-purple-300">{players.length}</span>
            </div>
          </div>
        </div>

        {/* LOBBY state */}
        {room?.status === "waiting" && (
          <div className="bg-slate-900/90 rounded-3xl p-8 border border-purple-800/60 shadow-2xl flex flex-col items-center gap-6 text-center">
            <div className="text-sm text-slate-300">
              Tell players to go to <span className="text-cyan-300 font-bold font-mono">quizverse</span> and enter PIN{" "}
              <span className="font-mono font-black text-3xl text-cyan-300 px-3 py-1 rounded-2xl bg-white/5 border border-cyan-400/40 inline-block tracking-widest">
                {code}
              </span>
            </div>

            <div className="w-full max-w-2xl min-h-[160px] p-4 rounded-2xl bg-white/5 border border-white/5 flex flex-wrap gap-2 items-center justify-center">
              {players.length === 0 ? (
                <span className="text-xs text-slate-500">Waiting for players to join…</span>
              ) : (
                players.map((p) => (
                  <span
                    key={p.id}
                    className="px-3 py-1.5 rounded-full bg-white/10 border border-white/10 text-xs font-bold flex items-center gap-1.5 text-white animate-fade-in"
                  >
                    <span>{p.avatar}</span>
                    <span>{p.name}</span>
                  </span>
                ))
              )}
            </div>

            <div className="flex items-center gap-3">
              <Button
                onClick={handleStart}
                disabled={players.length === 0 || startQ.isPending}
                className="h-12 px-8 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 text-slate-950 font-black text-sm shadow-lg shadow-cyan-500/30 gap-2 disabled:opacity-40"
              >
                <Play className="w-4 h-4" /> START GAME ({players.length} joined)
              </Button>
            </div>
          </div>
        )}

        {/* QUESTION state */}
        {room?.status === "question" && currentQ && (
          <div className="bg-slate-900/90 rounded-3xl p-8 border border-purple-800/60 shadow-2xl flex flex-col gap-6">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-purple-300 font-bold">
                Q{(room?.currentQuestion ?? 0) + 1} of {questions.length}
              </span>
              <span className="text-3xl font-black text-amber-300 font-mono">⏱ {timer}s</span>
              <span className="text-cyan-300 font-bold">
                {Object.keys(answers).length}/{players.length} answered
              </span>
            </div>

            <div className="text-xl sm:text-2xl font-black text-white text-center py-4">
              {currentQ.text}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm font-bold">
              {currentQ.options.map((opt, i) => (
                <div
                  key={i}
                  className="p-4 rounded-2xl bg-white/5 border border-white/10 text-white flex items-center gap-3"
                >
                  <span className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center font-mono text-xs">
                    {["A", "B", "C", "D"][i]}
                  </span>
                  <span>{opt}</span>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2">
              <Button
                onClick={() => showSb.mutate({ code })}
                className="rounded-2xl bg-purple-600 hover:bg-purple-500 text-xs font-black px-6"
              >
                Skip to scoreboard →
              </Button>
            </div>
          </div>
        )}

        {/* SCOREBOARD state */}
        {room?.status === "scoreboard" && (
          <div className="bg-slate-900/90 rounded-3xl p-8 border border-purple-800/60 shadow-2xl flex flex-col gap-6">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black uppercase text-purple-300">Live scoreboard</span>
                <h2 className="text-xl font-black text-white">After Q{(room?.currentQuestion ?? 0) + 1}</h2>
              </div>
              <Button
                onClick={handleNextQuestion}
                className="rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 text-slate-950 font-black text-xs px-6 h-10 shadow"
              >
                {(room?.currentQuestion ?? 0) + 1 >= questions.length ? "Final results →" : "Next question →"}
              </Button>
            </div>

            <div className="divide-y divide-white/5 text-xs font-mono">
              {sortedPlayers.map((p, i) => (
                <div key={p.id} className="py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="font-black text-base w-6 text-center text-amber-300">#{i + 1}</span>
                    <span className="text-2xl">{p.avatar}</span>
                    <span className="font-black text-white text-sm font-sans">{p.name}</span>
                    {p.streak >= 2 && <span className="text-[10px] text-amber-300">🔥{p.streak}</span>}
                  </div>
                  <span className="font-black text-cyan-300 text-sm">{p.score} pts</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ENDED state - podium */}
        {room?.status === "ended" && (
          <div className="bg-slate-900/90 rounded-3xl p-10 border border-purple-800/60 shadow-2xl flex flex-col items-center gap-6 text-center">
            <span className="text-5xl">🏆</span>
            <h2 className="text-3xl font-black bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-500 bg-clip-text text-transparent">
              Final Results
            </h2>

            {/* Podium */}
            <div className="flex items-end justify-center gap-3 w-full max-w-md pt-4">
              {/* 2nd */}
              <div className="flex-1 flex flex-col items-center gap-1">
                <span className="text-3xl">{sortedPlayers[1]?.avatar || "🥈"}</span>
                <span className="text-xs font-bold text-white max-w-[100px] truncate">{sortedPlayers[1]?.name || "-"}</span>
                <span className="text-[11px] font-mono text-cyan-300">{sortedPlayers[1]?.score ?? 0}</span>
                <div className="w-full h-24 rounded-2xl bg-gradient-to-t from-slate-400 to-slate-200 text-slate-950 font-black flex items-center justify-center text-sm shadow">
                  2
                </div>
              </div>
              {/* 1st */}
              <div className="flex-1 flex flex-col items-center gap-1">
                <span className="text-4xl">{sortedPlayers[0]?.avatar || "🥇"}</span>
                <span className="text-xs font-bold text-white max-w-[100px] truncate">{sortedPlayers[0]?.name || "-"}</span>
                <span className="text-[11px] font-mono text-amber-300 font-bold">{sortedPlayers[0]?.score ?? 0}</span>
                <div className="w-full h-32 rounded-2xl bg-gradient-to-t from-amber-500 to-yellow-300 text-slate-950 font-black flex items-center justify-center text-base shadow">
                  1 👑
                </div>
              </div>
              {/* 3rd */}
              <div className="flex-1 flex flex-col items-center gap-1">
                <span className="text-3xl">{sortedPlayers[2]?.avatar || "🥉"}</span>
                <span className="text-xs font-bold text-white max-w-[100px] truncate">{sortedPlayers[2]?.name || "-"}</span>
                <span className="text-[11px] font-mono text-purple-300">{sortedPlayers[2]?.score ?? 0}</span>
                <div className="w-full h-16 rounded-2xl bg-gradient-to-t from-amber-700 to-amber-500 text-slate-950 font-black flex items-center justify-center text-sm shadow">
                  3
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-400">All players received coins proportional to their score.</p>
            <div className="flex gap-3">
              <Button onClick={() => setLocation("/compete")} className="rounded-2xl bg-purple-600 font-black text-xs px-6">
                Back to Compete
              </Button>
              <Link href="/play" className="px-5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-xs font-bold">
                Play hub
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
