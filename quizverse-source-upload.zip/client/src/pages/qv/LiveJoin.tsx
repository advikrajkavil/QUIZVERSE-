/**
 * LiveJoin — dedicated PIN entry page with nickname & avatar selection.
 */

import React, { useState } from "react";
import { useLocation } from "wouter";
import { Navbar } from "@/components/qv/Navbar";
import { AVATARS } from "@/lib/quizverseData";
import { getPlayer, setName } from "@/lib/playerStore";
import { playClick } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Users, Loader2 } from "lucide-react";

export default function LiveJoin() {
  const [, setLocation] = useLocation();
  const player = getPlayer();
  const [pin, setPin] = useState("");
  const [nickname, setNickname] = useState(player.name || "");
  const [avatar, setAvatar] = useState(player.avatar || "🚀");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const roomUtils = trpc.useUtils();

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    setError(null);
    const code = pin.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (code.length !== 6) {
      setError("PIN must be 6 characters");
      return;
    }
    const name = (nickname || "Player").trim().slice(0, 32);
    setName(name);
    setLoading(true);
    try {
      const room = await roomUtils.client.rooms.get.query({ code });
      if (!room) {
        setError("Room not found. Check the PIN and try again.");
        return;
      }
      localStorage.setItem("quizverse_live_avatar", avatar);
      setLocation(`/live/play/${code}`);
    } catch {
      setError("Could not connect. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar />

      <main className="flex-1 max-w-lg w-full mx-auto p-4 sm:p-6 flex flex-col justify-center gap-6">
        <div className="bg-slate-900/90 rounded-3xl p-7 border border-purple-800/60 shadow-2xl flex flex-col gap-6 text-center">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-slate-950 shadow-lg shadow-cyan-500/30">
            <Users className="w-7 h-7" />
          </div>

          <div>
            <h1 className="text-3xl font-black bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text text-transparent">
              Join Live Game
            </h1>
            <p className="text-xs text-slate-400 mt-1">Enter your host's 6-digit game PIN</p>
          </div>

          <form onSubmit={handleJoin} className="flex flex-col gap-4 text-left">
            <div>
              <label className="text-[11px] uppercase font-bold text-slate-400">Game PIN</label>
              <input
                type="text"
                maxLength={6}
                autoFocus
                placeholder="123456"
                value={pin}
                onChange={(e) => setPin(e.target.value.toUpperCase())}
                className="mt-1 w-full text-center text-4xl font-black tracking-widest font-mono py-3 rounded-2xl bg-white/5 border border-purple-800/60 text-cyan-300 focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="text-[11px] uppercase font-bold text-slate-400">Nickname</label>
              <input
                type="text"
                maxLength={32}
                placeholder="Your name"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                className="mt-1 w-full text-center text-sm font-bold py-2.5 rounded-2xl bg-white/5 border border-purple-800/60 text-white focus:outline-none focus:border-cyan-400"
              />
              <div className="mt-2 flex items-center justify-center gap-2 text-[10px]">
                <span className="text-slate-500">Quick name:</span>
                {["Aryan", "Omkar"].map((name) => (
                  <button
                    key={name}
                    type="button"
                    onClick={() => {
                      playClick();
                      setNickname(name);
                    }}
                    className={`px-2.5 py-1 rounded-full border font-bold transition ${nickname === name ? "bg-cyan-400 text-slate-950 border-cyan-300" : "bg-white/5 text-cyan-200 border-cyan-400/20 hover:bg-cyan-400/10"}`}
                  >
                    {name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[11px] uppercase font-bold text-slate-400">Choose avatar</label>
              <div className="mt-1 grid grid-cols-5 gap-2">
                {AVATARS.map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => {
                      playClick();
                      setAvatar(a.emoji);
                    }}
                    className={`h-11 rounded-xl text-xl flex items-center justify-center border transition ${
                      avatar === a.emoji
                        ? "bg-gradient-to-br from-cyan-400 to-blue-500 border-cyan-300 shadow-md"
                        : "bg-white/5 border-white/5 hover:bg-white/10"
                    }`}
                  >
                    {a.emoji}
                  </button>
                ))}
              </div>
            </div>

            {error && <div className="text-xs text-rose-400 text-center font-semibold">{error}</div>}

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 text-slate-950 font-black text-sm tracking-wide shadow-lg shadow-cyan-500/30"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "ENTER GAME"}
            </Button>
          </form>
        </div>
      </main>
    </div>
  );
}
