/**
 * LivePlay — student-side live game view.
 * Enter name & avatar, wait in lobby, answer synchronized question options,
 * receive feedback, and watch your rank on the scoreboard.
 */

import React, { useEffect, useState, useRef } from "react";
import { Link, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/qv/Navbar";
import { AVATARS } from "@/lib/quizverseData";
import { getPlayer, earnCoins, earnXp } from "@/lib/playerStore";
import { playClick, playCorrect, playWrong, playVictory, playTick, playUrgent } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Loader2, Users, Flame, Heart } from "lucide-react";
import confetti from "canvas-confetti";

export default function LivePlay() {
  const [, params] = useRoute("/live/play/:code");
  const code = (params?.code || "").toUpperCase();

  const player = getPlayer();
  const [joined, setJoined] = useState(false);
  const [name, setNameInput] = useState(player.name || "");
  const [avatar, setAvatar] = useState(() => localStorage.getItem("quizverse_live_avatar") || player.avatar || "🚀");
  const [playerId] = useState(() => player.id);
  const [selected, setSelected] = useState<number | null>(null);
  const [answeredQuestion, setAnsweredQuestion] = useState<number | null>(null);
  const [timer, setTimer] = useState(20);
  const timerRef = useRef<number | null>(null);

  const roomUtils = trpc.useUtils();
  const roomQuery = trpc.rooms.get.useQuery({ code }, { enabled: !!code && joined, refetchInterval: 1200 });
  const joinMutation = trpc.rooms.join.useMutation();
  const answerMutation = trpc.rooms.answer.useMutation();

  const room = roomQuery.data;
  const quiz = room?.quiz;
  const questions = quiz?.questions || [];
  const currentQ = questions[room?.currentQuestion ?? 0];
  const qIdx = room?.currentQuestion ?? 0;
  const myAnswer = room?.answers?.[playerId];
  const myPlayer = (room?.players || []).find((p) => p.id === playerId);
  const players = room?.players || [];
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
  const myRank = sortedPlayers.findIndex((p) => p.id === playerId) + 1;

  // Question countdown
  useEffect(() => {
    if (room?.status !== "question") return;
    setTimer(currentQ?.timeLimit || 20);
    timerRef.current = window.setInterval(() => {
      setTimer((t) => {
        if (t <= 6) playTick();
        if (t <= 3) playUrgent();
        if (t <= 1) {
          clearInterval(timerRef.current!);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [room?.status, qIdx]);

  // Reset answer when question changes
  useEffect(() => {
    setSelected(null);
  }, [qIdx]);

  // Victory sound once on end
  useEffect(() => {
    if (room?.status === "ended") {
      playVictory();
      try {
        confetti({ particleCount: 70, spread: 80 });
      } catch {}
      // payout coins proportional to score
      const coins = Math.max(5, Math.round((myPlayer?.score || 0) * 0.05));
      earnCoins(coins);
      earnXp(Math.max(20, Math.round((myPlayer?.score || 0) * 0.1)));
    }
  }, [room?.status]);

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();
    const finalName = (name || "Player").trim().slice(0, 32);
    await joinMutation.mutateAsync({ code, player: { id: playerId, name: finalName, avatar } });
    setJoined(true);
    roomUtils.rooms.get.invalidate({ code });
  };

  const handlePick = async (optIdx: number) => {
    if (selected !== null || !currentQ || room?.status !== "question") return;
    setSelected(optIdx);
    playClick();
    const limit = currentQ.timeLimit || 20;
    const ms = (limit - timer) * 1000;
    const correct = optIdx === currentQ.correct;
    // speed bonus: 500..1000 pts
    const points = correct ? Math.round(500 + 500 * Math.max(0, timer / limit)) : 0;
    if (correct) playCorrect();
    else playWrong();
    await answerMutation.mutateAsync({
      code,
      playerId,
      answer: { optionIndex: optIdx, ms, correct, points },
    });
    setAnsweredQuestion(qIdx);
    roomUtils.rooms.get.invalidate({ code });
  };

  // Join form
  if (!joined) {
    return (
      <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
        <Navbar />
        <main className="flex-1 max-w-sm w-full mx-auto p-4 flex flex-col justify-center gap-4">
          <div className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/60 shadow-2xl flex flex-col gap-4 text-center">
            <span className="text-4xl">👋</span>
            <h1 className="text-2xl font-black bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text text-transparent">
              Enter your nickname
            </h1>
            <p className="text-xs text-slate-400">Joining room <span className="font-mono font-black text-cyan-300">{code}</span></p>

            <form onSubmit={handleJoin} className="flex flex-col gap-4 text-left text-xs">
              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Nickname</label>
                <input
                  type="text"
                  maxLength={32}
                  autoFocus
                  placeholder="Your nickname"
                  value={name}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="mt-1 w-full text-center text-sm font-bold py-2.5 rounded-2xl bg-white/5 border border-purple-800/60 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-[11px] uppercase font-bold text-slate-400">Choose avatar</label>
                <div className="mt-1 grid grid-cols-5 gap-2">
                  {AVATARS.slice(0, 10).map((a) => (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => setAvatar(a.emoji)}
                      className={`h-11 rounded-xl text-xl flex items-center justify-center border transition ${
                        avatar === a.emoji
                          ? "bg-gradient-to-br from-cyan-400 to-blue-500 border-cyan-300 shadow-md"
                          : "bg-white/5 border-white/5 hover:bg-white/10"
                      }`}
                    >
                      {a.emoji}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                type="submit"
                disabled={joinMutation.isPending}
                className="w-full h-12 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 text-slate-950 font-black text-sm shadow-lg shadow-cyan-500/30"
              >
                {joinMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "JOIN LOBBY"}
              </Button>
            </form>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar />

      <main className="flex-1 max-w-2xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-4">
        {/* Player header */}
        <div className="bg-slate-900/90 rounded-3xl p-4 border border-purple-800/60 shadow-2xl flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{myPlayer?.avatar || avatar}</span>
            <div className="font-sans">
              <div className="font-black text-white text-sm">{myPlayer?.name || name}</div>
              <div className="text-[10px] text-slate-400 font-mono">PIN {code}</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {myPlayer?.streak ? (
              <span className="text-amber-300 font-bold flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-400" /> {myPlayer.streak} streak
              </span>
            ) : null}
            <span className="text-cyan-300 font-black text-base">{myPlayer?.score ?? 0} pts</span>
          </div>
        </div>

        {/* LOBBY */}
        {room?.status === "waiting" && (
          <div className="bg-slate-900/90 rounded-3xl p-8 border border-purple-800/60 shadow-2xl text-center flex flex-col items-center gap-4">
            <span className="text-5xl animate-bounce">⏳</span>
            <h2 className="text-2xl font-black bg-gradient-to-r from-purple-300 via-pink-300 to-cyan-300 bg-clip-text text-transparent">
              You're in! Waiting for the host…
            </h2>
            <p className="text-xs text-slate-400">
              {players.length} player{players.length === 1 ? "" : "s"} in lobby. Keep this screen open.
            </p>
          </div>
        )}

        {/* QUESTION */}
        {room?.status === "question" && currentQ && (
          <div className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/60 shadow-2xl flex flex-col gap-5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-purple-300 font-bold">
                Q{qIdx + 1}/{questions.length}
              </span>
              <span className="text-3xl font-black text-amber-300 font-mono">⏱ {timer}s</span>
              <span className="text-[11px] text-slate-400">{currentQ.text.slice(0, 30)}…</span>
            </div>

            <div className="text-xl font-black text-white text-center py-2">{currentQ.text}</div>

            {selected !== null ? (
              <div className="py-10 text-center flex flex-col items-center gap-3">
                <span className="text-5xl">{currentQ.options[selected] ? "✅" : "❌"}</span>
                <span className="font-black text-base text-cyan-300">Answer locked in!</span>
                <span className="text-xs text-slate-400">Waiting for other players…</span>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm font-bold">
                {currentQ.options.map((opt, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handlePick(i)}
                    className="p-5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-400/60 active:scale-[0.99] text-white text-left transition flex items-center gap-3"
                  >
                    <span className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center font-mono text-sm shrink-0">
                      {["A", "B", "C", "D"][i]}
                    </span>
                    <span>{opt}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* SCOREBOARD */}
        {room?.status === "scoreboard" && (
          <div className="bg-slate-900/90 rounded-3xl p-6 border border-purple-800/60 shadow-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black uppercase text-purple-300">Round {qIdx + 1} results</span>
                <h2 className="text-xl font-black text-white">Scoreboard</h2>
              </div>
              <span className="px-3 py-1 rounded-full bg-cyan-400/20 text-cyan-300 text-xs font-mono font-bold">
                You: #{myRank} of {players.length}
              </span>
            </div>

            <div className="divide-y divide-white/5 text-xs font-mono">
              {sortedPlayers.map((p, i) => (
                <div
                  key={p.id}
                  className={`py-3 px-2 rounded-xl flex items-center justify-between ${
                    p.id === playerId ? "bg-cyan-400/10 border border-cyan-400/30" : ""
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="font-black text-base w-6 text-center text-amber-300">#{i + 1}</span>
                    <span className="text-2xl">{p.avatar}</span>
                    <span className="font-black text-white text-sm font-sans">{p.name}</span>
                    {p.id === playerId && <span className="text-[10px] text-cyan-300 font-bold">(You)</span>}
                  </div>
                  <span className="font-black text-cyan-300 text-sm">{p.score} pts</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ENDED */}
        {room?.status === "ended" && (
          <div className="bg-slate-900/90 rounded-3xl p-8 border border-purple-800/60 shadow-2xl text-center flex flex-col items-center gap-4">
            <span className="text-5xl">{myRank === 1 ? "🥇" : myRank === 2 ? "🥈" : myRank === 3 ? "🥉" : "🏁"}</span>
            <h2 className="text-3xl font-black bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-500 bg-clip-text text-transparent">
              {myRank === 1 ? "You Won!" : myRank <= 3 ? "Podium Finish!" : "Great Game!"}
            </h2>
            <div className="text-xs text-slate-300">
              Rank #{myRank} of {players.length} · <span className="font-mono text-cyan-300 font-bold">{myPlayer?.score} pts</span>
            </div>
            <div className="text-xs text-amber-300 font-mono">
              +{Math.max(5, Math.round((myPlayer?.score || 0) * 0.05))} coins earned!
            </div>
            <div className="flex gap-3 pt-2">
              <Link href="/play" className="px-5 py-2.5 rounded-2xl bg-cyan-300 text-slate-950 font-black text-xs shadow">
                Play more quizzes →
              </Link>
              <Link href="/compete" className="px-5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-xs font-bold">
                Back to Compete
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
