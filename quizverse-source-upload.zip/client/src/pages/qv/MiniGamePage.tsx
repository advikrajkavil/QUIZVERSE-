/**
 * MiniGamePage — loads quiz by slug from route (/play/:quizId/:mode),
 * renders the chosen mini-game mode with a mode switcher bar.
 */

import React from "react";
import { Link, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/qv/Navbar";
import { PinJoinDialog } from "@/components/qv/PinJoinDialog";
import { SpaceRaceMode } from "@/components/qv/modes/SpaceRaceMode";
import { MillionaireMode } from "@/components/qv/modes/MillionaireMode";
import { SpeedRushMode } from "@/components/qv/modes/SpeedRushMode";
import { TowerBattleMode } from "@/components/qv/modes/TowerBattleMode";
import { SurvivalMode } from "@/components/qv/modes/SurvivalMode";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2 } from "lucide-react";
import { getPlayer } from "@/lib/playerStore";

const MODES = [
  { id: "space-race", label: "🚀 Space Race" },
  { id: "millionaire", label: "💰 Quiz Millionaire" },
  { id: "speed-rush", label: "🏎️ Speed Rush" },
  { id: "tower-battle", label: "🏰 Tower Battle" },
  { id: "survival", label: "🧟 Survival" },
];

export default function MiniGamePage() {
  const [, params] = useRoute("/play/:quizId/:mode");
  const rawQuizId = params?.quizId || "";
  const quizId = rawQuizId.startsWith(":") ? "" : rawQuizId;
  const mode = params?.mode || "space-race";
  const [pinOpen, setPinOpen] = React.useState(false);

  const quizQuery = trpc.quizzes.get.useQuery({ slug: quizId }, { enabled: !!quizId });
  const playMutation = trpc.quizzes.recordPlay.useMutation();
  const leaderboardMutation = trpc.leaderboard.submit.useMutation();

  const quiz = quizQuery.data;
  const submitScore = async (result: { score: number; totalQuestions: number; gameMode: string }) => {
    try {
      const player = getPlayer();
      const payload = { score: Math.round(result.score), avatar: player.avatar, coins: player.coins };
      await Promise.all([
        leaderboardMutation.mutateAsync({ ...payload, period: "alltime" }),
        leaderboardMutation.mutateAsync({ ...payload, period: "weekly" }),
      ]);
    } catch {
      // Guests can still play; only authenticated account holders are added.
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenPin={() => setPinOpen(true)} />
      <PinJoinDialog open={pinOpen} onOpenChange={setPinOpen} />

      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-4">
        {/* Top bar: back + mode switcher */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          <Link
            href="/play"
            className="flex items-center gap-1.5 text-slate-400 hover:text-white font-bold transition"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Play hub
          </Link>

          <div className="flex items-center gap-1 bg-white/5 p-1 rounded-full border border-white/10 overflow-x-auto">
            {MODES.map((m) => (
              <Link
                key={m.id}
                href={`/play/${quizId}/${m.id}`}
                className={`px-3 py-1 rounded-full font-bold transition whitespace-nowrap ${
                  mode === m.id
                    ? "bg-purple-600 text-white shadow"
                    : "text-slate-300 hover:text-white hover:bg-white/5"
                }`}
              >
                {m.label}
              </Link>
            ))}
          </div>
        </div>

        {quizQuery.isLoading ? (
          <div className="py-24 flex items-center justify-center text-slate-400 gap-2 text-xs">
            <Loader2 className="w-5 h-5 animate-spin" /> Loading quiz…
          </div>
        ) : !quiz ? (
          <div className="py-24 text-center text-slate-400 text-xs">
            Quiz not found. <Link href="/play" className="text-cyan-400 underline">Browse quizzes</Link>
          </div>
        ) : (
          <>
            {mode === "space-race" && (
              <SpaceRaceMode quiz={quiz} onComplete={submitScore} onExit={() => (window.location.href = `/play/${quizId}/millionaire`)} />
            )}
            {mode === "millionaire" && (
              <MillionaireMode quiz={quiz} onComplete={submitScore} onExit={() => (window.location.href = `/play/${quizId}/speed-rush`)} />
            )}
            {mode === "speed-rush" && (
              <SpeedRushMode quiz={quiz} onComplete={submitScore} onExit={() => (window.location.href = `/play/${quizId}/tower-battle`)} />
            )}
            {mode === "tower-battle" && (
              <TowerBattleMode quiz={quiz} onComplete={submitScore} onExit={() => (window.location.href = `/play/${quizId}/survival`)} />
            )}
            {mode === "survival" && (
              <SurvivalMode quiz={quiz} onComplete={submitScore} onExit={() => (window.location.href = "/play")} />
            )}
          </>
        )}
      </main>
    </div>
  );
}
