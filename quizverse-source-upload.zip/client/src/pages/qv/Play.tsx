/**
 * QUIZVERSE Play hub — subject tabs, difficulty pills, search, sort, and quiz cards.
 */

import React, { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Navbar } from "@/components/qv/Navbar";
import { QuizCard } from "@/components/qv/QuizCard";
import { PinJoinDialog } from "@/components/qv/PinJoinDialog";
import { GRADE_BANDS, SUBJECTS, SubjectMeta } from "@/lib/quizverseData";
import { playClick } from "@/lib/sounds";
import { Search, Flame, Sparkles, Filter, Users, Loader2 } from "lucide-react";

export default function Play() {
  const [pinOpen, setPinOpen] = useState(false);
  const searchParam = new URLSearchParams(window.location.search);
  const [subject, setSubject] = useState(searchParam.get("subject") || "all");
  const [gradeBand, setGradeBand] = useState(searchParam.get("grade") || "all");
  const [difficulty, setDifficulty] = useState("all");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [sort, setSort] = useState<"popular" | "newest" | "top">("popular");

  React.useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 250);
    return () => clearTimeout(t);
  }, [search]);

  const quizzesQuery = trpc.quizzes.list.useQuery({
    subject: subject === "all" ? undefined : subject,
    gradeBand: gradeBand === "all" ? undefined : gradeBand as any,
    difficulty: difficulty === "all" ? undefined : difficulty,
    search: debounced || undefined,
    sort,
    limit: 60,
  });

  const quizzes = quizzesQuery.data || [];

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenPin={() => setPinOpen(true)} />
      <PinJoinDialog open={pinOpen} onOpenChange={setPinOpen} />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-6">
        {/* Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-500/30 via-teal-500/20 to-cyan-500/30 p-6 sm:p-8 border border-emerald-500/30 flex flex-col gap-2 shadow-xl">
          <span className="text-[10px] font-black uppercase tracking-wider text-emerald-300">🎮 Play Hub</span>
          <h1 className="text-2xl sm:text-4xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
            Pick a subject. Pick a mode. Start earning coins.
          </h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Carefully scaffolded quizzes for Nursery, Grades 1–2, Grades 3–5, Grades 6–8, and Grades 9–12 across Science, Math, English, Social Studies, and Computer Science. Each quiz can be played in any of the five mini-game modes.
          </p>
        </div>

        {/* Filter bar */}
        <div className="flex flex-col gap-3">
          {/* Subject pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => {
                playClick();
                setSubject("all");
              }}
              className={`px-3.5 py-1.5 rounded-full font-bold transition shrink-0 ${
                subject === "all" ? "bg-cyan-400 text-slate-950 shadow" : "bg-white/5 hover:bg-white/10 text-slate-300"
              }`}
            >
              All Subjects
            </button>
            {SUBJECTS.map((s) => (
              <button
                key={s.id}
                onClick={() => {
                  playClick();
                  setSubject(s.id);
                }}
                className={`px-3.5 py-1.5 rounded-full font-bold transition shrink-0 flex items-center gap-1 ${
                  subject === s.id
                    ? "bg-gradient-to-r " + s.gradient + " text-white shadow"
                    : "bg-white/5 hover:bg-white/10 text-slate-300"
                }`}
              >
                <span>{s.icon}</span> {s.name}
              </button>
            ))}
          </div>

          {/* Grade + search + difficulty + sort */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white/5 p-3 rounded-2xl border border-white/5 text-xs">
            <div className="flex items-center gap-1 w-full overflow-x-auto pb-1">
              <span className="text-slate-500 text-[11px] mr-1 shrink-0">Grade:</span>
              <button onClick={() => setGradeBand("all")} className={`px-2.5 py-1 rounded-full text-[11px] font-bold shrink-0 ${gradeBand === "all" ? "bg-cyan-400 text-slate-950" : "text-slate-400 hover:bg-white/5"}`}>All</button>
              {GRADE_BANDS.map((g) => (
                <button key={g.id} onClick={() => setGradeBand(g.id)} title={g.description} className={`px-2.5 py-1 rounded-full text-[11px] font-bold shrink-0 ${gradeBand === g.id ? "bg-cyan-400 text-slate-950" : "text-slate-400 hover:bg-white/5"}`}>
                  {g.short}
                </button>
              ))}
            </div>
            {/* Search */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search quizzes…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Difficulty */}
            <div className="flex items-center gap-1">
              <span className="text-slate-500 text-[11px] hidden sm:inline">Difficulty:</span>
              {["all", "easy", "medium", "hard"].map((d) => (
                <button
                  key={d}
                  onClick={() => {
                    playClick();
                    setDifficulty(d);
                  }}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold capitalize transition ${
                    difficulty === d ? "bg-purple-600 text-white" : "hover:bg-white/5 text-slate-400"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>

            {/* Sort */}
            <div className="flex items-center gap-1">
              <span className="text-slate-500 text-[11px] hidden sm:inline">Sort:</span>
              {[
                { id: "popular", label: "Most played" },
                { id: "newest", label: "Newest" },
                { id: "top", label: "Top score" },
              ].map((so) => (
                <button
                  key={so.id}
                  onClick={() => {
                    playClick();
                    setSort(so.id as any);
                  }}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition ${
                    sort === so.id ? "bg-slate-800 text-white border border-white/10" : "hover:bg-white/5 text-slate-400"
                  }`}
                >
                  {so.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Quizzes grid */}
        {quizzesQuery.isLoading ? (
          <div className="py-24 flex items-center justify-center text-slate-400 gap-2 text-xs">
            <Loader2 className="w-5 h-5 animate-spin" /> Loading quizzes…
          </div>
        ) : quizzes.length === 0 ? (
          <div className="py-20 text-center text-slate-400 text-xs flex flex-col items-center gap-3">
            <span className="text-4xl">🔍</span>
            <span className="font-bold">No quizzes found.</span>
            <span>Try a different subject or search term.</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {quizzes.map((q) => (
              <QuizCard key={q.id} quiz={q} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
