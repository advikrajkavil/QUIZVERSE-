/**
 * QUIZVERSE Player Profile — rank tier, XP progress, level, coins, stats
 * (games played, accuracy, streaks), equipped avatar/theme, and badges showcase.
 */

import React, { useEffect, useState } from "react";
import { Link } from "wouter";
import { Navbar } from "@/components/qv/Navbar";
import { PinJoinDialog } from "@/components/qv/PinJoinDialog";
import { AVATARS, BADGES, THEMES, RANK_TIERS, xpForNextLevel, rankFromXp } from "@/lib/quizverseData";
import {
  getPlayer,
  subscribePlayer,
  setName,
  resetPlayer,
  earnCoins,
} from "@/lib/playerStore";
import { playClick } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import {
  Trophy,
  Flame,
  Award,
  Gamepad2,
  CheckCircle,
  Coins,
  Shield,
  Palette,
  RotateCcw,
  Sparkles,
  CalendarDays,
  Medal,
  Target,
} from "lucide-react";

export default function Profile() {
  const [pinOpen, setPinOpen] = useState(false);
  const [player, setPlayerState] = useState(getPlayer());
  const [editing, setEditing] = useState(false);
  const [nameVal, setNameVal] = useState(player.name);

  useEffect(() => subscribePlayer(() => setPlayerState({ ...getPlayer() })), []);

  const rank = rankFromXp(player.xp);
  const nextXp = xpForNextLevel(player.level);
  const prevXp = xpForNextLevel(player.level - 1);
  const prog = nextXp > prevXp ? Math.min(100, Math.round(((player.xp - prevXp) / (nextXp - prevXp)) * 100)) : 100;
  const accuracy = player.totalAnswers ? Math.round((player.correctAnswers / player.totalAnswers) * 100) : 0;
  const equippedTheme = THEMES.find((t) => t.id === player.theme);
  const nextRank = RANK_TIERS.find((tier) => tier.minXp > player.xp);
  const modeLabel = player.bestScoreMode?.replace(/-/g, " ") || "No score yet";

  const saveName = () => {
    setName(nameVal);
    setEditing(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenPin={() => setPinOpen(true)} />
      <PinJoinDialog open={pinOpen} onOpenChange={setPinOpen} />

      <main className="relative flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-6 overflow-hidden">
        <div className="pointer-events-none absolute -top-28 -right-32 h-80 w-80 rounded-full bg-purple-600/20 blur-3xl" />
        <div className="pointer-events-none absolute top-96 -left-40 h-72 w-72 rounded-full bg-cyan-500/10 blur-3xl" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-64 opacity-20 [background-image:linear-gradient(rgba(139,92,246,.25)_1px,transparent_1px),linear-gradient(90deg,rgba(34,211,238,.2)_1px,transparent_1px)] [background-size:32px_32px] [mask-image:linear-gradient(to_bottom,black,transparent)]" />
        {/* Banner card */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-800/60 via-indigo-900/60 to-cyan-900/40 p-6 sm:p-8 border border-purple-800/60 shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <span className="w-20 h-20 rounded-3xl bg-gradient-to-br from-purple-500 via-indigo-500 to-cyan-400 flex items-center justify-center text-5xl shadow-xl shadow-purple-500/30 shrink-0">
              {player.avatar}
            </span>
            <div className="flex flex-col gap-1">
              {editing ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    maxLength={32}
                    value={nameVal}
                    onChange={(e) => setNameVal(e.target.value)}
                    className="py-1 px-3 rounded-xl bg-white/10 border border-white/20 text-white font-black text-lg focus:outline-none focus:border-cyan-300"
                  />
                  <Button size="sm" onClick={saveName} className="rounded-xl bg-cyan-300 text-slate-950 font-black text-xs">
                    Save
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
                    {player.name}
                  </h1>
                  <button onClick={() => setEditing(true)} className="text-[11px] text-slate-400 hover:text-white underline font-bold">
                    Edit
                  </button>
                </div>
              )}
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                <span className="px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1" style={{ color: rank.color, background: `${rank.color}20` }}>
                  <span>{rank.icon}</span> {rank.name}
                </span>
                <span className="text-purple-300">Lv {player.level}</span>
                <span className="text-slate-400">• {player.xp} XP</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:items-end gap-1 font-mono text-xs">
            <span className="text-amber-300 font-extrabold text-2xl flex items-center gap-1">
              🪙 {player.coins}
            </span>
            <span className="text-slate-400 text-[11px] font-sans">coins in wallet</span>
            <Link href="/rewards" className="mt-1 text-[11px] text-cyan-300 hover:underline font-bold font-sans">
              Spend in shop →
            </Link>
          </div>
        </div>

        {/* Level XP bar */}
        <div className="bg-slate-900/90 rounded-3xl p-5 border border-purple-800/60 shadow-2xl flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-black text-white flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" /> Level {player.level} Progress
            </span>
            <span className="font-mono text-slate-400 text-[11px]">{player.xp} / {nextXp} XP ({prog}%)</span>
          </div>
          <div className="h-3 rounded-full bg-slate-800 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 transition-all duration-500" style={{ width: `${prog}%` }} />
          </div>
          <span className="text-[10px] text-slate-500">Every correct answer adds XP and coins. Streaks earn bonuses.</span>
        </div>

        {/* Player journey cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-3xl bg-gradient-to-br from-amber-500/20 to-orange-500/5 border border-amber-400/30 p-4 flex flex-col gap-2 shadow-xl">
            <div className="flex items-center justify-between"><CalendarDays className="w-5 h-5 text-amber-300" /><span className="text-[10px] uppercase font-black text-amber-200">Daily streak</span></div>
            <span className="text-3xl font-black text-white">{player.streak} days</span>
            <p className="text-[11px] text-slate-400">Best streak: <b className="text-amber-200">{player.bestStreak} days</b>. Keep playing today to protect it.</p>
          </div>
          <div className="rounded-3xl bg-gradient-to-br from-cyan-500/20 to-blue-500/5 border border-cyan-400/30 p-4 flex flex-col gap-2 shadow-xl">
            <div className="flex items-center justify-between"><Target className="w-5 h-5 text-cyan-300" /><span className="text-[10px] uppercase font-black text-cyan-200">Best score</span></div>
            <span className="text-3xl font-black text-white">{player.bestScore.toLocaleString()}</span>
            <p className="text-[11px] text-slate-400">Top run in <b className="text-cyan-200 capitalize">{modeLabel}</b>.</p>
          </div>
          <div className="rounded-3xl bg-gradient-to-br from-purple-500/20 to-pink-500/5 border border-purple-400/30 p-4 flex flex-col gap-2 shadow-xl">
            <div className="flex items-center justify-between"><Medal className="w-5 h-5 text-purple-300" /><span className="text-[10px] uppercase font-black text-purple-200">Next rank</span></div>
            <span className="text-xl font-black text-white">{nextRank ? `${nextRank.icon} ${nextRank.name}` : "👑 Max rank"}</span>
            <p className="text-[11px] text-slate-400">{nextRank ? `${Math.max(0, nextRank.minXp - player.xp).toLocaleString()} XP to unlock.` : "You reached the top of the ladder."}</p>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          {[
            { value: player.correctAnswers, label: "Correct answers", icon: CheckCircle, color: "text-emerald-300" },
            { value: `${accuracy}%`, label: "Accuracy", icon: Award, color: "text-cyan-300" },
            { value: `${player.streak} (best ${player.bestStreak})`, label: "Streak 🔥", icon: Flame, color: "text-amber-300" },
            { value: player.gamesPlayed, label: "Game sessions", icon: Gamepad2, color: "text-purple-300" },
          ].map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="p-4 rounded-3xl bg-slate-900/90 border border-purple-800/50 flex flex-col gap-1 items-center shadow-xl">
                <Icon className={`w-5 h-5 ${s.color}`} />
                <div className={`text-xl font-black font-mono ${s.color}`}>{s.value}</div>
                <div className="text-[11px] text-slate-400">{s.label}</div>
              </div>
            );
          })}
        </div>

        {/* Badges */}
        <section className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" /> Badges ({player.badgesOwned.length}/{BADGES.length})
            </h2>
            <Link href="/rewards" className="text-xs text-purple-300 font-bold hover:underline">
              How to earn them →
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {BADGES.map((b) => {
              const unlocked = player.badgesOwned.includes(b.id);
              return (
                <div
                  key={b.id}
                  className={`p-3 rounded-2xl border flex items-center gap-3 text-xs ${
                    unlocked
                      ? "bg-purple-900/40 border-purple-600/60 shadow-lg shadow-purple-500/10"
                      : "bg-white/5 border-white/5 opacity-50 grayscale"
                  }`}
                >
                  <span className="text-3xl shrink-0">{b.icon}</span>
                  <div>
                    <div className="font-black text-white text-xs">{b.name}</div>
                    <div className="text-[10px] text-slate-400 line-clamp-1">{b.description}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Rank ladder */}
        <section className="rounded-3xl bg-slate-900/90 border border-purple-800/50 p-5 shadow-2xl">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-black text-white flex items-center gap-2"><Trophy className="w-5 h-5 text-amber-300" /> Rank ladder</h2>
            <span className="text-[11px] text-slate-400">{player.xp.toLocaleString()} total XP</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {RANK_TIERS.map((tier) => {
              const reached = player.xp >= tier.minXp;
              return <div key={tier.name} className={`rounded-2xl p-3 border text-center transition ${reached ? "bg-white/10 border-purple-400/50" : "bg-black/10 border-white/5 opacity-45"}`}><div className="text-2xl">{tier.icon}</div><div className="text-[11px] font-black text-white mt-1">{tier.name}</div><div className="text-[10px] font-mono text-slate-400">{tier.minXp.toLocaleString()} XP</div></div>;
            })}
          </div>
        </section>

        {/* Equipped theme card */}
        <div className="rounded-3xl bg-slate-900/90 border border-white/5 p-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <Palette className="w-5 h-5 text-cyan-300" />
            <div>
              <span className="font-bold text-white">Active Theme: {equippedTheme?.name || "Nebula Purple"}</span>
              <p className="text-[11px] text-slate-400">{equippedTheme?.description}</p>
            </div>
          </div>
          <Link href="/rewards" className="px-4 py-2 rounded-2xl bg-white/10 hover:bg-white/15 font-bold shrink-0">
            Change theme →
          </Link>
        </div>

        {/* Danger zone */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={() => {
              if (confirm("Reset all local progress, coins and badges?")) resetPlayer();
            }}
            className="text-[11px] text-slate-600 hover:text-rose-400 transition"
          >
            Reset local stats
          </button>
        </div>
      </main>
    </div>
  );
}
