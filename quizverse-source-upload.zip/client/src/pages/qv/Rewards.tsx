/**
 * QUIZVERSE Rewards shop — avatars (blooks) with coins, collectible badges,
 * and live-switching visual themes.
 */

import React, { useEffect, useState } from "react";
import { Link } from "wouter";
import { Navbar } from "@/components/qv/Navbar";
import { PinJoinDialog } from "@/components/qv/PinJoinDialog";
import { AVATARS, BADGES, THEMES } from "@/lib/quizverseData";
import {
  getPlayer,
  subscribePlayer,
  buyAvatar,
  equipAvatar,
  buyTheme,
  equipTheme,
  earnCoins,
} from "@/lib/playerStore";
import { playClick, playVictory } from "@/lib/sounds";
import { Button } from "@/components/ui/button";
import { Gift, Lock, Check, Sparkles, Coins, Palette, Shield, Flame, Trophy, Star } from "lucide-react";
import confetti from "canvas-confetti";

export default function Rewards() {
  const [pinOpen, setPinOpen] = useState(false);
  const [player, setPlayerState] = useState(getPlayer());
  const [tab, setTab] = useState<"avatars" | "badges" | "themes">("avatars");
  const [banner, setBanner] = useState<string | null>(null);

  useEffect(() => subscribePlayer(() => setPlayerState({ ...getPlayer() })), []);

  const toast = (msg: string) => {
    setBanner(msg);
    setTimeout(() => setBanner(null), 2200);
  };

  const handleBuyAvatar = (id: string, price: number) => {
    playClick();
    if (buyAvatar(id)) {
      try {
        confetti({ particleCount: 50, spread: 60 });
      } catch {}
      playVictory();
      toast("Unlocked! Click Equip to wear it.");
    } else {
      toast("Not enough coins — answer more questions to earn some!");
    }
  };

  const handleEquipAvatar = (emoji: string) => {
    playClick();
    equipAvatar(emoji);
    toast("Avatar equipped!");
  };

  const handleBuyTheme = (id: string, price: number) => {
    playClick();
    if (buyTheme(id)) {
      toast("Theme unlocked! Equip it now.");
    } else {
      toast("Not enough coins for this theme.");
    }
  };

  const handleEquipTheme = (id: string) => {
    playClick();
    equipTheme(id);
    toast("Theme applied!");
  };

  const tierColors: Record<string, string> = {
    Starter: "text-slate-400 border-slate-600/40",
    Rare: "text-cyan-300 border-cyan-500/40",
    Epic: "text-purple-300 border-purple-500/40",
    Legendary: "text-amber-300 border-amber-500/40",
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenPin={() => setPinOpen(true)} />
      <PinJoinDialog open={pinOpen} onOpenChange={setPinOpen} />

      <main className="relative flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-6 overflow-hidden">
        <div className="pointer-events-none absolute -top-40 left-1/3 h-96 w-96 rounded-full bg-fuchsia-600/20 blur-3xl" />
        <div className="pointer-events-none absolute top-80 -right-40 h-96 w-96 rounded-full bg-cyan-500/10 blur-3xl" />
        <div className="pointer-events-none absolute inset-0 opacity-15 [background-image:radial-gradient(circle_at_20%_20%,#fff_1px,transparent_1px),radial-gradient(circle_at_80%_35%,#67e8f9_1px,transparent_1px),radial-gradient(circle_at_55%_75%,#f0abfc_1px,transparent_1px)] [background-size:110px_110px,150px_150px,190px_190px]" />
        {banner && (
          <div className="fixed top-16 right-4 z-50 px-4 py-2 rounded-2xl bg-cyan-300 text-slate-950 font-black text-xs shadow-xl animate-fade-in">
            {banner}
          </div>
        )}

        {/* Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-pink-500/30 via-purple-600/30 to-indigo-500/30 p-6 sm:p-8 border border-pink-400/30 flex flex-col gap-2 shadow-xl">
          <span className="text-[10px] font-black uppercase tracking-wider text-pink-300">🎁 Rewards & Shop</span>
          <h1 className="text-2xl sm:text-4xl font-black text-white" style={{ fontFamily: "Fredoka, Nunito, sans-serif" }}>
            Spend coins on blooks, badges, and themes
          </h1>
          <p className="text-xs text-slate-300 max-w-xl">
            You earn coins by answering questions in any game mode or live competition. Collect them all!
          </p>
          <div className="flex items-center gap-2 pt-1 font-mono text-xs">
            <span className="px-3 py-1.5 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 font-extrabold flex items-center gap-1.5 text-sm">
              🪙 {player.coins} coins
            </span>
            <span className="text-slate-400">• {player.xp} XP • Lv{player.level}</span>
          </div>
        </div>

        {/* Progress snapshot */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { icon: Coins, value: player.coins.toLocaleString(), label: "Coins to spend", color: "text-amber-300", bg: "from-amber-500/20" },
            { icon: Sparkles, value: player.xp.toLocaleString(), label: "Total XP", color: "text-cyan-300", bg: "from-cyan-500/20" },
            { icon: Flame, value: `${player.streak} days`, label: "Current streak", color: "text-orange-300", bg: "from-orange-500/20" },
            { icon: Trophy, value: `${player.badgesOwned.length}/${BADGES.length}`, label: "Badges earned", color: "text-purple-300", bg: "from-purple-500/20" },
          ].map((item) => {
            const Icon = item.icon;
            return <div key={item.label} className={`rounded-2xl bg-gradient-to-br ${item.bg} to-transparent border border-white/10 p-4 flex items-center gap-3 shadow-lg`}><Icon className={`w-5 h-5 ${item.color}`} /><div><div className="font-black text-white font-mono">{item.value}</div><div className="text-[10px] text-slate-400">{item.label}</div></div></div>;
          })}
        </section>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-white/5 p-1 rounded-full border border-white/10 w-fit text-xs font-bold">
          <button
            onClick={() => setTab("avatars")}
            className={`px-4 py-1.5 rounded-full transition ${tab === "avatars" ? "bg-purple-600 text-white" : "text-slate-300"}`}
          >
            Blooks ({AVATARS.length})
          </button>
          <button
            onClick={() => setTab("badges")}
            className={`px-4 py-1.5 rounded-full transition ${tab === "badges" ? "bg-purple-600 text-white" : "text-slate-300"}`}
          >
            Badges ({BADGES.length})
          </button>
          <button
            onClick={() => setTab("themes")}
            className={`px-4 py-1.5 rounded-full transition ${tab === "themes" ? "bg-purple-600 text-white" : "text-slate-300"}`}
          >
            Themes ({THEMES.length})
          </button>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-slate-400"><Star className="w-3.5 h-3.5 text-amber-300" /> Earn more coins by playing daily challenges, winning live games, and keeping your streak alive.</div>

        {/* AVATARS */}
        {tab === "avatars" && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {AVATARS.map((a) => {
              const owned = player.avatarsOwned.includes(a.id);
              const equipped = player.avatar === a.emoji;
              return (
                <div
                  key={a.id}
                  className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-purple-500/40 transition flex flex-col items-center gap-2 text-center text-xs"
                >
                  <span className="text-5xl">{a.emoji}</span>
                  <span className="font-black text-white text-sm">{a.name}</span>
                  <span className={`text-[10px] font-bold uppercase border px-2 py-0.5 rounded-full ${tierColors[a.tier]}`}>
                    {a.tier}
                  </span>
                  <p className="text-[10px] text-slate-400 line-clamp-2">{a.description}</p>
                  <div className="mt-auto w-full pt-1">
                    {equipped ? (
                      <span className="block w-full py-2 rounded-xl bg-cyan-400/20 text-cyan-300 font-black text-[11px] border border-cyan-400/40">
                        EQUIPPED
                      </span>
                    ) : owned ? (
                      <Button
                        size="sm"
                        onClick={() => handleEquipAvatar(a.emoji)}
                        className="w-full rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-[11px]"
                      >
                        Equip
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        onClick={() => handleBuyAvatar(a.id, a.price)}
                        className="w-full rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-[11px] flex items-center justify-center gap-1"
                      >
                        <Coins className="w-3 h-3" /> {a.price === 0 ? "FREE" : a.price}
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* BADGES */}
        {tab === "badges" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {BADGES.map((b) => {
              const unlocked = player.badgesOwned.includes(b.id);
              return (
                <div
                  key={b.id}
                  className={`p-4 rounded-2xl border transition flex items-start gap-3 text-xs ${
                    unlocked
                      ? "bg-purple-900/40 border-purple-600/60 shadow-lg shadow-purple-500/10"
                      : "bg-white/5 border-white/5 opacity-60"
                  }`}
                >
                  <span className="text-3xl shrink-0">{b.icon}</span>
                  <div className="flex flex-col gap-1 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-black text-white text-sm">{b.name}</span>
                      {unlocked ? (
                        <span className="text-[10px] font-bold text-emerald-300 flex items-center gap-0.5">
                          <Check className="w-3 h-3" /> UNLOCKED
                        </span>
                      ) : (
                        <Lock className="w-3.5 h-3.5 text-slate-500" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">{b.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* THEMES */}
        {tab === "themes" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {THEMES.map((t) => {
              const owned = player.themesOwned.includes(t.id);
              const equipped = player.theme === t.id;
              return (
                <div
                  key={t.id}
                  className="rounded-2xl border border-white/10 overflow-hidden flex flex-col text-xs bg-slate-900"
                >
                  <div className={`h-24 bg-gradient-to-r ${t.gradient} p-3 flex items-start justify-between text-white`}>
                    <span className="font-black text-sm drop-shadow">{t.name}</span>
                    {equipped && (
                      <span className="text-[10px] font-bold bg-black/40 px-2 py-0.5 rounded-full backdrop-blur">
                        ACTIVE
                      </span>
                    )}
                  </div>
                  <div className="p-4 flex flex-col gap-2 flex-1">
                    <p className="text-[11px] text-slate-400 flex-1">{t.description}</p>
                    <div className="mt-auto">
                      {equipped ? (
                        <span className="block w-full text-center py-2 rounded-xl bg-cyan-400/20 text-cyan-300 font-black text-[11px] border border-cyan-400/40">
                          EQUIPPED
                        </span>
                      ) : owned ? (
                        <Button
                          size="sm"
                          onClick={() => handleEquipTheme(t.id)}
                          className="w-full rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-[11px]"
                        >
                          Apply Theme
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleBuyTheme(t.id, t.price)}
                          className="w-full rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-[11px] flex items-center justify-center gap-1"
                        >
                          <Coins className="w-3 h-3" /> {t.price} coins
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
