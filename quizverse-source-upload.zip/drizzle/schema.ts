import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * QUIZVERSE quizzes across five subject areas.
 * Questions JSON array: [{ id, text, options: [4 strings], correct: 0..3, explanation?, timeLimit? }]
 */
export const quizzes = mysqlTable("quizzes", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 64 }).notNull().unique(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description"),
  subject: mysqlEnum("subject", ["science", "math", "english", "social", "cs"]).default("science").notNull(),
  gradeBand: mysqlEnum("gradeBand", ["nursery", "grade1", "grade2", "3-5", "6-8", "9-12"]).default("6-8").notNull(),
  topic: varchar("topic", { length: 128 }).default("General").notNull(),
  learningObjectives: text("learningObjectives"),
  tags: text("tags"),
  estimatedMinutes: int("estimatedMinutes").default(5).notNull(),
  cover: varchar("cover", { length: 128 }).default("🧠").notNull(),
  questions: text("questions").notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("medium").notNull(),
  isFeatured: int("isFeatured").default(0).notNull(),
  isDaily: int("isDaily").default(0).notNull(),
  authorName: varchar("authorName", { length: 128 }).notNull().default("Quizverse"),
  authorOpenId: varchar("authorOpenId", { length: 64 }),
  timesPlayed: int("timesPlayed").default(0).notNull(),
  avgScore: int("avgScore").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = typeof quizzes.$inferInsert;

/**
 * Kahoot-style live multiplayer rooms with 6-digit PIN codes.
 * status: 'waiting' -> 'question' -> 'scoreboard' -> ... -> 'ended'
 */
export const gameRooms = mysqlTable("game_rooms", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 8 }).notNull().unique(),
  quizId: int("quizId").notNull(),
  hostName: varchar("hostName", { length: 128 }).notNull().default("Host"),
  hostOpenId: varchar("hostOpenId", { length: 64 }),
  status: mysqlEnum("status", ["waiting", "question", "scoreboard", "ended"]).default("waiting").notNull(),
  currentQuestion: int("currentQuestion").default(0).notNull(),
  questionStartedAt: timestamp("questionStartedAt"),
  answers: text("answers"), // JSON { [playerId]: { optionIndex, ms, correct, points } }
  players: text("players"), // JSON [{ id, name, avatar, score, streak }]
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GameRoom = typeof gameRooms.$inferSelect;
export type InsertGameRoom = typeof gameRooms.$inferInsert;

/**
 * Global and weekly leaderboards.
 */
export const leaderboard = mysqlTable("leaderboard", {
  id: int("id").autoincrement().primaryKey(),
  userId: varchar("userId", { length: 64 }),
  name: varchar("name", { length: 128 }).notNull(),
  avatar: varchar("avatar", { length: 64 }).default("🚀").notNull(),
  score: int("score").default(0).notNull(),
  coins: int("coins").default(0).notNull(),
  period: mysqlEnum("period", ["alltime", "weekly"]).default("alltime").notNull(),
  rankTitle: varchar("rankTitle", { length: 64 }).default("Novice").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LeaderboardEntry = typeof leaderboard.$inferSelect;
export type InsertLeaderboardEntry = typeof leaderboard.$inferInsert;
