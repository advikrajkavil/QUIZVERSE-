import { InsertQuiz } from "../drizzle/schema";
import { createQuiz, getQuizBySlug, updateQuiz, listQuizzes } from "../server/db";

type QuizSeed = Omit<InsertQuiz, "id" | "createdAt" | "updatedAt">;
type GradeBand = "3-5" | "6-8" | "9-12";
type Subject = "science" | "math" | "english" | "social" | "cs";
type TopicSpec = { subject: Subject; title: string; topic: string; cover: string; difficulty: "easy" | "medium" | "hard" };

const slugify = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 58);
const q = (id: string, text: string, options: [string, string, string, string], correct: number, explanation: string) => ({ id, text, options, correct, explanation, timeLimit: 22 });
const spreadAnswers = (questions: ReturnType<typeof q>[], seed: number) => questions.map((question, index) => {
  const target = (seed + index) % 4;
  const options = [...question.options];
  const [correctOption] = options.splice(question.correct, 1);
  options.splice(target, 0, correctOption);
  return { ...question, options: options as [string, string, string, string], correct: target };
});

const topics = (subject: Subject, cover: string, difficulty: TopicSpec["difficulty"], values: string): TopicSpec[] => values.split("|").map((title) => ({ subject, title, topic: title, cover, difficulty }));

const ADDITIONS: Record<GradeBand, TopicSpec[]> = {
  "3-5": [
    ...topics("science", "🔬", "easy", "Animal Adaptations|Plant Parts & Functions|Rocks & Minerals|Earth's Water Cycle"),
    ...topics("math", "🔢", "easy", "Place Value & Rounding|Division Strategies|Decimals to Tenths|Data & Graphs"),
    ...topics("english", "📚", "easy", "Main Idea & Details|Parts of Speech|Narrative Story Elements|Spelling Patterns"),
    ...topics("social", "🗺️", "easy", "Maps & Landforms|Local Government|Communities Past & Present|Historical Primary Sources"),
    ...topics("cs", "💻", "easy", "Computational Thinking|Sequencing & Events|Online Research Skills|Digital Files & Folders"),
  ],
  "6-8": [
    ...topics("science", "🧪", "medium", "Cells & Microscopes|Food Webs & Energy Flow|Earth's Rock Cycle|Force & Motion"),
    ...topics("math", "📊", "medium", "Integers & Rational Numbers|Expressions & Equations|Probability Basics|Statistics & Variability"),
    ...topics("english", "✍️", "medium", "Text Structure|Point of View|Research & Citations|Sentence Variety"),
    ...topics("social", "🏺", "medium", "Medieval Civilizations|Industrial Revolution|Government & Rights|Human Geography"),
    ...topics("cs", "🖥️", "medium", "Variables & Data Types|Loops & Conditions|Networks & Packets|Ethical Technology"),
  ],
  "9-12": [
    ...topics("science", "⚗️", "hard", "Chemical Reactions|Genetics & Heredity|Ecology & Population|Newton's Laws|Waves & Sound|Climate Change Science"),
    ...topics("math", "📈", "hard", "Linear Functions|Quadratic Functions|Systems of Equations|Trigonometry Basics|Calculus Concepts"),
    ...topics("english", "🖋️", "hard", "Rhetorical Analysis|Literary Movements|Poetry Analysis|Synthesis Writing|Grammar & Style"),
    ...topics("social", "🌐", "hard", "World War History|Constitutional Principles|Comparative Government|Macroeconomics|Researching Historical Claims"),
    ...topics("cs", "👨‍💻", "hard", "Object-Oriented Design|Recursion|Databases & SQL|Cybersecurity Principles|Machine Learning Concepts"),
  ],
};

function questionSet(subject: Subject, topic: string, grade: GradeBand) {
  const suffix = ` in ${topic}`;
  if (subject === "science") return [
    q("q1", `Which practice helps scientists investigate a question${suffix}?`, ["Collecting evidence", "Changing every variable", "Ignoring results", "Guessing once"], 0, "Scientists collect repeatable evidence and use it to evaluate explanations."),
    q("q2", `Which statement is a testable claim about ${topic}?`, ["It is interesting", "If light increases, the plant may grow faster", "Everyone likes it", "It is the best"], 1, "A testable claim connects variables that can be observed or measured."),
    q("q3", `What should a strong scientific explanation about ${topic} include?`, ["Evidence and reasoning", "Only an opinion", "A colorful title", "No observations"], 0, "Evidence supports a claim, while reasoning explains the connection."),
    q("q4", `Why do scientists repeat investigations about ${topic}?`, ["To improve confidence in results", "To erase data", "To avoid measuring", "To guarantee a favorite answer"], 0, "Repeated investigations help reveal patterns and make results more reliable."),
  ];
  if (subject === "math") return [
    q("q1", `Which strategy is most useful when solving a problem about ${topic}?`, ["Define the quantities and relationships", "Skip all units", "Choose numbers randomly", "Copy the first answer"], 0, "Identifying quantities and relationships helps select a valid method."),
    q("q2", `What should you do first when checking a solution in ${topic}?`, ["Substitute or estimate to test it", "Erase the work", "Change the question", "Ignore the units"], 0, "Substitution or estimation can reveal whether an answer is reasonable."),
    q("q3", `A mathematical model for ${topic} should represent…`, ["Important relationships", "Only decoration", "A random symbol", "An unrelated story"], 0, "Models simplify situations while preserving useful mathematical relationships."),
    q("q4", `Why label units when working with ${topic}?`, ["They communicate what a number measures", "They make numbers larger", "They replace reasoning", "They guarantee an answer"], 0, "Units give numerical results meaning and help catch mistakes."),
  ];
  if (subject === "english") return [
    q("q1", `What is a strong reading or writing move for ${topic}?`, ["Use specific evidence", "Make an unsupported claim", "Ignore the audience", "Remove all details"], 0, "Specific evidence makes an interpretation or argument clearer and more convincing."),
    q("q2", `Which revision usually improves writing about ${topic}?`, ["Clarifying the main idea", "Adding unrelated sentences", "Removing all verbs", "Repeating one word"], 0, "A clear main idea gives the reader a strong path through the writing."),
    q("q3", `A reliable source about ${topic} should be…`, ["Relevant and supported by evidence", "Anonymous and unsourced", "Based only on a rumor", "Impossible to check"], 0, "Relevance, evidence, and checkable authorship support reliable research."),
    q("q4", `Why does audience matter when communicating about ${topic}?`, ["It shapes word choice and explanation", "It changes factual accuracy", "It removes the need to revise", "It makes grammar irrelevant"], 0, "Writers adapt tone, detail, and examples to help a particular audience understand."),
  ];
  if (subject === "social") return [
    q("q1", `When studying ${topic}, what is the best first step?`, ["Ask who created the source and why", "Assume every claim is true", "Ignore the date", "Use only one opinion"], 0, "Source, purpose, and context help historians and social scientists evaluate claims."),
    q("q2", `A primary source about ${topic} is…`, ["Evidence from the time or event", "A later textbook summary only", "A fictional rumor", "A blank page"], 0, "Primary sources come directly from the period, event, or participant."),
    q("q3", `Why compare multiple perspectives on ${topic}?`, ["To identify context and disagreement", "To avoid evidence", "To make all claims identical", "To remove questions"], 0, "Comparing perspectives reveals context, bias, and complexity."),
    q("q4", `A responsible conclusion about ${topic} should be based on…`, ["Evidence and clear reasoning", "Popularity alone", "A single unexplained claim", "A guess"], 0, "Evidence-based reasoning supports responsible conclusions."),
  ];
  return [
    q("q1", `Which concept is central when learning about ${topic}?`, ["Breaking problems into steps", "Changing code without testing", "Ignoring inputs", "Avoiding documentation"], 0, "Computing relies on structured problem solving, testing, and clear instructions."),
    q("q2", `What makes a solution to ${topic} easier to maintain?`, ["Clear names and small tested parts", "One giant unexplained block", "Repeated mystery values", "No comments ever"], 0, "Readable structure and tested components make programs easier to understand and change."),
    q("q3", `Why test a program or model about ${topic}?`, ["To find and fix unexpected behavior", "To hide errors", "To remove all inputs", "To avoid users"], 0, "Testing compares actual behavior with expected behavior and reveals bugs."),
    q("q4", `A responsible technology decision about ${topic} considers…`, ["Users, privacy, safety, and impact", "Only speed", "Only appearance", "No consequences"], 0, "Good computing practice considers people, data, safety, and wider impact."),
  ];
}

function makeQuiz(gradeBand: GradeBand, spec: TopicSpec, index: number): QuizSeed {
  const slug = `${gradeBand.replace("-", "-")}-${slugify(spec.subject + "-" + spec.title)}`;
  return {
    slug,
    title: spec.title,
    description: `A ${gradeBand} learning challenge covering ${spec.topic} with explanations and review-friendly practice.`,
    subject: spec.subject,
    gradeBand,
    topic: spec.topic,
    learningObjectives: `Build grade ${gradeBand} understanding of ${spec.topic}, explain key ideas, and apply them to new problems.`,
    tags: `${spec.subject},${slugify(spec.topic).replace(/-/g, ",")},practice,review`,
    estimatedMinutes: 6 + (index % 5),
    cover: spec.cover,
    difficulty: spec.difficulty,
    isFeatured: index < 2 ? 1 : 0,
    isDaily: index === 0 ? 1 : 0,
    authorName: "QUIZVERSE Curriculum",
    timesPlayed: 0,
    avgScore: 0,
    questions: JSON.stringify(spreadAnswers(questionSet(spec.subject, spec.topic, gradeBand), index)),
  } as QuizSeed;
}

async function main() {
  const current = await listQuizzes({ limit: 60 });
  const counts = { "3-5": 0, "6-8": 0, "9-12": 0 } as Record<GradeBand, number>;
  for (const quiz of current) if (quiz.gradeBand in counts) counts[quiz.gradeBand as GradeBand]++;

  let created = 0;
  let updated = 0;
  for (const gradeBand of ["3-5", "6-8", "9-12"] as GradeBand[]) {
    const needed = Math.max(0, 30 - counts[gradeBand]);
    const pool = ADDITIONS[gradeBand];
    if (needed > pool.length) throw new Error(`Not enough topic definitions for ${gradeBand}`);
    for (let i = 0; i < needed; i++) {
      const quiz = makeQuiz(gradeBand, pool[i], i);
      const existing = await getQuizBySlug(quiz.slug);
      if (existing) { await updateQuiz(quiz.slug, quiz); updated++; }
      else { await createQuiz(quiz); created++; }
    }
    console.log(`${gradeBand}: ${counts[gradeBand]} existing + ${needed} added = 30 topics`);
  }
  console.log(`Catalog complete: ${created} created, ${updated} refreshed.`);
}

main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
