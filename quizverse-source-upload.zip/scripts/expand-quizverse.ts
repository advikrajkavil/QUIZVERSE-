import { InsertQuiz } from "../drizzle/schema";
import { createQuiz, getQuizBySlug, updateQuiz } from "../server/db";

type QuizSeed = Omit<InsertQuiz, "id" | "createdAt" | "updatedAt">;

const q = (id: string, text: string, options: [string, string, string, string], correct: number, explanation: string, timeLimit = 20) => ({
  id, text, options, correct, explanation, timeLimit,
});

const EXPANSION: QuizSeed[] = [
  {
    slug: "science-weather-climate",
    title: "Weather, Climate & Storms",
    description: "Read the sky, understand climate patterns, and explore the science behind storms.",
    subject: "science", gradeBand: "3-5", topic: "Weather & climate", learningObjectives: "Distinguish weather from climate and identify common weather processes.", tags: "weather,climate,storms,earth-science", estimatedMinutes: 7, cover: "🌦️", difficulty: "easy", authorName: "WeatherWise", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "What instrument measures temperature?", ["Barometer", "Thermometer", "Anemometer", "Rain gauge"], 1, "A thermometer measures how hot or cold something is."),
      q("q2", "What is moving air called?", ["Wind", "Humidity", "Pressure", "Fog"], 0, "Wind is air moving from one place to another."),
      q("q3", "Which cloud type is often linked with thunderstorms?", ["Cirrus", "Cumulus", "Cumulonimbus", "Stratus"], 2, "Tall cumulonimbus clouds can produce heavy rain, lightning, and thunder."),
      q("q4", "Climate describes the usual weather of a place over what time?", ["A few minutes", "One afternoon", "Many years", "One storm"], 2, "Climate describes long-term patterns, while weather changes day to day."),
    ]),
  },
  {
    slug: "science-human-body",
    title: "Human Body Systems",
    description: "Explore the organs and systems that help the human body move, breathe, and grow.",
    subject: "science", gradeBand: "6-8", topic: "Human biology", learningObjectives: "Connect major organs to their body systems and explain basic body functions.", tags: "biology,body,organs,health", estimatedMinutes: 8, cover: "🫀", difficulty: "medium", authorName: "BioBrianna", isFeatured: 1, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "Which organ pumps blood around the body?", ["Lung", "Heart", "Liver", "Kidney"], 1, "The heart is a muscular pump that circulates blood."),
      q("q2", "Where does most gas exchange happen?", ["Stomach", "Small intestine", "Alveoli in the lungs", "Bone marrow"], 2, "Tiny alveoli exchange oxygen and carbon dioxide with the blood."),
      q("q3", "Which system sends electrical signals through the body?", ["Nervous system", "Digestive system", "Skeletal system", "Endocrine system"], 0, "The brain, spinal cord, and nerves form the nervous system."),
      q("q4", "What is the main job of red blood cells?", ["Fight every bone", "Carry oxygen", "Digest food", "Make hormones"], 1, "Hemoglobin in red blood cells binds and transports oxygen."),
    ]),
  },
  {
    slug: "science-energy-matter",
    title: "Energy, Matter & Simple Machines",
    description: "Test your understanding of states of matter, energy transfers, forces, and machines.",
    subject: "science", gradeBand: "6-8", topic: "Physical science", learningObjectives: "Classify matter, identify energy transformations, and apply force concepts.", tags: "energy,matter,force,physics", estimatedMinutes: 8, cover: "⚙️", difficulty: "medium", authorName: "PhysicsPioneer", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "Which state of matter has a fixed volume but takes the shape of its container?", ["Solid", "Liquid", "Gas", "Plasma"], 1, "Liquids keep their volume but flow to match the container."),
      q("q2", "What happens to a stretched rubber band when released?", ["Chemical energy becomes sound only", "Elastic potential energy becomes motion", "Light becomes matter", "Gravity disappears"], 1, "Stored elastic potential energy changes into kinetic energy."),
      q("q3", "A ramp is an example of which simple machine?", ["Lever", "Pulley", "Inclined plane", "Wheel and axle"], 2, "An inclined plane helps move objects up or down gradually."),
      q("q4", "What force pulls objects toward Earth?", ["Friction", "Magnetism", "Gravity", "Buoyancy"], 2, "Gravity attracts objects toward the center of Earth."),
    ]),
  },
  {
    slug: "math-multiplication-mastery",
    title: "Multiplication Mastery",
    description: "Build fast, accurate multiplication strategies with factors, arrays, and patterns.",
    subject: "math", gradeBand: "3-5", topic: "Multiplication & factors", learningObjectives: "Use multiplication facts, properties, and factor relationships to solve problems.", tags: "multiplication,factors,fluency,elementary-math", estimatedMinutes: 6, cover: "✖️", difficulty: "easy", authorName: "NumNinja", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "What is 7 × 8?", ["48", "54", "56", "64"], 2, "Seven groups of eight equal 56."),
      q("q2", "Which number is a factor of 36?", ["5", "7", "9", "11"], 2, "36 ÷ 9 = 4, so 9 is a factor of 36."),
      q("q3", "What is 4 × 25?", ["50", "75", "100", "125"], 2, "Four groups of 25 make 100."),
      q("q4", "Which property explains 3 × 5 = 5 × 3?", ["Distributive", "Commutative", "Associative", "Identity"], 1, "The commutative property lets factors switch order."),
    ]),
  },
  {
    slug: "math-geometry-foundations",
    title: "Geometry Foundations",
    description: "Angles, area, perimeter, symmetry, and shapes — sharpen your geometry toolkit.",
    subject: "math", gradeBand: "3-5", topic: "Geometry & measurement", learningObjectives: "Classify shapes and calculate perimeter, area, and angle relationships.", tags: "geometry,area,perimeter,angles", estimatedMinutes: 8, cover: "📐", difficulty: "medium", authorName: "ShapeShifter", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "How many degrees are in a right angle?", ["45", "90", "180", "360"], 1, "A right angle measures exactly 90 degrees."),
      q("q2", "What is the perimeter of a square with side length 6?", ["12", "18", "24", "36"], 2, "A square has four equal sides: 4 × 6 = 24."),
      q("q3", "What is the area of a rectangle 5 units by 4 units?", ["9", "18", "20", "25"], 2, "Area is length × width: 5 × 4 = 20 square units."),
      q("q4", "A triangle has how many sides?", ["2", "3", "4", "5"], 1, "A triangle is a polygon with three sides and three angles."),
    ]),
  },
  {
    slug: "math-ratios-proportions",
    title: "Ratios & Proportions",
    description: "Compare quantities, scale recipes, and solve real-world proportional problems.",
    subject: "math", gradeBand: "6-8", topic: "Ratios & proportional reasoning", learningObjectives: "Represent equivalent ratios and solve proportions using multiple strategies.", tags: "ratios,proportions,percent,algebra", estimatedMinutes: 8, cover: "⚖️", difficulty: "medium", authorName: "RatioRanger", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "Which ratio is equivalent to 2:3?", ["3:4", "4:6", "6:8", "8:9"], 1, "Multiplying both parts by 2 gives 4:6."),
      q("q2", "If 4 notebooks cost $12, how much does one cost?", ["$2", "$3", "$4", "$8"], 1, "Divide the total cost by the number of notebooks: 12 ÷ 4 = 3."),
      q("q3", "A map scale is 1 cm = 5 km. What does 6 cm represent?", ["11 km", "20 km", "25 km", "30 km"], 3, "Multiply 6 by 5 km per centimeter to get 30 km."),
      q("q4", "What is 25% of 80?", ["10", "15", "20", "25"], 2, "One quarter of 80 is 20, and 25% equals one quarter."),
    ]),
  },
  {
    slug: "english-reading-inference",
    title: "Reading Inference Lab",
    description: "Use clues, context, and evidence to read between the lines with confidence.",
    subject: "english", gradeBand: "6-8", topic: "Reading comprehension", learningObjectives: "Make evidence-based inferences and distinguish stated facts from implied ideas.", tags: "reading,inference,evidence,comprehension", estimatedMinutes: 8, cover: "🔎", difficulty: "medium", authorName: "BookWorm", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "An inference is best described as…", ["A guess with no clues", "A conclusion supported by evidence", "A dictionary definition", "A direct quotation"], 1, "Readers infer by combining text clues with what they already know."),
      q("q2", "Which detail is strongest evidence that a character is nervous?", ["She owns a blue bag", "She taps her foot and avoids eye contact", "She reads a book", "She arrives early"], 1, "Tapping and avoiding eye contact are observable signs of nervousness."),
      q("q3", "What does context usually help a reader determine?", ["The author's handwriting", "The meaning of an unfamiliar word", "The page number", "The font size"], 1, "Nearby words and ideas provide clues to a word's meaning."),
      q("q4", "A theme is…", ["The lesson or message of a text", "The setting only", "The list of characters", "The title font"], 0, "Theme is the larger idea or message explored by a story."),
    ]),
  },
  {
    slug: "english-writing-evidence",
    title: "Writing with Evidence",
    description: "Build stronger paragraphs with claims, relevant evidence, and clear explanations.",
    subject: "english", gradeBand: "9-12", topic: "Argument writing", learningObjectives: "Develop claims, integrate evidence, and explain how evidence supports an argument.", tags: "writing,claims,evidence,argument", estimatedMinutes: 9, cover: "📝", difficulty: "hard", authorName: "EssayAce", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "A claim in an argument is…", ["A debatable position", "A page number", "A source list", "A transition word"], 0, "A claim is the writer's position that the argument supports."),
      q("q2", "What should follow a quotation in an analytical paragraph?", ["A new topic", "An explanation of its significance", "Only an emoji", "The conclusion immediately"], 1, "Analysis explains how the evidence supports the claim."),
      q("q3", "Which source is generally most credible for a research claim?", ["An anonymous rumor", "A peer-reviewed study", "An unsourced meme", "A random comment"], 1, "Peer review adds expert evaluation and accountability."),
      q("q4", "A counterclaim is…", ["An opposing viewpoint", "The title", "A spelling error", "A summary of every source"], 0, "Addressing an opposing viewpoint can make an argument more persuasive."),
    ]),
  },
  {
    slug: "english-figurative-language",
    title: "Figurative Language Studio",
    description: "Spot similes, metaphors, personification, hyperbole, and powerful imagery.",
    subject: "english", gradeBand: "3-5", topic: "Figurative language", learningObjectives: "Identify common figurative language devices and explain their effects on a reader.", tags: "simile,metaphor,poetry,language", estimatedMinutes: 6, cover: "✨", difficulty: "easy", authorName: "WordSmith", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "Which sentence contains a simile?", ["The moon is a lamp.", "The moon shone like a silver coin.", "The moon rose.", "The moon was visible."], 1, "A simile compares using like or as."),
      q("q2", "'The wind whispered' is an example of…", ["Personification", "Alliteration", "Rhyme", "A fact"], 0, "Personification gives a human action to something nonhuman."),
      q("q3", "Hyperbole is…", ["A very small detail", "An intentional exaggeration", "A direct definition", "A question"], 1, "Hyperbole exaggerates for emphasis or effect."),
      q("q4", "A metaphor makes a comparison by saying one thing…", ["Is another thing", "Rhymes with another thing", "Has a question", "Uses a number"], 0, "Metaphors make direct comparisons without like or as."),
    ]),
  },
  {
    slug: "social-civics-government",
    title: "Civics & Government Basics",
    description: "Learn how communities make decisions, protect rights, and participate in government.",
    subject: "social", gradeBand: "6-8", topic: "Civics & government", learningObjectives: "Describe branches of government, civic responsibilities, and foundational rights.", tags: "civics,government,rights,democracy", estimatedMinutes: 8, cover: "🏛️", difficulty: "medium", authorName: "CivicSpark", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "Which branch of the U.S. government makes federal laws?", ["Executive", "Legislative", "Judicial", "Local"], 1, "Congress, the legislative branch, writes and passes federal laws."),
      q("q2", "What is a civic responsibility?", ["Ignoring elections", "Participating in community life", "Breaking laws", "Avoiding all discussions"], 1, "Civic responsibilities include informed participation and helping communities."),
      q("q3", "The First Amendment protects freedom of…", ["Speech", "Speeding", "Tax evasion", "Plagiarism"], 0, "The First Amendment protects speech, religion, press, assembly, and petition."),
      q("q4", "A constitution is primarily…", ["A grocery list", "A framework for government", "A weather report", "A private diary"], 1, "A constitution establishes structures, powers, and rights."),
    ]),
  },
  {
    slug: "social-economics-everyday",
    title: "Everyday Economics",
    description: "Explore needs, wants, markets, saving, budgeting, and the choices behind everyday life.",
    subject: "social", gradeBand: "9-12", topic: "Economics & finance", learningObjectives: "Apply opportunity cost, supply and demand, budgeting, and basic financial reasoning.", tags: "economics,budgeting,markets,finance", estimatedMinutes: 9, cover: "💵", difficulty: "medium", authorName: "MarketMaven", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "Opportunity cost is…", ["The next-best choice given up", "A free gift", "A tax receipt", "A store coupon"], 0, "Opportunity cost measures what you sacrifice when choosing an option."),
      q("q2", "If demand rises while supply stays the same, price often…", ["Falls", "Rises", "Becomes zero", "Cannot change"], 1, "More buyers competing for the same supply tends to increase price."),
      q("q3", "A budget helps a person…", ["Plan income and spending", "Avoid all choices", "Guarantee profit", "Remove every need"], 0, "A budget compares expected income with planned expenses and savings."),
      q("q4", "Saving money means setting some income aside for…", ["Future use", "Immediate waste", "A random guess", "A guaranteed prize"], 0, "Savings can support future goals or unexpected expenses."),
    ]),
  },
  {
    slug: "social-world-cultures",
    title: "World Cultures & Traditions",
    description: "Compare how people around the world express identity through language, food, art, and celebrations.",
    subject: "social", gradeBand: "3-5", topic: "Culture & geography", learningObjectives: "Describe cultural diversity respectfully and connect traditions to place and history.", tags: "culture,traditions,diversity,geography", estimatedMinutes: 7, cover: "🌎", difficulty: "easy", authorName: "CultureQuest", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "Culture can include a community's…", ["Language and traditions", "Weather only", "Height only", "Favorite number"], 0, "Culture includes shared language, beliefs, traditions, arts, and practices."),
      q("q2", "Why should we avoid assuming every person in a group is the same?", ["Groups have no history", "Individuals and communities are diverse", "Facts never matter", "Maps are inaccurate"], 1, "Respectful learning recognizes differences within and between communities."),
      q("q3", "Food traditions are often influenced by…", ["Environment and history", "The alphabet only", "Random dice", "Planet size"], 0, "Available ingredients, migration, climate, and history shape food traditions."),
      q("q4", "A respectful way to learn about another culture is to…", ["Ask questions and use reliable sources", "Mock unfamiliar customs", "Copy stereotypes", "Ignore people from it"], 0, "Curiosity, listening, and reliable sources support respectful understanding."),
    ]),
  },
  {
    slug: "cs-web-internet",
    title: "How the Web Works",
    description: "URLs, browsers, servers, HTML, CSS, and the invisible systems behind your favorite sites.",
    subject: "cs", gradeBand: "6-8", topic: "Web & internet", learningObjectives: "Explain the roles of browsers, servers, URLs, HTML, and CSS in a web page.", tags: "internet,web,html,css,browsers", estimatedMinutes: 8, cover: "🌐", difficulty: "medium", authorName: "WebWizard", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "What does a web browser do?", ["Displays and interacts with web content", "Prints electricity", "Only stores passwords", "Creates weather"], 0, "Browsers request, interpret, and display web resources."),
      q("q2", "HTML primarily describes a page's…", ["Structure", "Electric bill", "Wi-Fi signal", "Color temperature"], 0, "HTML elements define the structure and content of a web page."),
      q("q3", "CSS is commonly used to control…", ["Presentation and layout", "The Earth's orbit", "Passwords only", "CPU voltage"], 0, "CSS styles colors, spacing, typography, and layout."),
      q("q4", "A URL helps identify…", ["The location of a web resource", "A computer's weight", "A keyboard shortcut", "A battery level"], 0, "A URL tells a browser where to request a resource."),
    ]),
  },
  {
    slug: "cs-data-algorithms",
    title: "Data, Algorithms & Problem Solving",
    description: "Learn how data structures and algorithms help computers solve problems efficiently.",
    subject: "cs", gradeBand: "9-12", topic: "Algorithms & data", learningObjectives: "Compare algorithms, data structures, and computational trade-offs.", tags: "algorithms,data-structures,complexity,problem-solving", estimatedMinutes: 10, cover: "🧩", difficulty: "hard", authorName: "CosmicCoder", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "An algorithm is…", ["A finite procedure for solving a problem", "A computer brand", "A file extension only", "A screen color"], 0, "Algorithms are step-by-step procedures that transform input into output."),
      q("q2", "Which structure is best described as last-in, first-out?", ["Queue", "Stack", "Graph", "Table"], 1, "A stack removes the most recently added item first."),
      q("q3", "Binary search requires data to be…", ["Sorted", "Encrypted", "Printed", "Duplicated"], 0, "Binary search repeatedly halves a sorted search range."),
      q("q4", "Why do programmers analyze complexity?", ["To estimate how resources grow with input", "To choose a logo", "To change screen brightness", "To name variables"], 0, "Complexity analysis helps compare time and space as input grows."),
    ]),
  },
  {
    slug: "cs-cyber-safety",
    title: "Digital Citizenship & Cyber Safety",
    description: "Practice smart habits for passwords, privacy, phishing, and respectful online communities.",
    subject: "cs", gradeBand: "3-5", topic: "Digital citizenship", learningObjectives: "Recognize safe online behaviors, protect private information, and identify scams.", tags: "safety,privacy,phishing,digital-citizenship", estimatedMinutes: 7, cover: "🛡️", difficulty: "easy", authorName: "SafetyScout", isFeatured: 0, isDaily: 0, timesPlayed: 0, avgScore: 0,
    questions: JSON.stringify([
      q("q1", "Which password is safest?", ["password123", "A long unique passphrase", "Your first name", "123456"], 1, "Long, unique passphrases are harder to guess and should not be reused."),
      q("q2", "Phishing is an attempt to…", ["Trick you into revealing information", "Improve your Wi-Fi", "Clean a screen", "Organize files"], 0, "Phishing messages imitate trusted sources to steal information."),
      q("q3", "What should you do before sharing a photo of someone?", ["Ask permission", "Post immediately", "Share their address", "Remove their name only"], 0, "Permission respects privacy and safety."),
      q("q4", "Private information includes…", ["Your home address", "A public weather fact", "A math solution", "A book title"], 0, "Addresses and similar details can identify or locate a person."),
    ]),
  },
];

async function main() {
  console.log(`Expanding QUIZVERSE with ${EXPANSION.length} additional topics…`);
  for (const quiz of EXPANSION) {
    const existing = await getQuizBySlug(quiz.slug);
    if (existing) await updateQuiz(quiz.slug, quiz);
    else await createQuiz(quiz);
    console.log(`✓ ${quiz.title}`);
  }
  console.log(`Added/updated ${EXPANSION.length} quizzes across science, math, English, social studies, and computer science.`);
}

main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
