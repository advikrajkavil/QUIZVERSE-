import mysql from "mysql2/promise";

type Question = {
  id: string;
  text: string;
  options: [string, string, string, string];
  correct: number;
  [key: string]: unknown;
};

function moveCorrectAnswer(question: Question, targetIndex: number): Question {
  const currentIndex = Math.max(0, Math.min(3, question.correct));
  const options = [...question.options];
  const [correctOption] = options.splice(currentIndex, 1);
  options.splice(targetIndex, 0, correctOption);
  return { ...question, options: options as [string, string, string, string], correct: targetIndex };
}

async function main() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL!);
  const [rows] = await connection.query("SELECT id, slug, questions FROM quizzes ORDER BY id ASC");
  let updated = 0;
  let changedQuestions = 0;
  const distribution = [0, 0, 0, 0];

  for (const row of rows as Array<{ id: number; slug: string; questions: string }>) {
    const questions = JSON.parse(row.questions) as Question[];
    const normalized = questions.map((question, index) => {
      // Cycle through all four answer positions within each quiz. The quiz id
      // adds variety across the catalog while preserving every correct answer.
      const targetIndex = (row.id + index) % 4;
      distribution[targetIndex]++;
      if (question.correct !== targetIndex) changedQuestions++;
      return moveCorrectAnswer(question, targetIndex);
    });
    await connection.execute("UPDATE quizzes SET questions = ? WHERE id = ?", [JSON.stringify(normalized), row.id]);
    updated++;
  }

  await connection.end();
  console.log(`Normalized ${changedQuestions} question answers across ${updated} quizzes.`);
  console.log(`Correct-answer position distribution: A=${distribution[0]}, B=${distribution[1]}, C=${distribution[2]}, D=${distribution[3]}`);
}

main().then(() => process.exit(0)).catch((error) => { console.error(error); process.exit(1); });
