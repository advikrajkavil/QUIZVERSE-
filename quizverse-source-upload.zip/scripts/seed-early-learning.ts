import { InsertQuiz } from "../drizzle/schema";
import { createQuiz, getQuizBySlug, updateQuiz } from "../server/db";

type GradeBand = "nursery" | "grade1" | "grade2";
type Subject = "science" | "math" | "english" | "social" | "cs";
type Topic = { subject: Subject; title: string; cover: string };
type QuizSeed = Omit<InsertQuiz, "id" | "createdAt" | "updatedAt">;

const slugify = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 50);
const q = (id: string, text: string, options: [string, string, string, string], correct: number, explanation: string, hint: string) => ({ id, text, options, correct, explanation, hint, points: 100, timeLimit: 25 });
const spreadAnswers = (questions: ReturnType<typeof q>[], seed: number) => questions.map((question, index) => {
  const target = (seed + index) % 4;
  const options = [...question.options];
  const [correctOption] = options.splice(question.correct, 1);
  options.splice(target, 0, correctOption);
  return { ...question, options: options as [string, string, string, string], correct: target };
});
const topicList = (subject: Subject, cover: string, names: string): Topic[] => names.split("|").map((title) => ({ subject, title, cover }));

const TOPICS: Record<GradeBand, Topic[]> = {
  nursery: [
    ...topicList("english", "🔤", "Letter Sounds|Rhyming Words|Story Pictures|Name & Feelings|Listening & Following Directions|Everyday Words"),
    ...topicList("math", "🔢", "Counting 1 to 5|Counting 1 to 10|Big and Small|Shapes Around Us|Patterns & Sorting|More and Less"),
    ...topicList("science", "🌱", "Colors in Nature|My Five Senses|Animals & Babies|Weather Feelings|Plants Need Water|Healthy Me"),
    ...topicList("social", "🤝", "My Family|My Classroom|Sharing & Taking Turns|Community Helpers|Kind Words|Safe Places"),
    ...topicList("cs", "🧩", "Button & Tap Skills|Sequence the Day|Match & Sort|Patterns in Play|Screen Safety|Creative Building"),
  ],
  grade1: [
    ...topicList("english", "📖", "Phonics Blends|Sight Words|Beginning-Middle-End|Nouns & Verbs|Sentence Building|New Vocabulary"),
    ...topicList("math", "➕", "Numbers to 100|Addition Within 20|Subtraction Within 20|Place Value Tens|Time to the Hour|Money & Coins"),
    ...topicList("science", "🔬", "Living and Nonliving|Animal Habitats|Light & Sound|Pushes & Pulls|Seasons|Materials Around Us"),
    ...topicList("social", "🏡", "Rules & Responsibilities|Neighborhoods|Maps & Directions|Past and Present|Needs & Wants|Celebrations"),
    ...topicList("cs", "💻", "Keyboard & Mouse|Step-by-Step Instructions|Digital Drawing|Strong Password Habits|Device Care|Find the Pattern"),
  ],
  grade2: [
    ...topicList("english", "📚", "Main Idea|Context Clues|Complete Sentences|Adjectives & Adverbs|Story Character & Setting|Informational Text"),
    ...topicList("math", "✖️", "Addition to 1,000|Subtraction to 1,000|Skip Counting|Shapes & Fractions|Length & Measurement|Graphs & Questions"),
    ...topicList("science", "🌎", "Life Cycles|Plant Parts|Matter Around Us|Earth Materials|Weather Patterns|Energy & Motion"),
    ...topicList("social", "🗺️", "Local History|Leaders & Citizens|Landmarks|Goods & Services|Culture & Traditions|Using a Map Key"),
    ...topicList("cs", "🖥️", "Algorithms in Daily Life|Loops & Repetition|Digital Information|Search Carefully|Online Kindness|Build a Simple Game"),
  ],
};

function questionSet(subject: Subject, topic: string, grade: GradeBand) {
  const age = grade === "nursery" ? "a young learner" : grade === "grade1" ? "a Grade 1 learner" : "a Grade 2 learner";
  if (subject === "english") return [
    q("q1", `Which activity helps ${age} learn about ${topic}?`, ["Look, listen, and say the words", "Close the book", "Skip every sound", "Mix up the cards"], 0, `Active looking, listening, and speaking are helpful ways to practice ${topic}.`, "Try it aloud and look for clues."),
    q("q2", `What is a good way to show understanding of ${topic}?`, ["Tell or draw what you noticed", "Hide the page", "Guess without looking", "Use no words or pictures"], 0, `Explaining with words or pictures shows what you understand about ${topic}.`, "Can you explain it to a friend?"),
    q("q3", `When practicing ${topic}, what should you do if something feels tricky?`, ["Try again and ask for help", "Give up immediately", "Erase every answer", "Stop listening"], 0, "Trying again and asking for help are positive learning habits.", "Take a breath and try one small step."),
    q("q4", `Which choice is ready for a ${topic} activity?`, ["Pay attention to the directions", "Rush before listening", "Distract a friend", "Hide the materials"], 0, "Listening to directions helps you know what to do next.", "What is the first step?"),
  ];
  if (subject === "math") return [
    q("q1", `Which action helps with ${topic}?`, ["Count or compare carefully", "Guess every time", "Skip the objects", "Change the question"], 0, `Careful counting and comparing build strong ${topic} thinking.`, "Touch or point to each item once."),
    q("q2", `What can you use to check a ${topic} answer?`, ["Objects, fingers, or a drawing", "A random number", "A blank page", "Someone else's name"], 0, "Models and drawings help make math ideas visible.", "Draw the problem or use counters."),
    q("q3", `If ${topic} feels difficult, what is a helpful next step?`, ["Try a smaller example", "Hide the numbers", "Never check", "Choose the biggest answer"], 0, "A smaller example can make a new idea easier to understand.", "Start with just one or two items."),
    q("q4", `Which habit makes math work clearer?`, ["Explain how you know", "Cover the work", "Skip the question", "Erase the model"], 0, "Explaining your thinking helps you and your teacher see the strategy.", "Say: I know because…"),
  ];
  if (subject === "science") return [
    q("q1", `What do curious scientists do when learning about ${topic}?`, ["Look closely and ask questions", "Ignore what they see", "Change every answer", "Hide the objects"], 0, `Observation and questions help us learn about ${topic}.`, "Use your eyes, ears, and hands safely."),
    q("q2", `Which is useful evidence for ${topic}?`, ["Something you can see, hear, or measure", "A secret guess", "A random color", "A made-up rule"], 0, "Evidence is information we can observe or measure.", "What did you notice?"),
    q("q3", `How can you care for the world while studying ${topic}?`, ["Be gentle and leave living things safe", "Pull everything apart", "Waste all the water", "Touch unsafe objects"], 0, "Safe, gentle choices protect people, animals, plants, and materials.", "Ask before touching."),
    q("q4", `What is a great science question about ${topic}?`, ["What do you notice and why?", "Is there no answer?", "Can I ignore it?", "Who is fastest?"], 0, "Good questions invite observation, comparison, and explanation.", "Look for something you want to discover."),
  ];
  if (subject === "social") return [
    q("q1", `What helps us learn about ${topic}?`, ["Listen, share, and notice how people help", "Interrupt everyone", "Keep every idea secret", "Ignore the place"], 0, `Social learning about ${topic} grows when we listen and notice our community.`, "Think about how people work together."),
    q("q2", `Which choice shows kindness during ${topic}?`, ["Take turns and include others", "Grab everything", "Laugh at a mistake", "Refuse to listen"], 0, "Taking turns and including others help make a caring community.", "How would you want to be treated?"),
    q("q3", `What can a picture or map teach us about ${topic}?`, ["Where people and places are", "How to erase history", "A secret password", "Nothing at all"], 0, "Pictures and maps can show places, people, and connections.", "Look for labels and landmarks."),
    q("q4", `When learning about ${topic}, why do we ask questions?`, ["To understand people and places better", "To make others feel bad", "To avoid learning", "To change every fact"], 0, "Questions help us learn respectfully and connect ideas to our lives.", "Ask who, what, where, or why."),
  ];
  return [
    q("q1", `Which action is helpful when learning about ${topic} on a device?`, ["Follow steps carefully", "Tap every button", "Share private information", "Ignore the adult"], 0, `Clear steps and safe choices help you learn about ${topic} with technology.`, "Pause and read before tapping."),
    q("q2", `What is an algorithm for ${topic}?`, ["A list of steps", "A magic word", "A broken screen", "A secret identity"], 0, "An algorithm is an ordered list of steps for completing a task.", "What happens first, next, and last?"),
    q("q3", `What should you do if something unexpected happens while practicing ${topic}?`, ["Stop and tell a trusted adult", "Share your password", "Tap faster", "Hide the device"], 0, "A trusted adult can help keep you safe and solve the problem.", "Safety comes before speed."),
    q("q4", `Which activity builds ${topic} thinking?`, ["Make, test, and improve", "Never try", "Copy without looking", "Hide the result"], 0, "Making, testing, and improving are core problem-solving habits.", "What could you change next time?"),
  ];
}

function makeQuiz(gradeBand: GradeBand, item: Topic, index: number): QuizSeed {
  const slug = `${gradeBand}-${slugify(item.subject + "-" + item.title)}`.slice(0, 64);
  const difficulty = gradeBand === "nursery" ? "easy" : gradeBand === "grade1" ? (index % 5 === 0 ? "medium" : "easy") : (index % 4 === 0 ? "medium" : "easy");
  const objectives = gradeBand === "nursery"
    ? `Build confidence with ${item.title} through play, conversation, observation, and gentle practice.`
    : gradeBand === "grade1"
      ? `Practice ${item.title} using clear directions, examples, and explain-your-thinking strategies.`
      : `Strengthen Grade 2 understanding of ${item.title} and apply the skill in a new everyday example.`;
  return {
    slug,
    title: item.title,
    description: `${gradeBand === "nursery" ? "Playful" : "Friendly"} ${item.title} practice with picture-friendly language, hints, explanations, and confidence-building steps.`,
    subject: item.subject,
    gradeBand,
    topic: item.title,
    learningObjectives: objectives,
    tags: `${item.subject},early-learning,${slugify(item.title).replace(/-/g, ",")},family-practice`,
    estimatedMinutes: gradeBand === "nursery" ? 4 : 6,
    cover: item.cover,
    difficulty,
    isFeatured: index < 2 ? 1 : 0,
    isDaily: index === 0 ? 1 : 0,
    authorName: "QUIZVERSE Early Learning",
    timesPlayed: 0,
    avgScore: 0,
    questions: JSON.stringify(spreadAnswers(questionSet(item.subject, item.title, gradeBand), index)),
  } as QuizSeed;
}

async function main() {
  let created = 0;
  let updated = 0;
  for (const gradeBand of ["nursery", "grade1", "grade2"] as GradeBand[]) {
    for (const [index, item] of TOPICS[gradeBand].entries()) {
      const quiz = makeQuiz(gradeBand, item, index);
      const existing = await getQuizBySlug(quiz.slug);
      if (existing) { await updateQuiz(quiz.slug, quiz); updated++; }
      else { await createQuiz(quiz); created++; }
    }
    console.log(`${gradeBand}: ${TOPICS[gradeBand].length} detailed topics ready`);
  }
  console.log(`Early-learning catalog complete: ${created} created, ${updated} refreshed.`);
}

main().then(() => process.exit(0)).catch((error) => { console.error(error); process.exit(1); });
