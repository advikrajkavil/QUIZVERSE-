import { and, desc, eq, isNotNull, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertLeaderboardEntry,
  InsertQuiz,
  InsertUser,
  LeaderboardEntry,
  Quiz,
  gameRooms,
  leaderboard,
  quizzes,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { GameRoomDoc, LeaderEntry, Question, RoomAnswer, RoomPlayer } from "@shared/types";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    textFields.forEach((field) => {
      const v = user[field];
      if (v === undefined) return;
      values[field] = v ?? null;
      updateSet[field] = v ?? null;
    });
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    values.lastSignedIn = values.lastSignedIn ?? new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ---------------- QUIZZES ----------------

export async function listQuizzes(opts?: {
  subject?: string;
  gradeBand?: string;
  search?: string;
  difficulty?: string;
  sort?: "popular" | "newest" | "top";
  limit?: number;
  featuredOnly?: boolean;
  dailyOnly?: boolean;
}) {
  const db = await getDb();
  if (!db) return [];
  const limit = Math.min(Math.max(opts?.limit ?? 30, 1), 60);

  const conditions: any[] = [];
  if (opts?.subject && opts.subject !== "all") {
    conditions.push(eq(quizzes.subject, opts.subject as any));
  }
  if (opts?.gradeBand && opts.gradeBand !== "all") {
    conditions.push(eq(quizzes.gradeBand, opts.gradeBand as any));
  }
  if (opts?.difficulty && opts.difficulty !== "all") {
    conditions.push(eq(quizzes.difficulty, opts.difficulty as any));
  }
  if (opts?.featuredOnly) {
    conditions.push(eq(quizzes.isFeatured, 1));
  }
  if (opts?.dailyOnly) {
    conditions.push(eq(quizzes.isDaily, 1));
  }
  if (opts?.search && opts.search.trim()) {
    conditions.push(
      sql`(${quizzes.title} LIKE ${"%" + opts.search.trim() + "%"} OR ${quizzes.description} LIKE ${"%" + opts.search.trim() + "%"})`
    );
  }

  const where = conditions.length === 0 ? undefined : conditions.length === 1 ? conditions[0] : and(...conditions);
  const orderBy =
    opts?.sort === "popular"
      ? desc(quizzes.timesPlayed)
      : opts?.sort === "top"
      ? desc(quizzes.avgScore)
      : desc(quizzes.createdAt);

  const q = db.select().from(quizzes);
  const rows = where ? await q.where(where).orderBy(orderBy).limit(limit) : await q.orderBy(orderBy).limit(limit);
  return rows.map(hydrateQuiz);
}

function hydrateQuiz(q: Quiz) {
  let questions: Question[] = [];
  try {
    questions = JSON.parse(q.questions);
  } catch {}
  return { ...q, questions };
}

export async function getQuizBySlug(slug: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(quizzes).where(eq(quizzes.slug, slug)).limit(1);
  return rows[0] ? hydrateQuiz(rows[0]) : null;
}

export async function getQuizById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(quizzes).where(eq(quizzes.id, id)).limit(1);
  return rows[0] ? hydrateQuiz(rows[0]) : undefined;
}

export async function createQuiz(data: InsertQuiz) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(quizzes).values(data);
  return getQuizBySlug(data.slug);
}

export async function updateQuiz(slug: string, patch: Partial<InsertQuiz>, authorOpenId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await getQuizBySlug(slug);
  if (!existing) return undefined;
  if (existing.authorOpenId && authorOpenId && existing.authorOpenId !== authorOpenId) {
    throw new Error("You are not allowed to edit this quiz");
  }
  await db.update(quizzes).set(patch as any).where(eq(quizzes.slug, slug));
  return getQuizBySlug(slug);
}

export async function deleteQuiz(slug: string, authorOpenId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await getQuizBySlug(slug);
  if (!existing) return false;
  if (existing.authorOpenId && authorOpenId && existing.authorOpenId !== authorOpenId) {
    throw new Error("You are not allowed to delete this quiz");
  }
  await db.delete(quizzes).where(eq(quizzes.slug, slug));
  return true;
}

export async function recordQuizPlay(slug: string, scorePercent: number) {
  const db = await getDb();
  if (!db) return;
  const quiz = await getQuizBySlug(slug);
  if (!quiz) return;
  const n = quiz.timesPlayed + 1;
  const avg = Math.round((quiz.avgScore * quiz.timesPlayed + scorePercent) / n);
  await db
    .update(quizzes)
    .set({ timesPlayed: n, avgScore: avg })
    .where(eq(quizzes.slug, slug));
}

// ---------------- LIVE ROOMS ----------------

function genCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

export async function createGameRoom(quizId: number, hostName = "Host", hostOpenId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = genCode();
    try {
      await db.insert(gameRooms).values({
        code,
        quizId,
        hostName,
        hostOpenId,
        status: "waiting",
        currentQuestion: 0,
        players: "[]",
        answers: "{}",
      });
      return getGameRoom(code);
    } catch (e: any) {
      if (e?.code === "ER_DUP_ENTRY") continue;
      throw e;
    }
  }
  throw new Error("Failed to allocate room code");
}

export async function getGameRoom(code: string): Promise<GameRoomDoc | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(gameRooms).where(eq(gameRooms.code, code.toUpperCase())).limit(1);
  const r = rows[0];
  if (!r) return undefined;
  const quiz = await getQuizById(r.quizId);
  return {
    id: r.id,
    code: r.code,
    quizId: r.quizId,
    hostName: r.hostName,
    status: r.status as any,
    currentQuestion: r.currentQuestion,
    questionStartedAt: r.questionStartedAt ? r.questionStartedAt.toISOString() : undefined,
    answers: safeJson(r.answers, {}),
    players: safeJson(r.players, []),
    quiz,
  };
}

function safeJson<T>(s: string | null | undefined, fallback: T): T {
  try {
    return s ? JSON.parse(s) : fallback;
  } catch {
    return fallback;
  }
}

export async function joinGameRoom(code: string, player: { id: string; name: string; avatar: string; accountId?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const room = await getGameRoom(code);
  if (!room) throw new Error("Room not found");
  const players: RoomPlayer[] = [...room.players];
  const idx = players.findIndex((p) => p.id === player.id);
  const record: RoomPlayer = {
    id: player.id,
    accountId: player.accountId,
    name: player.name || "Player",
    avatar: player.avatar || "🚀",
    score: idx >= 0 ? players[idx].score : 0,
    streak: idx >= 0 ? players[idx].streak : 0,
    connected: true,
  };
  if (idx >= 0) players[idx] = record;
  else players.push(record);
  await db.update(gameRooms).set({ players: JSON.stringify(players) }).where(eq(gameRooms.code, room.code));
  return getGameRoom(code);
}

export async function startRoomQuestion(code: string, questionIndex = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const room = await getGameRoom(code);
  if (!room) throw new Error("Room not found");
  await db
    .update(gameRooms)
    .set({
      status: "question",
      currentQuestion: questionIndex,
      questionStartedAt: new Date(),
      answers: "{}",
    })
    .where(eq(gameRooms.code, room.code));
  return getGameRoom(code);
}

export async function submitRoomAnswer(code: string, playerId: string, answer: RoomAnswer) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const room = await getGameRoom(code);
  if (!room) throw new Error("Room not found");
  if (room.status !== "question") throw new Error("Question is not currently active");

  const answers: Record<string, RoomAnswer> = { ...(room.answers || {}) };
  if (answers[playerId]) return room; // once per player per question
  answers[playerId] = answer;

  const players: RoomPlayer[] = [...room.players];
  const idx = players.findIndex((p) => p.id === playerId);
  if (idx >= 0) {
    const cur = players[idx];
    const newStreak = answer.correct ? cur.streak + 1 : 0;
    players[idx] = {
      ...cur,
      score: cur.score + answer.points,
      streak: newStreak,
    };
  }

  await db
    .update(gameRooms)
    .set({ answers: JSON.stringify(answers), players: JSON.stringify(players) })
    .where(eq(gameRooms.code, room.code));
  return getGameRoom(code);
}

export async function showRoomScoreboard(code: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const room = await getGameRoom(code);
  if (!room) throw new Error("Room not found");
  await db.update(gameRooms).set({ status: "scoreboard" }).where(eq(gameRooms.code, room.code));
  return getGameRoom(code);
}

export async function endRoomGame(code: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const room = await getGameRoom(code);
  if (!room) throw new Error("Room not found");
  for (const player of room.players) {
    if (!player.accountId) continue;
    const entry = {
      userId: player.accountId,
      name: player.name,
      avatar: player.avatar,
      score: Math.max(0, Math.min(player.score, 10000000)),
      coins: 0,
      rankTitle: "Novice",
    } as const;
    await upsertLeaderboard({ ...entry, period: "alltime" });
    await upsertLeaderboard({ ...entry, period: "weekly" });
  }
  await db.update(gameRooms).set({ status: "ended" }).where(eq(gameRooms.code, room.code));
  return getGameRoom(code);
}

// ---------------- LEADERBOARD ----------------

export async function listLeaderboard(period: "alltime" | "weekly" = "alltime", limit = 50): Promise<LeaderEntry[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(leaderboard)
    .where(and(eq(leaderboard.period, period), isNotNull(leaderboard.userId)))
    .orderBy(desc(leaderboard.score))
    .limit(limit);
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    avatar: r.avatar,
    score: r.score,
    coins: r.coins,
    period: r.period as any,
    rankTitle: r.rankTitle,
  }));
}

export async function upsertLeaderboard(entry: InsertLeaderboardEntry) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db
    .select()
    .from(leaderboard)
    .where(and(eq(leaderboard.userId, entry.userId!), eq(leaderboard.period, entry.period ?? "alltime")))
    .limit(1);
  if (existing[0]) {
    await db
      .update(leaderboard)
      .set({
        name: entry.name,
        avatar: entry.avatar,
        score: sql`GREATEST(${leaderboard.score}, ${entry.score ?? 0})`,
        coins: sql`GREATEST(${leaderboard.coins}, ${entry.coins ?? 0})`,
        rankTitle: entry.rankTitle ?? existing[0].rankTitle,
      })
      .where(eq(leaderboard.id, existing[0].id));
  } else {
    await db.insert(leaderboard).values(entry);
  }
}
