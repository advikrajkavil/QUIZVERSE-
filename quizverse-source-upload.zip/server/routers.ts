import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { nanoid } from "nanoid";

const questionSchema = z.object({
  id: z.string(),
  text: z.string().min(3),
  options: z.tuple([z.string().min(1), z.string().min(1), z.string().min(1), z.string().min(1)]),
  correct: z.number().min(0).max(3),
  explanation: z.string().optional(),
  hint: z.string().max(300).optional(),
  topic: z.string().max(128).optional(),
  points: z.number().min(0).max(1000).optional(),
  timeLimit: z.number().min(5).max(120).optional(),
});

function slugify(s: string) {
  return (
    s
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 50) +
    "-" +
    nanoid(5)
  );
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  quizzes: router({
    list: publicProcedure
      .input(
        z
          .object({
            subject: z.string().optional(),
            gradeBand: z.enum(["nursery", "grade1", "grade2", "3-5", "6-8", "9-12"]).optional(),
            difficulty: z.string().optional(),
            search: z.string().optional(),
            sort: z.enum(["popular", "newest", "top"]).optional(),
            featuredOnly: z.boolean().optional(),
            dailyOnly: z.boolean().optional(),
            limit: z.number().min(1).max(60).optional(),
          })
          .optional()
      )
      .query(({ input }) => db.listQuizzes(input)),

    get: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(({ input }) => db.getQuizBySlug(input.slug)),

    create: publicProcedure
      .input(
        z.object({
          title: z.string().min(2).max(256),
          description: z.string().optional(),
          subject: z.enum(["science", "math", "english", "social", "cs"]),
          gradeBand: z.enum(["nursery", "grade1", "grade2", "3-5", "6-8", "9-12"]),
          topic: z.string().min(2).max(128),
          learningObjectives: z.string().max(2000).optional(),
          tags: z.string().max(1000).optional(),
          estimatedMinutes: z.number().min(1).max(180),
          cover: z.string().max(128).optional(),
          difficulty: z.enum(["easy", "medium", "hard"]).optional(),
          authorName: z.string().max(128).optional(),
          questions: z.array(questionSchema).min(2, "Add at least 2 questions"),
        })
      )
      .mutation(({ input, ctx }) => {
        return db.createQuiz({
          slug: slugify(input.title),
          title: input.title,
          description: input.description,
          subject: input.subject,
          gradeBand: input.gradeBand,
          topic: input.topic,
          learningObjectives: input.learningObjectives,
          tags: input.tags,
          estimatedMinutes: input.estimatedMinutes,
          cover: input.cover || "🧠",
          difficulty: input.difficulty || "medium",
          authorName: input.authorName || ctx.user?.name || "Quizverse",
          authorOpenId: ctx.user?.openId,
          questions: JSON.stringify(input.questions),
        });
      }),

    update: publicProcedure
      .input(
        z.object({
          slug: z.string(),
          title: z.string().min(2).max(256).optional(),
          description: z.string().optional(),
          subject: z.enum(["science", "math", "english", "social", "cs"]).optional(),
          gradeBand: z.enum(["nursery", "grade1", "grade2", "3-5", "6-8", "9-12"]).optional(),
          topic: z.string().min(2).max(128).optional(),
          learningObjectives: z.string().max(2000).optional(),
          tags: z.string().max(1000).optional(),
          estimatedMinutes: z.number().min(1).max(180).optional(),
          cover: z.string().max(128).optional(),
          difficulty: z.enum(["easy", "medium", "hard"]).optional(),
          questions: z.array(questionSchema).min(2).optional(),
        })
      )
      .mutation(({ input, ctx }) => {
        const patch: any = {};
        if (input.title) patch.title = input.title;
        if (input.description !== undefined) patch.description = input.description;
        if (input.subject) patch.subject = input.subject;
        if (input.gradeBand) patch.gradeBand = input.gradeBand;
        if (input.topic) patch.topic = input.topic;
        if (input.learningObjectives !== undefined) patch.learningObjectives = input.learningObjectives;
        if (input.tags !== undefined) patch.tags = input.tags;
        if (input.estimatedMinutes !== undefined) patch.estimatedMinutes = input.estimatedMinutes;
        if (input.cover) patch.cover = input.cover;
        if (input.difficulty) patch.difficulty = input.difficulty;
        if (input.questions) patch.questions = JSON.stringify(input.questions);
        return db.updateQuiz(input.slug, patch, ctx.user?.openId);
      }),

    delete: publicProcedure
      .input(z.object({ slug: z.string() }))
      .mutation(({ input, ctx }) => db.deleteQuiz(input.slug, ctx.user?.openId)),

    recordPlay: publicProcedure
      .input(z.object({ slug: z.string(), scorePercent: z.number().min(0).max(100) }))
      .mutation(({ input }) => db.recordQuizPlay(input.slug, input.scorePercent)),
  }),

  rooms: router({
    create: publicProcedure
      .input(
        z.object({
          quizId: z.number(),
          hostName: z.string().min(1).max(128).optional(),
        })
      )
      .mutation(({ input, ctx }) => db.createGameRoom(input.quizId, input.hostName, ctx.user?.openId)),

    get: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(({ input }) => db.getGameRoom(input.code)),

    join: publicProcedure
      .input(
        z.object({
          code: z.string(),
          player: z.object({
            id: z.string(),
            name: z.string().min(1).max(64),
            avatar: z.string().max(64),
          }),
        })
      )
      .mutation(({ input, ctx }) =>
        db.joinGameRoom(input.code, {
          ...input.player,
          name: (ctx.user?.name || ctx.user?.email?.split("@")[0] || input.player.name).slice(0, 64),
          accountId: ctx.user?.openId,
        })
      ),

    start: publicProcedure
      .input(z.object({ code: z.string(), questionIndex: z.number().optional() }))
      .mutation(({ input }) => db.startRoomQuestion(input.code, input.questionIndex ?? 0)),

    answer: publicProcedure
      .input(
        z.object({
          code: z.string(),
          playerId: z.string(),
          answer: z.object({
            optionIndex: z.number().min(0).max(3),
            ms: z.number(),
            correct: z.boolean(),
            points: z.number(),
          }),
        })
      )
      .mutation(({ input }) => db.submitRoomAnswer(input.code, input.playerId, input.answer)),

    scoreboard: publicProcedure
      .input(z.object({ code: z.string() }))
      .mutation(({ input }) => db.showRoomScoreboard(input.code)),

    end: publicProcedure
      .input(z.object({ code: z.string() }))
      .mutation(({ input }) => db.endRoomGame(input.code)),
  }),

  leaderboard: router({
    list: publicProcedure
      .input(
        z
          .object({
            period: z.enum(["alltime", "weekly"]).optional(),
            limit: z.number().min(1).max(50).optional(),
          })
          .optional()
      )
      .query(({ input }) => db.listLeaderboard(input?.period, input?.limit)),

    submit: protectedProcedure
      .input(
        z.object({
          avatar: z.string().max(64).optional(),
          score: z.number().min(0).max(10000000),
          coins: z.number().optional(),
          period: z.enum(["alltime", "weekly"]).optional(),
          rankTitle: z.string().max(64).optional(),
        })
      )
      .mutation(({ input, ctx }) =>
        db.upsertLeaderboard({
          userId: ctx.user.openId,
          name: (ctx.user.name || ctx.user.email?.split("@")[0] || "Quiz Player").slice(0, 128),
          avatar: input.avatar || "🚀",
          score: input.score,
          coins: input.coins || 0,
          period: input.period || "alltime",
          rankTitle: input.rankTitle || "Novice",
        })
      ),
  }),
});

export type AppRouter = typeof appRouter;
