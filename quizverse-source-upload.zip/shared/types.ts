/**
 * QUIZVERSE shared types
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

export type Subject = "science" | "math" | "english" | "social" | "cs";

export type Difficulty = "easy" | "medium" | "hard";

export type GradeBand = "nursery" | "grade1" | "grade2" | "3-5" | "6-8" | "9-12";

export type GameModeId =
  | "space-race"
  | "millionaire"
  | "speed-rush"
  | "tower-battle"
  | "survival";

export interface Question {
  id: string;
  text: string;
  options: [string, string, string, string];
  correct: number; // 0..3
  explanation?: string;
  hint?: string;
  topic?: string;
  points?: number;
  timeLimit?: number; // seconds, default 20
}

export interface QuizDoc {
  id?: number;
  slug: string;
  title: string;
  description?: string | null;
  subject: Subject;
  gradeBand: GradeBand;
  topic?: string | null;
  learningObjectives?: string | null;
  tags?: string | null;
  estimatedMinutes?: number;
  cover: string; // emoji or image URL
  questions: Question[];
  difficulty: Difficulty;
  isFeatured?: boolean | number;
  isDaily?: boolean | number;
  authorName?: string | null;
  timesPlayed?: number;
  avgScore?: number;
  createdAt?: string | Date;
  updatedAt?: string | Date;
}

export interface RoomPlayer {
  id: string;
  accountId?: string;
  name: string;
  avatar: string;
  score: number;
  streak: number;
  connected?: boolean;
}

export interface RoomAnswer {
  optionIndex: number;
  ms: number;
  correct: boolean;
  points: number;
}

export interface GameRoomDoc {
  id?: number;
  code: string;
  quizId: number;
  hostName: string;
  status: "waiting" | "question" | "scoreboard" | "ended";
  currentQuestion: number;
  questionStartedAt?: string;
  answers: Record<string, RoomAnswer>; // playerId -> answer
  players: RoomPlayer[];
  quiz?: QuizDoc;
}

export interface PlayerStats {
  id: string;
  name: string;
  avatar: string;
  theme: string;
  coins: number;
  xp: number;
  level: number;
  rankTitle: string;
  streak: number;
  bestStreak: number;
  gamesPlayed: number;
  bestScore: number;
  bestScoreMode?: string;
  correctAnswers: number;
  totalAnswers: number;
  avatarsOwned: string[];
  badgesOwned: string[];
  themesOwned: string[];
  dailyCompletedAt?: string;
  updatedAt?: string;
}

export interface AvatarItem {
  id: string;
  name: string;
  emoji: string;
  price: number; // coins
  tier: "Starter" | "Rare" | "Epic" | "Legendary";
  description: string;
}

export interface BadgeItem {
  id: string;
  name: string;
  icon: string;
  description: string;
  category: "progression" | "gameplay" | "streak" | "social";
  unlocked?: boolean;
}

export interface ThemeItem {
  id: string;
  name: string;
  description: string;
  price: number;
  gradient: string;
  accent: string;
}

export interface LeaderEntry {
  id: number;
  name: string;
  avatar: string;
  score: number;
  coins: number;
  period: "alltime" | "weekly";
  rankTitle: string;
}
